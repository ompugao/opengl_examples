#pragma once
#include "setup.h"
CSetup setup;
#include "SpaceForm.h"

namespace Collision3
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Form1 �̊T�v
	///
	/// �x�� : ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ 
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ����������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::GroupBox *  groupBox2;
	private: System::Windows::Forms::Button *  btnCrane;
	private: System::Windows::Forms::Button *  btnTilt;
	private: System::Windows::Forms::Button *  btnTumble;
	private: System::Windows::Forms::Button *  btnPan;
	private: System::Windows::Forms::Button *  btnZoom;
	private: System::Windows::Forms::Button *  btnDolly;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::TextBox *  txtLightZ;
	private: System::Windows::Forms::Button *  btnLightZ;
	private: System::Windows::Forms::TextBox *  txtLightY;
	private: System::Windows::Forms::Button *  btnLightY;
	private: System::Windows::Forms::TextBox *  txtLightX;
	private: System::Windows::Forms::Button *  btnLightX;
	private: System::Windows::Forms::CheckBox *  chkWireframe;
	public: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::CheckBox *  chkShadow;
	private: System::Windows::Forms::TextBox *  txtGridWidth;
	private: System::Windows::Forms::Button *  btnWidth;
	public: System::Windows::Forms::RadioButton *  rdbCheck;
	public: System::Windows::Forms::RadioButton *  rdbGrid;
	public: System::Windows::Forms::RadioButton *  rdbNon;
	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::Button *  btnReady;
	private: System::Windows::Forms::GroupBox *  groupBox5;
	private: System::Windows::Forms::TextBox *  txtSpeed1;
	private: System::Windows::Forms::TextBox *  txtSpeed2;
	private: System::Windows::Forms::GroupBox *  groupBox6;
	private: System::Windows::Forms::TextBox *  txtDir1;
	private: System::Windows::Forms::TextBox *  txtDir2;
	private: System::Windows::Forms::GroupBox *  groupBox7;
	private: System::Windows::Forms::TextBox *  txtOmegaZ1;
	private: System::Windows::Forms::TextBox *  txtOmegaZ2;
	private: System::Windows::Forms::GroupBox *  groupBox8;
	private: System::Windows::Forms::TextBox *  txtMass1;
	private: System::Windows::Forms::TextBox *  txtMass2;
	private: System::Windows::Forms::GroupBox *  groupBox9;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Label *  label2;

	private: System::Windows::Forms::TextBox *  txtRestitutionFloor;
	private: System::Windows::Forms::GroupBox *  groupBox10;
	private: System::Windows::Forms::RadioButton *  rdbSphere1;
	private: System::Windows::Forms::RadioButton *  rdbCube1;
	private: System::Windows::Forms::RadioButton *  rdbCylinder1;
	private: System::Windows::Forms::GroupBox *  groupBox11;
	private: System::Windows::Forms::RadioButton *  rdbSphere2;
	private: System::Windows::Forms::RadioButton *  rdbCube2;
	private: System::Windows::Forms::RadioButton *  rdbCylinder2;
	private: System::Windows::Forms::GroupBox *  groupBox12;
	private: System::Windows::Forms::Label *  label3;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::TextBox *  txtMuRigid;
	private: System::Windows::Forms::TextBox *  txtMuFloor;
	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::TextBox *  txtNumFrame;
	private: System::Windows::Forms::Label *  label6;
	private: System::Windows::Forms::TextBox *  txtNumThin;
	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::TextBox *  txtDrawTime;
	private: System::Windows::Forms::TextBox *  txtDeltaTime;
	private: System::Windows::Forms::Button *  btnStart;
	private: System::Windows::Forms::Button *  btnStop;
	private: System::Windows::Forms::Button *  btnStep;
	private: System::Windows::Forms::GroupBox *  groupBox13;
	private: System::Windows::Forms::Label *  label9;
	private: System::Windows::Forms::Label *  label10;
	private: System::Windows::Forms::Label *  label11;
	private: System::Windows::Forms::Button *  btnScalingX1;
	private: System::Windows::Forms::TextBox *  txtScalingX1;
	private: System::Windows::Forms::Button *  btnScalingY1;
	private: System::Windows::Forms::Button *  btnScalingZ1;

	private: System::Windows::Forms::TextBox *  txtScalingZ1;
	private: System::Windows::Forms::Button *  btnTransX1;
	private: System::Windows::Forms::Button *  btnTransY1;
	private: System::Windows::Forms::Button *  btnTransZ1;
	private: System::Windows::Forms::TextBox *  txtTransX1;
	private: System::Windows::Forms::TextBox *  txtTransY1;
	private: System::Windows::Forms::TextBox *  txtTransZ1;
	private: System::Windows::Forms::Button *  btnRotX1;
	private: System::Windows::Forms::Button *  btnRotY1;
	private: System::Windows::Forms::Button *  btnRotZ1;
	private: System::Windows::Forms::TextBox *  txtRotX1;
	private: System::Windows::Forms::TextBox *  txtRotY1;
	private: System::Windows::Forms::TextBox *  txtRotZ1;
	private: System::Windows::Forms::GroupBox *  groupBox14;
	private: System::Windows::Forms::Label *  label12;
	private: System::Windows::Forms::Label *  label13;
	private: System::Windows::Forms::Label *  label14;
	private: System::Windows::Forms::Button *  btnScalingX2;
	private: System::Windows::Forms::Button *  btnScalingY2;
	private: System::Windows::Forms::Button *  btnScalingZ2;
	private: System::Windows::Forms::TextBox *  txtScalingX2;
	private: System::Windows::Forms::TextBox *  txtScalingY2;
	private: System::Windows::Forms::TextBox *  txtScalingZ2;
	private: System::Windows::Forms::Button *  btnTransX2;
	private: System::Windows::Forms::Button *  btnTransY2;
	private: System::Windows::Forms::Button *  btnTransZ2;
	private: System::Windows::Forms::TextBox *  txtTransX2;
	private: System::Windows::Forms::TextBox *  txtTransY2;
	private: System::Windows::Forms::TextBox *  txtTransZ2;
	private: System::Windows::Forms::Button *  btnRotX2;
	private: System::Windows::Forms::Button *  btnRotY2;
	private: System::Windows::Forms::Button *  btnRotZ2;
	private: System::Windows::Forms::TextBox *  txtRotX2;
	private: System::Windows::Forms::TextBox *  txtRotY2;
	private: System::Windows::Forms::TextBox *  txtRotZ2;
private: System::Windows::Forms::TextBox *  txtRestitutionRigid;
private: System::Windows::Forms::CheckBox *  chkTrack;
private: System::Windows::Forms::RadioButton *  rdbNo1;
private: System::Windows::Forms::RadioButton *  rdbNo2;
private: System::Windows::Forms::TextBox *  txtScalingY1;
private: System::Windows::Forms::Label *  label15;


	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->rdbNo2 = new System::Windows::Forms::RadioButton();
			this->rdbNo1 = new System::Windows::Forms::RadioButton();
			this->chkTrack = new System::Windows::Forms::CheckBox();
			this->btnCrane = new System::Windows::Forms::Button();
			this->btnTilt = new System::Windows::Forms::Button();
			this->btnTumble = new System::Windows::Forms::Button();
			this->btnPan = new System::Windows::Forms::Button();
			this->btnZoom = new System::Windows::Forms::Button();
			this->btnDolly = new System::Windows::Forms::Button();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->txtLightZ = new System::Windows::Forms::TextBox();
			this->btnLightZ = new System::Windows::Forms::Button();
			this->txtLightY = new System::Windows::Forms::TextBox();
			this->btnLightY = new System::Windows::Forms::Button();
			this->txtLightX = new System::Windows::Forms::TextBox();
			this->btnLightX = new System::Windows::Forms::Button();
			this->chkWireframe = new System::Windows::Forms::CheckBox();
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->chkShadow = new System::Windows::Forms::CheckBox();
			this->txtGridWidth = new System::Windows::Forms::TextBox();
			this->btnWidth = new System::Windows::Forms::Button();
			this->rdbCheck = new System::Windows::Forms::RadioButton();
			this->rdbGrid = new System::Windows::Forms::RadioButton();
			this->rdbNon = new System::Windows::Forms::RadioButton();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->btnStep = new System::Windows::Forms::Button();
			this->btnStop = new System::Windows::Forms::Button();
			this->btnStart = new System::Windows::Forms::Button();
			this->txtDeltaTime = new System::Windows::Forms::TextBox();
			this->txtDrawTime = new System::Windows::Forms::TextBox();
			this->label8 = new System::Windows::Forms::Label();
			this->label7 = new System::Windows::Forms::Label();
			this->txtNumThin = new System::Windows::Forms::TextBox();
			this->label6 = new System::Windows::Forms::Label();
			this->txtNumFrame = new System::Windows::Forms::TextBox();
			this->label5 = new System::Windows::Forms::Label();
			this->groupBox12 = new System::Windows::Forms::GroupBox();
			this->txtMuFloor = new System::Windows::Forms::TextBox();
			this->txtMuRigid = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->label3 = new System::Windows::Forms::Label();
			this->groupBox10 = new System::Windows::Forms::GroupBox();
			this->rdbCylinder1 = new System::Windows::Forms::RadioButton();
			this->rdbCube1 = new System::Windows::Forms::RadioButton();
			this->rdbSphere1 = new System::Windows::Forms::RadioButton();
			this->groupBox9 = new System::Windows::Forms::GroupBox();
			this->txtRestitutionFloor = new System::Windows::Forms::TextBox();
			this->txtRestitutionRigid = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->groupBox8 = new System::Windows::Forms::GroupBox();
			this->txtMass2 = new System::Windows::Forms::TextBox();
			this->txtMass1 = new System::Windows::Forms::TextBox();
			this->groupBox7 = new System::Windows::Forms::GroupBox();
			this->txtOmegaZ2 = new System::Windows::Forms::TextBox();
			this->txtOmegaZ1 = new System::Windows::Forms::TextBox();
			this->groupBox6 = new System::Windows::Forms::GroupBox();
			this->txtDir2 = new System::Windows::Forms::TextBox();
			this->txtDir1 = new System::Windows::Forms::TextBox();
			this->groupBox5 = new System::Windows::Forms::GroupBox();
			this->txtSpeed2 = new System::Windows::Forms::TextBox();
			this->txtSpeed1 = new System::Windows::Forms::TextBox();
			this->btnReady = new System::Windows::Forms::Button();
			this->groupBox11 = new System::Windows::Forms::GroupBox();
			this->rdbCylinder2 = new System::Windows::Forms::RadioButton();
			this->rdbCube2 = new System::Windows::Forms::RadioButton();
			this->rdbSphere2 = new System::Windows::Forms::RadioButton();
			this->groupBox13 = new System::Windows::Forms::GroupBox();
			this->txtRotZ1 = new System::Windows::Forms::TextBox();
			this->txtRotY1 = new System::Windows::Forms::TextBox();
			this->txtRotX1 = new System::Windows::Forms::TextBox();
			this->btnRotZ1 = new System::Windows::Forms::Button();
			this->btnRotY1 = new System::Windows::Forms::Button();
			this->btnRotX1 = new System::Windows::Forms::Button();
			this->txtTransZ1 = new System::Windows::Forms::TextBox();
			this->txtTransY1 = new System::Windows::Forms::TextBox();
			this->txtTransX1 = new System::Windows::Forms::TextBox();
			this->btnTransZ1 = new System::Windows::Forms::Button();
			this->btnTransY1 = new System::Windows::Forms::Button();
			this->btnTransX1 = new System::Windows::Forms::Button();
			this->txtScalingZ1 = new System::Windows::Forms::TextBox();
			this->txtScalingY1 = new System::Windows::Forms::TextBox();
			this->btnScalingZ1 = new System::Windows::Forms::Button();
			this->btnScalingY1 = new System::Windows::Forms::Button();
			this->txtScalingX1 = new System::Windows::Forms::TextBox();
			this->btnScalingX1 = new System::Windows::Forms::Button();
			this->label11 = new System::Windows::Forms::Label();
			this->label10 = new System::Windows::Forms::Label();
			this->label9 = new System::Windows::Forms::Label();
			this->groupBox14 = new System::Windows::Forms::GroupBox();
			this->txtRotZ2 = new System::Windows::Forms::TextBox();
			this->txtRotY2 = new System::Windows::Forms::TextBox();
			this->txtRotX2 = new System::Windows::Forms::TextBox();
			this->btnRotZ2 = new System::Windows::Forms::Button();
			this->btnRotY2 = new System::Windows::Forms::Button();
			this->btnRotX2 = new System::Windows::Forms::Button();
			this->txtTransZ2 = new System::Windows::Forms::TextBox();
			this->txtTransY2 = new System::Windows::Forms::TextBox();
			this->txtTransX2 = new System::Windows::Forms::TextBox();
			this->btnTransZ2 = new System::Windows::Forms::Button();
			this->btnTransY2 = new System::Windows::Forms::Button();
			this->btnTransX2 = new System::Windows::Forms::Button();
			this->txtScalingZ2 = new System::Windows::Forms::TextBox();
			this->txtScalingY2 = new System::Windows::Forms::TextBox();
			this->txtScalingX2 = new System::Windows::Forms::TextBox();
			this->btnScalingZ2 = new System::Windows::Forms::Button();
			this->btnScalingY2 = new System::Windows::Forms::Button();
			this->btnScalingX2 = new System::Windows::Forms::Button();
			this->label14 = new System::Windows::Forms::Label();
			this->label13 = new System::Windows::Forms::Label();
			this->label12 = new System::Windows::Forms::Label();
			this->label15 = new System::Windows::Forms::Label();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox12->SuspendLayout();
			this->groupBox10->SuspendLayout();
			this->groupBox9->SuspendLayout();
			this->groupBox8->SuspendLayout();
			this->groupBox7->SuspendLayout();
			this->groupBox6->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->groupBox11->SuspendLayout();
			this->groupBox13->SuspendLayout();
			this->groupBox14->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->rdbNo2);
			this->groupBox2->Controls->Add(this->rdbNo1);
			this->groupBox2->Controls->Add(this->chkTrack);
			this->groupBox2->Controls->Add(this->btnCrane);
			this->groupBox2->Controls->Add(this->btnTilt);
			this->groupBox2->Controls->Add(this->btnTumble);
			this->groupBox2->Controls->Add(this->btnPan);
			this->groupBox2->Controls->Add(this->btnZoom);
			this->groupBox2->Controls->Add(this->btnDolly);
			this->groupBox2->Location = System::Drawing::Point(232, 320);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(200, 96);
			this->groupBox2->TabIndex = 23;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Camera";
			// 
			// rdbNo2
			// 
			this->rdbNo2->Location = System::Drawing::Point(136, 64);
			this->rdbNo2->Name = S"rdbNo2";
			this->rdbNo2->Size = System::Drawing::Size(48, 16);
			this->rdbNo2->TabIndex = 8;
			this->rdbNo2->Text = S"#2";
			// 
			// rdbNo1
			// 
			this->rdbNo1->Checked = true;
			this->rdbNo1->Location = System::Drawing::Point(136, 40);
			this->rdbNo1->Name = S"rdbNo1";
			this->rdbNo1->Size = System::Drawing::Size(48, 16);
			this->rdbNo1->TabIndex = 7;
			this->rdbNo1->TabStop = true;
			this->rdbNo1->Text = S"#1";
			// 
			// chkTrack
			// 
			this->chkTrack->Location = System::Drawing::Point(125, 16);
			this->chkTrack->Name = S"chkTrack";
			this->chkTrack->Size = System::Drawing::Size(67, 24);
			this->chkTrack->TabIndex = 6;
			this->chkTrack->Text = S"Track";
			this->chkTrack->CheckedChanged += new System::EventHandler(this, &Form1::chkTrack_CheckedChanged);
			// 
			// btnCrane
			// 
			this->btnCrane->Location = System::Drawing::Point(56, 62);
			this->btnCrane->Name = S"btnCrane";
			this->btnCrane->Size = System::Drawing::Size(64, 21);
			this->btnCrane->TabIndex = 5;
			this->btnCrane->Text = S"Crane";
			this->btnCrane->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnCrane_MouseDown);
			// 
			// btnTilt
			// 
			this->btnTilt->Location = System::Drawing::Point(8, 62);
			this->btnTilt->Name = S"btnTilt";
			this->btnTilt->Size = System::Drawing::Size(48, 21);
			this->btnTilt->TabIndex = 4;
			this->btnTilt->Text = S"Tilt";
			this->btnTilt->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTilt_MouseDown);
			// 
			// btnTumble
			// 
			this->btnTumble->Location = System::Drawing::Point(56, 40);
			this->btnTumble->Name = S"btnTumble";
			this->btnTumble->Size = System::Drawing::Size(64, 21);
			this->btnTumble->TabIndex = 3;
			this->btnTumble->Text = S"Tumble";
			this->btnTumble->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTumble_MouseDown);
			// 
			// btnPan
			// 
			this->btnPan->Location = System::Drawing::Point(8, 40);
			this->btnPan->Name = S"btnPan";
			this->btnPan->Size = System::Drawing::Size(48, 21);
			this->btnPan->TabIndex = 2;
			this->btnPan->Text = S"Pan";
			this->btnPan->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnPan_MouseDown);
			// 
			// btnZoom
			// 
			this->btnZoom->Location = System::Drawing::Point(56, 18);
			this->btnZoom->Name = S"btnZoom";
			this->btnZoom->Size = System::Drawing::Size(64, 22);
			this->btnZoom->TabIndex = 1;
			this->btnZoom->Text = S"Zoom";
			this->btnZoom->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnZoom_MouseDown);
			// 
			// btnDolly
			// 
			this->btnDolly->Location = System::Drawing::Point(8, 18);
			this->btnDolly->Name = S"btnDolly";
			this->btnDolly->Size = System::Drawing::Size(48, 22);
			this->btnDolly->TabIndex = 0;
			this->btnDolly->Text = S"Dolly";
			this->btnDolly->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDolly_MouseDown);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->txtLightZ);
			this->groupBox3->Controls->Add(this->btnLightZ);
			this->groupBox3->Controls->Add(this->txtLightY);
			this->groupBox3->Controls->Add(this->btnLightY);
			this->groupBox3->Controls->Add(this->txtLightX);
			this->groupBox3->Controls->Add(this->btnLightX);
			this->groupBox3->Location = System::Drawing::Point(440, 320);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(80, 96);
			this->groupBox3->TabIndex = 24;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Light";
			// 
			// txtLightZ
			// 
			this->txtLightZ->Location = System::Drawing::Point(32, 64);
			this->txtLightZ->Name = S"txtLightZ";
			this->txtLightZ->Size = System::Drawing::Size(34, 22);
			this->txtLightZ->TabIndex = 5;
			this->txtLightZ->Text = S"";
			// 
			// btnLightZ
			// 
			this->btnLightZ->Location = System::Drawing::Point(8, 64);
			this->btnLightZ->Name = S"btnLightZ";
			this->btnLightZ->Size = System::Drawing::Size(24, 22);
			this->btnLightZ->TabIndex = 4;
			this->btnLightZ->Text = S"Z";
			this->btnLightZ->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightZ_MouseDown);
			// 
			// txtLightY
			// 
			this->txtLightY->Location = System::Drawing::Point(32, 40);
			this->txtLightY->Name = S"txtLightY";
			this->txtLightY->Size = System::Drawing::Size(33, 22);
			this->txtLightY->TabIndex = 3;
			this->txtLightY->Text = S"";
			// 
			// btnLightY
			// 
			this->btnLightY->Location = System::Drawing::Point(8, 40);
			this->btnLightY->Name = S"btnLightY";
			this->btnLightY->Size = System::Drawing::Size(24, 24);
			this->btnLightY->TabIndex = 2;
			this->btnLightY->Text = S"Y";
			this->btnLightY->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightY_MouseDown);
			// 
			// txtLightX
			// 
			this->txtLightX->Location = System::Drawing::Point(32, 16);
			this->txtLightX->Name = S"txtLightX";
			this->txtLightX->Size = System::Drawing::Size(32, 22);
			this->txtLightX->TabIndex = 1;
			this->txtLightX->Text = S"";
			// 
			// btnLightX
			// 
			this->btnLightX->Location = System::Drawing::Point(8, 16);
			this->btnLightX->Name = S"btnLightX";
			this->btnLightX->Size = System::Drawing::Size(24, 24);
			this->btnLightX->TabIndex = 0;
			this->btnLightX->Text = S"X";
			this->btnLightX->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightX_MouseDown);
			// 
			// chkWireframe
			// 
			this->chkWireframe->Location = System::Drawing::Point(80, 392);
			this->chkWireframe->Name = S"chkWireframe";
			this->chkWireframe->Size = System::Drawing::Size(96, 24);
			this->chkWireframe->TabIndex = 25;
			this->chkWireframe->Text = S"Wireframe";
			this->chkWireframe->CheckedChanged += new System::EventHandler(this, &Form1::chkWireframe_CheckedChanged);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->chkShadow);
			this->groupBox1->Controls->Add(this->txtGridWidth);
			this->groupBox1->Controls->Add(this->btnWidth);
			this->groupBox1->Controls->Add(this->rdbCheck);
			this->groupBox1->Controls->Add(this->rdbGrid);
			this->groupBox1->Controls->Add(this->rdbNon);
			this->groupBox1->Location = System::Drawing::Point(8, 320);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(216, 72);
			this->groupBox1->TabIndex = 22;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Floor";
			// 
			// chkShadow
			// 
			this->chkShadow->Location = System::Drawing::Point(120, 48);
			this->chkShadow->Name = S"chkShadow";
			this->chkShadow->Size = System::Drawing::Size(88, 16);
			this->chkShadow->TabIndex = 5;
			this->chkShadow->Text = S"Shadow";
			this->chkShadow->CheckedChanged += new System::EventHandler(this, &Form1::chkShadow_CheckedChanged);
			// 
			// txtGridWidth
			// 
			this->txtGridWidth->Location = System::Drawing::Point(64, 40);
			this->txtGridWidth->Name = S"txtGridWidth";
			this->txtGridWidth->Size = System::Drawing::Size(40, 22);
			this->txtGridWidth->TabIndex = 4;
			this->txtGridWidth->Text = S"";
			// 
			// btnWidth
			// 
			this->btnWidth->Location = System::Drawing::Point(8, 40);
			this->btnWidth->Name = S"btnWidth";
			this->btnWidth->Size = System::Drawing::Size(56, 24);
			this->btnWidth->TabIndex = 3;
			this->btnWidth->Text = S"Width";
			this->btnWidth->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnWidth_MouseDown);
			// 
			// rdbCheck
			// 
			this->rdbCheck->Location = System::Drawing::Point(136, 17);
			this->rdbCheck->Name = S"rdbCheck";
			this->rdbCheck->Size = System::Drawing::Size(72, 24);
			this->rdbCheck->TabIndex = 2;
			this->rdbCheck->Text = S"Check";
			this->rdbCheck->CheckedChanged += new System::EventHandler(this, &Form1::rdbCheck_CheckedChanged);
			// 
			// rdbGrid
			// 
			this->rdbGrid->Checked = true;
			this->rdbGrid->Location = System::Drawing::Point(76, 16);
			this->rdbGrid->Name = S"rdbGrid";
			this->rdbGrid->Size = System::Drawing::Size(72, 24);
			this->rdbGrid->TabIndex = 1;
			this->rdbGrid->TabStop = true;
			this->rdbGrid->Text = S"Grid";
			this->rdbGrid->CheckedChanged += new System::EventHandler(this, &Form1::rdbGrid_CheckedChanged);
			// 
			// rdbNon
			// 
			this->rdbNon->Location = System::Drawing::Point(16, 16);
			this->rdbNon->Name = S"rdbNon";
			this->rdbNon->Size = System::Drawing::Size(56, 24);
			this->rdbNon->TabIndex = 0;
			this->rdbNon->Text = S"Non";
			this->rdbNon->CheckedChanged += new System::EventHandler(this, &Form1::rdbNon_CheckedChanged);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->label15);
			this->groupBox4->Controls->Add(this->btnStep);
			this->groupBox4->Controls->Add(this->btnStop);
			this->groupBox4->Controls->Add(this->btnStart);
			this->groupBox4->Controls->Add(this->txtDeltaTime);
			this->groupBox4->Controls->Add(this->txtDrawTime);
			this->groupBox4->Controls->Add(this->label8);
			this->groupBox4->Controls->Add(this->label7);
			this->groupBox4->Controls->Add(this->txtNumThin);
			this->groupBox4->Controls->Add(this->label6);
			this->groupBox4->Controls->Add(this->txtNumFrame);
			this->groupBox4->Controls->Add(this->label5);
			this->groupBox4->Controls->Add(this->groupBox12);
			this->groupBox4->Controls->Add(this->groupBox10);
			this->groupBox4->Controls->Add(this->groupBox9);
			this->groupBox4->Controls->Add(this->groupBox8);
			this->groupBox4->Controls->Add(this->groupBox7);
			this->groupBox4->Controls->Add(this->groupBox6);
			this->groupBox4->Controls->Add(this->groupBox5);
			this->groupBox4->Controls->Add(this->btnReady);
			this->groupBox4->Controls->Add(this->groupBox11);
			this->groupBox4->Location = System::Drawing::Point(6, 0);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(530, 200);
			this->groupBox4->TabIndex = 26;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Animation";
			// 
			// btnStep
			// 
			this->btnStep->Location = System::Drawing::Point(464, 152);
			this->btnStep->Name = S"btnStep";
			this->btnStep->Size = System::Drawing::Size(56, 32);
			this->btnStep->TabIndex = 19;
			this->btnStep->Text = S"Step";
			this->btnStep->Click += new System::EventHandler(this, &Form1::btnStep_Click);
			// 
			// btnStop
			// 
			this->btnStop->Location = System::Drawing::Point(397, 152);
			this->btnStop->Name = S"btnStop";
			this->btnStop->Size = System::Drawing::Size(56, 32);
			this->btnStop->TabIndex = 18;
			this->btnStop->Text = S"Stop";
			this->btnStop->Click += new System::EventHandler(this, &Form1::btnStop_Click);
			// 
			// btnStart
			// 
			this->btnStart->Location = System::Drawing::Point(330, 152);
			this->btnStart->Name = S"btnStart";
			this->btnStart->Size = System::Drawing::Size(56, 32);
			this->btnStart->TabIndex = 17;
			this->btnStart->Text = S"Start";
			this->btnStart->Click += new System::EventHandler(this, &Form1::btnStart_Click);
			// 
			// txtDeltaTime
			// 
			this->txtDeltaTime->Location = System::Drawing::Point(432, 120);
			this->txtDeltaTime->Name = S"txtDeltaTime";
			this->txtDeltaTime->Size = System::Drawing::Size(72, 22);
			this->txtDeltaTime->TabIndex = 16;
			this->txtDeltaTime->Text = S"";
			// 
			// txtDrawTime
			// 
			this->txtDrawTime->BackColor = System::Drawing::SystemColors::Menu;
			this->txtDrawTime->Location = System::Drawing::Point(432, 96);
			this->txtDrawTime->Name = S"txtDrawTime";
			this->txtDrawTime->Size = System::Drawing::Size(72, 22);
			this->txtDrawTime->TabIndex = 15;
			this->txtDrawTime->Text = S"";
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(400, 120);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(38, 16);
			this->label8->TabIndex = 14;
			this->label8->Text = S"����";
			// 
			// label7
			// 
			this->label7->Location = System::Drawing::Point(400, 96);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(40, 16);
			this->label7->TabIndex = 13;
			this->label7->Text = S"�`��";
			// 
			// txtNumThin
			// 
			this->txtNumThin->Location = System::Drawing::Point(320, 120);
			this->txtNumThin->Name = S"txtNumThin";
			this->txtNumThin->Size = System::Drawing::Size(40, 22);
			this->txtNumThin->TabIndex = 12;
			this->txtNumThin->Text = S"";
			// 
			// label6
			// 
			this->label6->Location = System::Drawing::Point(312, 99);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(80, 16);
			this->label6->TabIndex = 11;
			this->label6->Text = S"�Ԉ����\��";
			// 
			// txtNumFrame
			// 
			this->txtNumFrame->BackColor = System::Drawing::SystemColors::Menu;
			this->txtNumFrame->Location = System::Drawing::Point(248, 167);
			this->txtNumFrame->Name = S"txtNumFrame";
			this->txtNumFrame->Size = System::Drawing::Size(56, 22);
			this->txtNumFrame->TabIndex = 10;
			this->txtNumFrame->Text = S"";
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(208, 171);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(48, 24);
			this->label5->TabIndex = 9;
			this->label5->Text = S"�R�}��";
			// 
			// groupBox12
			// 
			this->groupBox12->Controls->Add(this->txtMuFloor);
			this->groupBox12->Controls->Add(this->txtMuRigid);
			this->groupBox12->Controls->Add(this->label4);
			this->groupBox12->Controls->Add(this->label3);
			this->groupBox12->Location = System::Drawing::Point(200, 94);
			this->groupBox12->Name = S"groupBox12";
			this->groupBox12->Size = System::Drawing::Size(104, 72);
			this->groupBox12->TabIndex = 8;
			this->groupBox12->TabStop = false;
			this->groupBox12->Text = S"�����C�W��";
			// 
			// txtMuFloor
			// 
			this->txtMuFloor->Location = System::Drawing::Point(48, 42);
			this->txtMuFloor->Name = S"txtMuFloor";
			this->txtMuFloor->Size = System::Drawing::Size(48, 22);
			this->txtMuFloor->TabIndex = 3;
			this->txtMuFloor->Text = S"";
			// 
			// txtMuRigid
			// 
			this->txtMuRigid->Location = System::Drawing::Point(48, 20);
			this->txtMuRigid->Name = S"txtMuRigid";
			this->txtMuRigid->Size = System::Drawing::Size(48, 22);
			this->txtMuRigid->TabIndex = 2;
			this->txtMuRigid->Text = S"";
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(16, 42);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(24, 16);
			this->label4->TabIndex = 1;
			this->label4->Text = S"��";
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(8, 22);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(48, 24);
			this->label3->TabIndex = 0;
			this->label3->Text = S"����";
			// 
			// groupBox10
			// 
			this->groupBox10->Controls->Add(this->rdbCylinder1);
			this->groupBox10->Controls->Add(this->rdbCube1);
			this->groupBox10->Controls->Add(this->rdbSphere1);
			this->groupBox10->Location = System::Drawing::Point(9, 94);
			this->groupBox10->Name = S"groupBox10";
			this->groupBox10->Size = System::Drawing::Size(183, 48);
			this->groupBox10->TabIndex = 6;
			this->groupBox10->TabStop = false;
			this->groupBox10->Text = S"#1";
			// 
			// rdbCylinder1
			// 
			this->rdbCylinder1->Location = System::Drawing::Point(123, 18);
			this->rdbCylinder1->Name = S"rdbCylinder1";
			this->rdbCylinder1->Size = System::Drawing::Size(58, 24);
			this->rdbCylinder1->TabIndex = 2;
			this->rdbCylinder1->Text = S"�~��";
			// 
			// rdbCube1
			// 
			this->rdbCube1->Checked = true;
			this->rdbCube1->Location = System::Drawing::Point(50, 19);
			this->rdbCube1->Name = S"rdbCube1";
			this->rdbCube1->Size = System::Drawing::Size(78, 20);
			this->rdbCube1->TabIndex = 1;
			this->rdbCube1->TabStop = true;
			this->rdbCube1->Text = S"������";
			// 
			// rdbSphere1
			// 
			this->rdbSphere1->Location = System::Drawing::Point(8, 17);
			this->rdbSphere1->Name = S"rdbSphere1";
			this->rdbSphere1->Size = System::Drawing::Size(40, 24);
			this->rdbSphere1->TabIndex = 0;
			this->rdbSphere1->Text = S"��";
			// 
			// groupBox9
			// 
			this->groupBox9->Controls->Add(this->txtRestitutionFloor);
			this->groupBox9->Controls->Add(this->txtRestitutionRigid);
			this->groupBox9->Controls->Add(this->label2);
			this->groupBox9->Controls->Add(this->label1);
			this->groupBox9->Location = System::Drawing::Point(432, 14);
			this->groupBox9->Name = S"groupBox9";
			this->groupBox9->Size = System::Drawing::Size(88, 74);
			this->groupBox9->TabIndex = 5;
			this->groupBox9->TabStop = false;
			this->groupBox9->Text = S"�����W��";
			// 
			// txtRestitutionFloor
			// 
			this->txtRestitutionFloor->Location = System::Drawing::Point(40, 43);
			this->txtRestitutionFloor->Name = S"txtRestitutionFloor";
			this->txtRestitutionFloor->Size = System::Drawing::Size(40, 22);
			this->txtRestitutionFloor->TabIndex = 3;
			this->txtRestitutionFloor->Text = S"";
			// 
			// txtRestitutionRigid
			// 
			this->txtRestitutionRigid->Location = System::Drawing::Point(40, 21);
			this->txtRestitutionRigid->Name = S"txtRestitutionRigid";
			this->txtRestitutionRigid->Size = System::Drawing::Size(40, 22);
			this->txtRestitutionRigid->TabIndex = 2;
			this->txtRestitutionRigid->Text = S"";
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(8, 45);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(40, 24);
			this->label2->TabIndex = 1;
			this->label2->Text = S"��";
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(6, 23);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(40, 24);
			this->label1->TabIndex = 0;
			this->label1->Text = S"����";
			// 
			// groupBox8
			// 
			this->groupBox8->Controls->Add(this->txtMass2);
			this->groupBox8->Controls->Add(this->txtMass1);
			this->groupBox8->Location = System::Drawing::Point(352, 14);
			this->groupBox8->Name = S"groupBox8";
			this->groupBox8->Size = System::Drawing::Size(72, 74);
			this->groupBox8->TabIndex = 4;
			this->groupBox8->TabStop = false;
			this->groupBox8->Text = S"����Kg";
			// 
			// txtMass2
			// 
			this->txtMass2->Location = System::Drawing::Point(8, 44);
			this->txtMass2->Name = S"txtMass2";
			this->txtMass2->Size = System::Drawing::Size(56, 22);
			this->txtMass2->TabIndex = 1;
			this->txtMass2->Text = S"";
			// 
			// txtMass1
			// 
			this->txtMass1->Location = System::Drawing::Point(8, 22);
			this->txtMass1->Name = S"txtMass1";
			this->txtMass1->Size = System::Drawing::Size(56, 22);
			this->txtMass1->TabIndex = 0;
			this->txtMass1->Text = S"";
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->txtOmegaZ2);
			this->groupBox7->Controls->Add(this->txtOmegaZ1);
			this->groupBox7->Location = System::Drawing::Point(246, 14);
			this->groupBox7->Name = S"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(106, 74);
			this->groupBox7->TabIndex = 3;
			this->groupBox7->TabStop = false;
			this->groupBox7->Text = S"�p���xdeg/s";
			// 
			// txtOmegaZ2
			// 
			this->txtOmegaZ2->Location = System::Drawing::Point(8, 45);
			this->txtOmegaZ2->Name = S"txtOmegaZ2";
			this->txtOmegaZ2->Size = System::Drawing::Size(80, 22);
			this->txtOmegaZ2->TabIndex = 1;
			this->txtOmegaZ2->Text = S"";
			// 
			// txtOmegaZ1
			// 
			this->txtOmegaZ1->Location = System::Drawing::Point(8, 22);
			this->txtOmegaZ1->Name = S"txtOmegaZ1";
			this->txtOmegaZ1->Size = System::Drawing::Size(80, 22);
			this->txtOmegaZ1->TabIndex = 0;
			this->txtOmegaZ1->Text = S"";
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->txtDir2);
			this->groupBox6->Controls->Add(this->txtDir1);
			this->groupBox6->Location = System::Drawing::Point(160, 14);
			this->groupBox6->Name = S"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(80, 74);
			this->groupBox6->TabIndex = 2;
			this->groupBox6->TabStop = false;
			this->groupBox6->Text = S"����deg";
			// 
			// txtDir2
			// 
			this->txtDir2->Location = System::Drawing::Point(8, 45);
			this->txtDir2->Name = S"txtDir2";
			this->txtDir2->Size = System::Drawing::Size(56, 22);
			this->txtDir2->TabIndex = 1;
			this->txtDir2->Text = S"";
			// 
			// txtDir1
			// 
			this->txtDir1->Location = System::Drawing::Point(8, 22);
			this->txtDir1->Name = S"txtDir1";
			this->txtDir1->Size = System::Drawing::Size(56, 22);
			this->txtDir1->TabIndex = 0;
			this->txtDir1->Text = S"";
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->txtSpeed2);
			this->groupBox5->Controls->Add(this->txtSpeed1);
			this->groupBox5->Location = System::Drawing::Point(72, 14);
			this->groupBox5->Name = S"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(80, 74);
			this->groupBox5->TabIndex = 1;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = S"���xm/s";
			// 
			// txtSpeed2
			// 
			this->txtSpeed2->Location = System::Drawing::Point(8, 45);
			this->txtSpeed2->Name = S"txtSpeed2";
			this->txtSpeed2->Size = System::Drawing::Size(56, 22);
			this->txtSpeed2->TabIndex = 1;
			this->txtSpeed2->Text = S"";
			// 
			// txtSpeed1
			// 
			this->txtSpeed1->Location = System::Drawing::Point(8, 22);
			this->txtSpeed1->Name = S"txtSpeed1";
			this->txtSpeed1->Size = System::Drawing::Size(56, 22);
			this->txtSpeed1->TabIndex = 0;
			this->txtSpeed1->Text = S"";
			// 
			// btnReady
			// 
			this->btnReady->Location = System::Drawing::Point(8, 24);
			this->btnReady->Name = S"btnReady";
			this->btnReady->Size = System::Drawing::Size(56, 48);
			this->btnReady->TabIndex = 0;
			this->btnReady->Text = S"Ready";
			this->btnReady->Click += new System::EventHandler(this, &Form1::btnReady_Click);
			// 
			// groupBox11
			// 
			this->groupBox11->Controls->Add(this->rdbCylinder2);
			this->groupBox11->Controls->Add(this->rdbCube2);
			this->groupBox11->Controls->Add(this->rdbSphere2);
			this->groupBox11->Location = System::Drawing::Point(8, 146);
			this->groupBox11->Name = S"groupBox11";
			this->groupBox11->Size = System::Drawing::Size(184, 48);
			this->groupBox11->TabIndex = 7;
			this->groupBox11->TabStop = false;
			this->groupBox11->Text = S"#2";
			// 
			// rdbCylinder2
			// 
			this->rdbCylinder2->Location = System::Drawing::Point(123, 16);
			this->rdbCylinder2->Name = S"rdbCylinder2";
			this->rdbCylinder2->Size = System::Drawing::Size(58, 24);
			this->rdbCylinder2->TabIndex = 2;
			this->rdbCylinder2->Text = S"�~��";
			// 
			// rdbCube2
			// 
			this->rdbCube2->Checked = true;
			this->rdbCube2->Location = System::Drawing::Point(48, 16);
			this->rdbCube2->Name = S"rdbCube2";
			this->rdbCube2->Size = System::Drawing::Size(80, 24);
			this->rdbCube2->TabIndex = 1;
			this->rdbCube2->TabStop = true;
			this->rdbCube2->Text = S"������";
			// 
			// rdbSphere2
			// 
			this->rdbSphere2->Location = System::Drawing::Point(8, 16);
			this->rdbSphere2->Name = S"rdbSphere2";
			this->rdbSphere2->Size = System::Drawing::Size(40, 24);
			this->rdbSphere2->TabIndex = 0;
			this->rdbSphere2->Text = S"��";
			// 
			// groupBox13
			// 
			this->groupBox13->Controls->Add(this->txtRotZ1);
			this->groupBox13->Controls->Add(this->txtRotY1);
			this->groupBox13->Controls->Add(this->txtRotX1);
			this->groupBox13->Controls->Add(this->btnRotZ1);
			this->groupBox13->Controls->Add(this->btnRotY1);
			this->groupBox13->Controls->Add(this->btnRotX1);
			this->groupBox13->Controls->Add(this->txtTransZ1);
			this->groupBox13->Controls->Add(this->txtTransY1);
			this->groupBox13->Controls->Add(this->txtTransX1);
			this->groupBox13->Controls->Add(this->btnTransZ1);
			this->groupBox13->Controls->Add(this->btnTransY1);
			this->groupBox13->Controls->Add(this->btnTransX1);
			this->groupBox13->Controls->Add(this->txtScalingZ1);
			this->groupBox13->Controls->Add(this->txtScalingY1);
			this->groupBox13->Controls->Add(this->btnScalingZ1);
			this->groupBox13->Controls->Add(this->btnScalingY1);
			this->groupBox13->Controls->Add(this->txtScalingX1);
			this->groupBox13->Controls->Add(this->btnScalingX1);
			this->groupBox13->Controls->Add(this->label11);
			this->groupBox13->Controls->Add(this->label10);
			this->groupBox13->Controls->Add(this->label9);
			this->groupBox13->Location = System::Drawing::Point(24, 200);
			this->groupBox13->Name = S"groupBox13";
			this->groupBox13->Size = System::Drawing::Size(240, 120);
			this->groupBox13->TabIndex = 27;
			this->groupBox13->TabStop = false;
			this->groupBox13->Text = S"Affine#1";
			// 
			// txtRotZ1
			// 
			this->txtRotZ1->Location = System::Drawing::Point(192, 88);
			this->txtRotZ1->Name = S"txtRotZ1";
			this->txtRotZ1->Size = System::Drawing::Size(40, 22);
			this->txtRotZ1->TabIndex = 20;
			this->txtRotZ1->Text = S"";
			// 
			// txtRotY1
			// 
			this->txtRotY1->Location = System::Drawing::Point(192, 64);
			this->txtRotY1->Name = S"txtRotY1";
			this->txtRotY1->Size = System::Drawing::Size(40, 22);
			this->txtRotY1->TabIndex = 19;
			this->txtRotY1->Text = S"";
			// 
			// txtRotX1
			// 
			this->txtRotX1->Location = System::Drawing::Point(192, 40);
			this->txtRotX1->Name = S"txtRotX1";
			this->txtRotX1->Size = System::Drawing::Size(40, 22);
			this->txtRotX1->TabIndex = 18;
			this->txtRotX1->Text = S"";
			// 
			// btnRotZ1
			// 
			this->btnRotZ1->Location = System::Drawing::Point(168, 88);
			this->btnRotZ1->Name = S"btnRotZ1";
			this->btnRotZ1->Size = System::Drawing::Size(24, 24);
			this->btnRotZ1->TabIndex = 17;
			this->btnRotZ1->Text = S"Z";
			this->btnRotZ1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRotZ1_MouseDown);
			// 
			// btnRotY1
			// 
			this->btnRotY1->Location = System::Drawing::Point(168, 64);
			this->btnRotY1->Name = S"btnRotY1";
			this->btnRotY1->Size = System::Drawing::Size(24, 24);
			this->btnRotY1->TabIndex = 16;
			this->btnRotY1->Text = S"Y";
			this->btnRotY1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRotY1_MouseDown);
			// 
			// btnRotX1
			// 
			this->btnRotX1->Location = System::Drawing::Point(168, 40);
			this->btnRotX1->Name = S"btnRotX1";
			this->btnRotX1->Size = System::Drawing::Size(24, 24);
			this->btnRotX1->TabIndex = 15;
			this->btnRotX1->Text = S"X";
			this->btnRotX1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRotX1_MouseDown);
			// 
			// txtTransZ1
			// 
			this->txtTransZ1->Location = System::Drawing::Point(112, 88);
			this->txtTransZ1->Name = S"txtTransZ1";
			this->txtTransZ1->Size = System::Drawing::Size(40, 22);
			this->txtTransZ1->TabIndex = 14;
			this->txtTransZ1->Text = S"";
			// 
			// txtTransY1
			// 
			this->txtTransY1->Location = System::Drawing::Point(112, 64);
			this->txtTransY1->Name = S"txtTransY1";
			this->txtTransY1->Size = System::Drawing::Size(40, 22);
			this->txtTransY1->TabIndex = 13;
			this->txtTransY1->Text = S"";
			// 
			// txtTransX1
			// 
			this->txtTransX1->Location = System::Drawing::Point(112, 40);
			this->txtTransX1->Name = S"txtTransX1";
			this->txtTransX1->Size = System::Drawing::Size(40, 22);
			this->txtTransX1->TabIndex = 12;
			this->txtTransX1->Text = S"";
			// 
			// btnTransZ1
			// 
			this->btnTransZ1->Location = System::Drawing::Point(88, 88);
			this->btnTransZ1->Name = S"btnTransZ1";
			this->btnTransZ1->Size = System::Drawing::Size(24, 24);
			this->btnTransZ1->TabIndex = 11;
			this->btnTransZ1->Text = S"Z";
			this->btnTransZ1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTransZ1_MouseDown);
			// 
			// btnTransY1
			// 
			this->btnTransY1->Location = System::Drawing::Point(88, 64);
			this->btnTransY1->Name = S"btnTransY1";
			this->btnTransY1->Size = System::Drawing::Size(24, 24);
			this->btnTransY1->TabIndex = 10;
			this->btnTransY1->Text = S"Y";
			this->btnTransY1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTransY1_MouseDown);
			// 
			// btnTransX1
			// 
			this->btnTransX1->Location = System::Drawing::Point(88, 40);
			this->btnTransX1->Name = S"btnTransX1";
			this->btnTransX1->Size = System::Drawing::Size(24, 24);
			this->btnTransX1->TabIndex = 9;
			this->btnTransX1->Text = S"X";
			this->btnTransX1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTransX1_MouseDown);
			// 
			// txtScalingZ1
			// 
			this->txtScalingZ1->Location = System::Drawing::Point(32, 88);
			this->txtScalingZ1->Name = S"txtScalingZ1";
			this->txtScalingZ1->Size = System::Drawing::Size(40, 22);
			this->txtScalingZ1->TabIndex = 8;
			this->txtScalingZ1->Text = S"";
			// 
			// txtScalingY1
			// 
			this->txtScalingY1->Location = System::Drawing::Point(32, 64);
			this->txtScalingY1->Name = S"txtScalingY1";
			this->txtScalingY1->Size = System::Drawing::Size(40, 22);
			this->txtScalingY1->TabIndex = 7;
			this->txtScalingY1->Text = S"";
			// 
			// btnScalingZ1
			// 
			this->btnScalingZ1->Location = System::Drawing::Point(8, 88);
			this->btnScalingZ1->Name = S"btnScalingZ1";
			this->btnScalingZ1->Size = System::Drawing::Size(24, 24);
			this->btnScalingZ1->TabIndex = 6;
			this->btnScalingZ1->Text = S"Z";
			this->btnScalingZ1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnScalingZ1_MouseDown);
			// 
			// btnScalingY1
			// 
			this->btnScalingY1->Location = System::Drawing::Point(8, 64);
			this->btnScalingY1->Name = S"btnScalingY1";
			this->btnScalingY1->Size = System::Drawing::Size(24, 24);
			this->btnScalingY1->TabIndex = 5;
			this->btnScalingY1->Text = S"Y";
			this->btnScalingY1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnScalingY1_MouseDown);
			// 
			// txtScalingX1
			// 
			this->txtScalingX1->Location = System::Drawing::Point(32, 40);
			this->txtScalingX1->Name = S"txtScalingX1";
			this->txtScalingX1->Size = System::Drawing::Size(40, 22);
			this->txtScalingX1->TabIndex = 4;
			this->txtScalingX1->Text = S"";
			// 
			// btnScalingX1
			// 
			this->btnScalingX1->Location = System::Drawing::Point(8, 40);
			this->btnScalingX1->Name = S"btnScalingX1";
			this->btnScalingX1->Size = System::Drawing::Size(24, 24);
			this->btnScalingX1->TabIndex = 3;
			this->btnScalingX1->Text = S"X";
			this->btnScalingX1->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnScalingX1_MouseDown);
			// 
			// label11
			// 
			this->label11->Location = System::Drawing::Point(167, 20);
			this->label11->Name = S"label11";
			this->label11->Size = System::Drawing::Size(64, 16);
			this->label11->TabIndex = 2;
			this->label11->Text = S"Rotation";
			// 
			// label10
			// 
			this->label10->Location = System::Drawing::Point(79, 20);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(80, 16);
			this->label10->TabIndex = 1;
			this->label10->Text = S"Translation";
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(8, 20);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(56, 16);
			this->label9->TabIndex = 0;
			this->label9->Text = S"Scaling";
			// 
			// groupBox14
			// 
			this->groupBox14->Controls->Add(this->txtRotZ2);
			this->groupBox14->Controls->Add(this->txtRotY2);
			this->groupBox14->Controls->Add(this->txtRotX2);
			this->groupBox14->Controls->Add(this->btnRotZ2);
			this->groupBox14->Controls->Add(this->btnRotY2);
			this->groupBox14->Controls->Add(this->btnRotX2);
			this->groupBox14->Controls->Add(this->txtTransZ2);
			this->groupBox14->Controls->Add(this->txtTransY2);
			this->groupBox14->Controls->Add(this->txtTransX2);
			this->groupBox14->Controls->Add(this->btnTransZ2);
			this->groupBox14->Controls->Add(this->btnTransY2);
			this->groupBox14->Controls->Add(this->btnTransX2);
			this->groupBox14->Controls->Add(this->txtScalingZ2);
			this->groupBox14->Controls->Add(this->txtScalingY2);
			this->groupBox14->Controls->Add(this->txtScalingX2);
			this->groupBox14->Controls->Add(this->btnScalingZ2);
			this->groupBox14->Controls->Add(this->btnScalingY2);
			this->groupBox14->Controls->Add(this->btnScalingX2);
			this->groupBox14->Controls->Add(this->label14);
			this->groupBox14->Controls->Add(this->label13);
			this->groupBox14->Controls->Add(this->label12);
			this->groupBox14->Location = System::Drawing::Point(280, 200);
			this->groupBox14->Name = S"groupBox14";
			this->groupBox14->Size = System::Drawing::Size(240, 120);
			this->groupBox14->TabIndex = 28;
			this->groupBox14->TabStop = false;
			this->groupBox14->Text = S"Affine#2";
			// 
			// txtRotZ2
			// 
			this->txtRotZ2->Location = System::Drawing::Point(192, 88);
			this->txtRotZ2->Name = S"txtRotZ2";
			this->txtRotZ2->Size = System::Drawing::Size(40, 22);
			this->txtRotZ2->TabIndex = 20;
			this->txtRotZ2->Text = S"";
			// 
			// txtRotY2
			// 
			this->txtRotY2->Location = System::Drawing::Point(192, 64);
			this->txtRotY2->Name = S"txtRotY2";
			this->txtRotY2->Size = System::Drawing::Size(40, 22);
			this->txtRotY2->TabIndex = 19;
			this->txtRotY2->Text = S"";
			// 
			// txtRotX2
			// 
			this->txtRotX2->Location = System::Drawing::Point(192, 40);
			this->txtRotX2->Name = S"txtRotX2";
			this->txtRotX2->Size = System::Drawing::Size(40, 22);
			this->txtRotX2->TabIndex = 18;
			this->txtRotX2->Text = S"";
			// 
			// btnRotZ2
			// 
			this->btnRotZ2->Location = System::Drawing::Point(168, 88);
			this->btnRotZ2->Name = S"btnRotZ2";
			this->btnRotZ2->Size = System::Drawing::Size(24, 24);
			this->btnRotZ2->TabIndex = 17;
			this->btnRotZ2->Text = S"Z";
			this->btnRotZ2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRotZ2_MouseDown);
			// 
			// btnRotY2
			// 
			this->btnRotY2->Location = System::Drawing::Point(168, 64);
			this->btnRotY2->Name = S"btnRotY2";
			this->btnRotY2->Size = System::Drawing::Size(24, 24);
			this->btnRotY2->TabIndex = 16;
			this->btnRotY2->Text = S"Y";
			this->btnRotY2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRotY2_MouseDown);
			// 
			// btnRotX2
			// 
			this->btnRotX2->Location = System::Drawing::Point(168, 40);
			this->btnRotX2->Name = S"btnRotX2";
			this->btnRotX2->Size = System::Drawing::Size(24, 24);
			this->btnRotX2->TabIndex = 15;
			this->btnRotX2->Text = S"X";
			this->btnRotX2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRotX2_MouseDown);
			// 
			// txtTransZ2
			// 
			this->txtTransZ2->Location = System::Drawing::Point(112, 88);
			this->txtTransZ2->Name = S"txtTransZ2";
			this->txtTransZ2->Size = System::Drawing::Size(40, 22);
			this->txtTransZ2->TabIndex = 14;
			this->txtTransZ2->Text = S"";
			// 
			// txtTransY2
			// 
			this->txtTransY2->Location = System::Drawing::Point(112, 64);
			this->txtTransY2->Name = S"txtTransY2";
			this->txtTransY2->Size = System::Drawing::Size(40, 22);
			this->txtTransY2->TabIndex = 13;
			this->txtTransY2->Text = S"";
			// 
			// txtTransX2
			// 
			this->txtTransX2->Location = System::Drawing::Point(112, 40);
			this->txtTransX2->Name = S"txtTransX2";
			this->txtTransX2->Size = System::Drawing::Size(40, 22);
			this->txtTransX2->TabIndex = 12;
			this->txtTransX2->Text = S"";
			// 
			// btnTransZ2
			// 
			this->btnTransZ2->Location = System::Drawing::Point(88, 88);
			this->btnTransZ2->Name = S"btnTransZ2";
			this->btnTransZ2->Size = System::Drawing::Size(24, 24);
			this->btnTransZ2->TabIndex = 11;
			this->btnTransZ2->Text = S"Z";
			this->btnTransZ2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTransZ2_MouseDown);
			// 
			// btnTransY2
			// 
			this->btnTransY2->Location = System::Drawing::Point(88, 64);
			this->btnTransY2->Name = S"btnTransY2";
			this->btnTransY2->Size = System::Drawing::Size(24, 24);
			this->btnTransY2->TabIndex = 10;
			this->btnTransY2->Text = S"Y";
			this->btnTransY2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTransY2_MouseDown);
			// 
			// btnTransX2
			// 
			this->btnTransX2->Location = System::Drawing::Point(88, 40);
			this->btnTransX2->Name = S"btnTransX2";
			this->btnTransX2->Size = System::Drawing::Size(24, 24);
			this->btnTransX2->TabIndex = 9;
			this->btnTransX2->Text = S"X";
			this->btnTransX2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTransX2_MouseDown);
			// 
			// txtScalingZ2
			// 
			this->txtScalingZ2->Location = System::Drawing::Point(32, 88);
			this->txtScalingZ2->Name = S"txtScalingZ2";
			this->txtScalingZ2->Size = System::Drawing::Size(40, 22);
			this->txtScalingZ2->TabIndex = 8;
			this->txtScalingZ2->Text = S"";
			// 
			// txtScalingY2
			// 
			this->txtScalingY2->Location = System::Drawing::Point(32, 64);
			this->txtScalingY2->Name = S"txtScalingY2";
			this->txtScalingY2->Size = System::Drawing::Size(40, 22);
			this->txtScalingY2->TabIndex = 7;
			this->txtScalingY2->Text = S"";
			// 
			// txtScalingX2
			// 
			this->txtScalingX2->Location = System::Drawing::Point(32, 40);
			this->txtScalingX2->Name = S"txtScalingX2";
			this->txtScalingX2->Size = System::Drawing::Size(40, 22);
			this->txtScalingX2->TabIndex = 6;
			this->txtScalingX2->Text = S"";
			// 
			// btnScalingZ2
			// 
			this->btnScalingZ2->Location = System::Drawing::Point(8, 88);
			this->btnScalingZ2->Name = S"btnScalingZ2";
			this->btnScalingZ2->Size = System::Drawing::Size(24, 24);
			this->btnScalingZ2->TabIndex = 5;
			this->btnScalingZ2->Text = S"Z";
			this->btnScalingZ2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnScalingZ2_MouseDown);
			// 
			// btnScalingY2
			// 
			this->btnScalingY2->Location = System::Drawing::Point(8, 64);
			this->btnScalingY2->Name = S"btnScalingY2";
			this->btnScalingY2->Size = System::Drawing::Size(24, 24);
			this->btnScalingY2->TabIndex = 4;
			this->btnScalingY2->Text = S"Y";
			this->btnScalingY2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnScalingY2_MouseDown);
			// 
			// btnScalingX2
			// 
			this->btnScalingX2->Location = System::Drawing::Point(8, 40);
			this->btnScalingX2->Name = S"btnScalingX2";
			this->btnScalingX2->Size = System::Drawing::Size(24, 24);
			this->btnScalingX2->TabIndex = 3;
			this->btnScalingX2->Text = S"X";
			this->btnScalingX2->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnScalingX2_MouseDown);
			// 
			// label14
			// 
			this->label14->Location = System::Drawing::Point(164, 20);
			this->label14->Name = S"label14";
			this->label14->Size = System::Drawing::Size(64, 16);
			this->label14->TabIndex = 2;
			this->label14->Text = S"Rotation";
			// 
			// label13
			// 
			this->label13->Location = System::Drawing::Point(76, 20);
			this->label13->Name = S"label13";
			this->label13->Size = System::Drawing::Size(80, 16);
			this->label13->TabIndex = 1;
			this->label13->Text = S"Translation";
			// 
			// label12
			// 
			this->label12->Location = System::Drawing::Point(8, 20);
			this->label12->Name = S"label12";
			this->label12->Size = System::Drawing::Size(56, 16);
			this->label12->TabIndex = 0;
			this->label12->Text = S"Scaling";
			// 
			// label15
			// 
			this->label15->Location = System::Drawing::Point(504, 112);
			this->label15->Name = S"label15";
			this->label15->Size = System::Drawing::Size(24, 16);
			this->label15->TabIndex = 20;
			this->label15->Text = S"s";
			// 
			// Form1
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(7, 15);
			this->ClientSize = System::Drawing::Size(544, 419);
			this->Controls->Add(this->groupBox14);
			this->Controls->Add(this->groupBox13);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->chkWireframe);
			this->Controls->Add(this->groupBox1);
			this->Name = S"Form1";
			this->Text = S"Collision3";
			this->Load += new System::EventHandler(this, &Form1::Form1_Load);
			this->groupBox2->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox12->ResumeLayout(false);
			this->groupBox10->ResumeLayout(false);
			this->groupBox9->ResumeLayout(false);
			this->groupBox8->ResumeLayout(false);
			this->groupBox7->ResumeLayout(false);
			this->groupBox6->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->groupBox11->ResumeLayout(false);
			this->groupBox13->ResumeLayout(false);
			this->groupBox14->ResumeLayout(false);
			this->ResumeLayout(false);

		}	


	
	//��������ǉ�
	SpaceForm* spaceForm;//�R�����`��t�H�[���̃C���X�^���X
	bool flagStart;//�A�j���[�V�������s�t���O
	bool flagStep;
	double muRigid;
	double muFloor;
	double eRigid;
	double eFloor;
	double cv, ci;
	float t;//���̎��Ԍo�߁i���ԍ���dt�̘a�j
	int numThin;//�Ԉ����Ԋu
	int numFrame;//���R�}��
	int count;//���s��
	private: System::Void Form1_Load(System::Object *  sender, System::EventArgs *  e)
	{
		//Form�̈ʒu
		Left = 50;
		Top = 100;
		//SpaceForm��\��
		spaceForm = new SpaceForm();
		spaceForm -> Show();
		//Floor�̏����l
		gridWidth = 1.0;
        txtGridWidth->Text = gridWidth.ToString();

		txtDeltaTime->Text = S"0.001";//�������ԑ���(s)
		txtNumThin->Text = S"50";//�Ԉ����\���Ԋu
		//���x�ƕ����̏����ݒ�
		txtSpeed1->Text = S"5.0";
		txtSpeed2->Text = S"5.0";
		txtDir1->Text = S"0.0";
		txtDir2->Text = S"180.0";
		txtOmegaZ1->Text = S"0.0";
		txtOmegaZ2->Text = S"0.0";
		txtMuRigid->Text = S"0.1";//���̓��m�̓����C��R
		txtMuFloor->Text = S"0.5"; //���ɂ����铮���C��R
		txtRestitutionRigid->Text = S"0.5";
		txtRestitutionFloor->Text = S"0.5";
		txtMass1->Text = S"1.0";
		txtMass2->Text = S"1.0";
		count = 0;//���s��
		//�����ʒu(setup.h��CLight�N���X�Őݒ�j
        txtLightX->Text = light.x.ToString();
        txtLightY->Text = light.y.ToString();
        txtLightZ->Text = light.z.ToString();
	}

	private: System::Void btnReady_Click(System::Object *  sender, System::EventArgs *  e)
	{

		//OpenGL����
		IntPtr ptr = spaceForm->picSpace->Handle;//�f�o�C�X�R���e�L�X�g�̃n���h��
		hWnd = (HWND)ptr.ToInt32();
		hDC = GetDC(hWnd);
		setup.initOpenGL();

	    if(count >= 1) goto jump;
		
		//�`��I�u�W�F�N�g
		numTarget = 2;
		target[0].vSize = CVector(0.5, 0.5, 0.5);
		target[0].vEuler = CVector();
		target[0].num1 = 20;
		target[0].num2 = 20;

		target[0].diffuse[0] = 0.7f; //red
		target[0].diffuse[1] = 1.0f;
		target[0].diffuse[2] = 0.9f;

		target[1].vSize = CVector(0.5f, 0.5f, 0.5f);//CVector(2.5, 2.5, 0.5);//
		target[1].vEuler = CVector();
		target[1].num1 = 20;
		target[1].num2 = 20;
		target[1].diffuse[0] = 0.8f;
		target[1].diffuse[1] = 1.0f;
		target[1].diffuse[2] = 1.0f;
		//�ʒu
		target[0].vPos = CVector(-1.0f, 0.0f, 2.0f);
		target[1].vPos = CVector( 1.0f, 0.0f, 2.0f);
		//Text�\��
		txtGridWidth->Text = gridWidth.ToString();
		txtLightX->Text = light.x.ToString();
		txtLightY->Text = light.y.ToString();
		txtLightZ->Text = light.z.ToString();

		txtScalingX1->Text = target[0].vSize.x.ToString();
		txtScalingY1->Text = target[0].vSize.y.ToString();
		txtScalingZ1->Text = target[0].vSize.z.ToString();
		txtTransX1->Text = target[0].vPos.x.ToString();
		txtTransY1->Text = target[0].vPos.y.ToString();
		txtTransZ1->Text = target[0].vPos.z.ToString();
		txtRotX1->Text = target[0].vEuler.x.ToString();
		txtRotY1->Text = target[0].vEuler.y.ToString();
		txtRotZ1->Text = target[0].vEuler.z.ToString();

		txtScalingX2->Text = target[1].vSize.x.ToString();
		txtScalingY2->Text = target[1].vSize.y.ToString();
		txtScalingZ2->Text = target[1].vSize.z.ToString();
		txtTransX2->Text = target[1].vPos.x.ToString();
		txtTransY2->Text = target[1].vPos.y.ToString();
		txtTransZ2->Text = target[1].vPos.z.ToString();
		txtRotX2->Text = target[1].vEuler.x.ToString();
		txtRotY2->Text = target[1].vEuler.y.ToString();
		txtRotZ2->Text = target[1].vEuler.z.ToString();

jump:;
		//����#1(target[0]������#1�j
		if(rdbSphere1->Checked == true){
			target[0].kind = SPHERE; target[0].texType = T_SPHERICAL;
		}
		else if(rdbCube1->Checked == true){
			target[0].kind = CUBE; target[0].texType = T_PLANAR2;
		}
		else { //�~��
			target[0].kind = CYLINDER; target[0].texType = T_CYLINDRICAL;
		}
		target[0].texMode = T_MODULATE;

		Image* im0 = Image::FromFile("\\CPPNetOpenGL\\bmp128\\check1.bmp");
		Bitmap* bitmap0 = new Bitmap(im0);
		target[0].makeTexture(bitmap0);
		//����#2
		if(rdbSphere2->Checked == true){
			target[1].kind = SPHERE; target[1].texType = T_SPHERICAL;
		}
		else if(rdbCube2->Checked == true){
			target[1].kind = CUBE; target[1].texType = T_PLANAR2;
		}
		else { //�~��
			target[1].kind = CYLINDER; target[1].texType = T_CYLINDRICAL;
		}
		target[1].texMode = T_MODULATE;
		Image* im1 = Image::FromFile("\\CPPNetOpenGL\\bmp128\\checkMono1.bmp");
		Bitmap* bitmap1 = new Bitmap(im1);
		target[1].makeTexture(bitmap1);

		initObject();
		camera.reset(chkTrack, rdbNo1);
		flagStep = false;
		display();
		numFrame = 0;
		txtNumFrame->Text = numFrame.ToString();
		count ++;
	}

	private: System::Void initObject()
	{

		//�Q�̍���(������,��,�~���j�̏Փˁi��]����j
		double pp = (M_PI / 180.0);
		double g = 9.8f;//�d�͉����x

		//�����ݒ�
		target[0].speed = Convert::ToSingle(txtSpeed1->Text);//m/s
		target[1].speed = Convert::ToSingle(txtSpeed2->Text);
		target[0].dir = Convert::ToSingle(txtDir1->Text);
		target[1].dir = Convert::ToSingle(txtDir2->Text);
		muRigid =  Convert::ToSingle(txtMuRigid->Text);//�����C��R(���̓��m)
		muFloor =  Convert::ToSingle(txtMuFloor->Text);//�����C��R(���ƍ���)
		eRigid = Convert::ToSingle(txtRestitutionRigid->Text);//�����W��(���̓��m)
		eFloor = Convert::ToSingle(txtRestitutionFloor->Text);//�����W��(���ƍ���)
		cv = 0.0;//��C�̔S����R�W��
		ci = 0.0;//��C�̊�����R�W��

		//����
		target[0].mass = Convert::ToSingle(txtMass1->Text);
		target[1].mass = Convert::ToSingle(txtMass2->Text);
		//�T�C�Y�C�ʒu�C�p��
		target[0].vSize.x = Convert::ToSingle(txtScalingX1->Text);
		target[0].vSize.y = Convert::ToSingle(txtScalingY1->Text);
		target[0].vSize.z = Convert::ToSingle(txtScalingZ1->Text);
		target[0].vPos.x = Convert::ToSingle(txtTransX1->Text);
		target[0].vPos.y = Convert::ToSingle(txtTransY1->Text);
		target[0].vPos.z = Convert::ToSingle(txtTransZ1->Text);
		target[0].vEuler.x = Convert::ToSingle(txtRotX1->Text);
		target[0].vEuler.y = Convert::ToSingle(txtRotY1->Text);
		target[0].vEuler.z = Convert::ToSingle(txtRotZ1->Text);
		target[1].vSize.x = Convert::ToSingle(txtScalingX2->Text);
		target[1].vSize.y = Convert::ToSingle(txtScalingY2->Text);
		target[1].vSize.z = Convert::ToSingle(txtScalingZ2->Text);
		target[1].vPos.x = Convert::ToSingle(txtTransX2->Text);
		target[1].vPos.y = Convert::ToSingle(txtTransY2->Text);
		target[1].vPos.z = Convert::ToSingle(txtTransZ2->Text);
		target[1].vEuler.x = Convert::ToSingle(txtRotX2->Text);
		target[1].vEuler.y = Convert::ToSingle(txtRotY2->Text);
		target[1].vEuler.z = Convert::ToSingle(txtRotZ2->Text);
		//�����x�̊e����
		target[0].vVelocity0.x = target[0].speed * cos(target[0].dir * pp);
		target[0].vVelocity0.y = target[0].speed * sin(target[0].dir * pp);
		target[0].vVelocity0.z = 0.0f;
		target[0].vVelocity = target[0].vVelocity0;
		target[1].vVelocity0.x = target[1].speed * cos(target[1].dir * pp);
		target[1].vVelocity0.y = target[1].speed * sin(target[1].dir * pp);
		target[1].vVelocity0.z = 0.0f;
		target[1].vVelocity = target[1].vVelocity0;

		//�O��(��ɕ��̂ɂ�����O�́j
		target[0].vForce0 = CVector();
		target[1].vForce0 = CVector();
		target[0].vForce0.z = - g * (target[0].mass);
		target[1].vForce0.z = - g * (target[1].mass);
		//�p���x
		target[0].omega0 = Convert::ToSingle(txtOmegaZ1->Text) * pp;
		target[0].vAxis = CVector(0.0, 0.0, 1.0);
		target[1].omega0 = Convert::ToSingle(txtOmegaZ2->Text) * pp;
		target[1].vAxis = CVector(0.0, 0.0, 1.0);
		target[0].vOmega = target[0].omega0 * target[0].vAxis; //rad
		target[1].vOmega = target[1].omega0 * target[1].vAxis; //rad
	}

	private: System::Void Form1_Closed(System::Object *  sender, System::EventArgs *  e)
	{
 		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);
	}

	private: System::Void display()
	{
	    int i;
		setup.set3DAmbient(spaceForm->picSpace);
		setup.setLight();
		camera.reset(chkTrack, rdbNo1);//Track mode
		flagShadow = chkShadow->Checked;

		glClear(GL_COLOR_BUFFER_BIT); //�װ�ޯ̧��ر
		glClear(GL_DEPTH_BUFFER_BIT); //���߽�ޯ̧��ر
	    //���������̂�����Ƃ��͎���2�s���K�v
	    glCullFace(GL_BACK);   //���ʂ��폜
	    glEnable(GL_CULL_FACE);//���ʍ폜��L���ɂ���

		setup.drawFloor(rdbNon, rdbCheck);//setup.h

	    if(chkWireframe->Checked == true){//ܲ԰�ڰ�����
		    glPolygonMode(GL_FRONT,GL_LINE);
		    glPolygonMode(GL_BACK,GL_POINT);
	    }
				
		//�������̂�����Ƃ��͈ȉ��̂悤�ɕs�������̂��ɂ��ׂĕ`��
		for(i = 0; i < numTarget; i++) {
			if(target[i].diffuse[3] == 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_FALSE); //���߽�ޯ̧���������݋֎~
		glEnable(GL_BLEND);//��̧�����ިݸނ�L���ɂ���
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);//�F�����W�������߂�

		//���������̂�`��
		for(i=0;i<numTarget;i++) {
			if(target[i].diffuse[3] != 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_TRUE); //���߽�ޯ̧�̏������݂�����
		glDisable(GL_BLEND);

        setup.drawShadow();//setup.h

        glPopMatrix();
	    SwapBuffers(hDC);
    }

    private: System::Void rdbCheck_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbGrid_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbNon_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void btnWidth_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
         if(e->Button == MouseButtons::Left)
                gridWidth += 0.1f;
         else
                gridWidth -= 0.1f;
         txtGridWidth->Text = gridWidth.ToString();
         display();
    }

    private: System::Void chkShadow_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        flagShadow = chkShadow->Checked;
        display();
    }

    private: System::Void btnDolly_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.dist -= 0.5f;
        else
            camera.dist += 0.5f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnZoom_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.fov -= 0.1f;
        else
            camera.fov += 0.1f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnPan_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta += 1.0f; //deg
   	    else
            camera.theta -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTumble_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta -= 5.0f;
        else
            camera.theta += 5.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTilt_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 1.0f; //deg
   	    else
            camera.phi -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.vCenter.z = camera.vPos.z - camera.dist * sin(pp * camera.phi);
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnCrane_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 2.0f;
        else
            camera.phi -= 2.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnLightX_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.x += 1.0f;
        else
            light.x -= 1.0f;
        txtLightX->Text = String::Format("{0:0.0}", __box(light.x));

        display();
    }

    private: System::Void btnLightY_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.y += 1.0f;
        else
            light.y -= 1.0f;
        txtLightY->Text = String::Format("{0:0.0}", __box(light.y));

        display();
    }

    private: System::Void btnLightZ_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.z += 1.0f;
        else
            light.z -= 1.0f;
        txtLightZ->Text = String::Format("{0:0.0}", __box(light.z));

        display();
    }


	private: System::Void chkWireframe_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
        setup.initOpenGL(); //Mode�؂�ւ����ɂ͕K�v
        display();
	}
	private: System::Void btnStart_Click(System::Object *  sender, System::EventArgs *  e)
	{
		execute();
	}

	private: System::Void btnStop_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = false;
	}

	private: System::Void btnStep_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = true;
		flagStep = true;
		execute();
	}

	private: System::Void chkTrack_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
		camera.reset(chkTrack, rdbNo1);
		display();
	}

	private: System::Void execute()
	{
		float drawTime, lapse;
		int h1, m1, s1, ms1;
		int h2, m2, s2, ms2;
		float dt;//��������
//		float pp = 2.0 * M_PI;
		int i, k;
    
		//����
		dt = Convert::ToSingle(txtDeltaTime->Text);//�b�P�ʂŎw��

		txtDrawTime->Text = S" ";
		flagStart = true;

		Cursor = Cursors::AppStarting;//�J�[�\����ύX
		DateTime tStart = DateTime::Now;//���݂̎���
		h1 = tStart.Hour;
		m1 = tStart.Minute;
		s1 = tStart.Second;
		ms1 = tStart.Millisecond;

		numThin = Convert::ToInt32(txtNumThin->Text);
		float ddt = dt / (float)numThin;
		//�������[�����g
		for(i = 0; i < numTarget; i++) target[i].calcInertia();
		int numFrame0 = 0;
		while(true){
			for(k = 0; k < numThin; k++){
				//�X�V(�Փ˂��Ă��Ȃ��Ƃ��͕����^���j
				for(i = 0; i < numTarget; i++){
					target[i].vPos0 = target[i].vPos;
					target[i].projection(eFloor, muFloor, cv, ci, ddt);
				}
				decideCollision3D();//�Փ˔���
			}
			display();
			Application::DoEvents();//���̃C�x���g��t
			if( flagStart == false ) break;
			numFrame++;
			numFrame0++;
			if(flagStep == true) break;
		}

		Cursor = Cursors::Default;
		DateTime tStop = DateTime::Now;
		h2 = tStop.Hour;
		m2 = tStop.Minute;
		s2 = tStop.Second;
		ms2 = tStop.Millisecond;
		//�o�ߎ���(sec)
		lapse = (float)(h2-h1) * 3600.0f + (float)(m2-m1) * 60.0f + (float)(s2-s1) + (float)(ms2-ms1) / 1000.0f;
		//1�R�}������̕`�掞��(sec)
		drawTime = lapse / (float)numFrame0;
		txtDrawTime->Text = drawTime.ToString();//�e�L�X�g�{�b�N�X�ɕ\��
		txtNumFrame->Text = numFrame.ToString();//���R�}��
	}

private: System::Void decideCollision3D()
{
    //���̓��m�̏Փ�
    int i, j;
    double d, r[10];
    double rikiseki;
    double x, y, z;
    CVector vCollision;  //�Փ˓_
    double vn1, vn2;//�@�������C�ڐ������̑傫��
    double muc, B, m1, m2;// speed1, speed2;
    CVector vVelocityP1, vVelocityP2;//�������x
    CVector vNormal;//#1���猩���Փ˖ʂ̖@������(target[0]��#1)
    CVector vTangential;//, vRelative;
    CVector vDir, A1, A2, vRg1, vRg2,vPos1, vPos2;

    //���̂Ƃ݂Ȃ����Ƃ��̔��a(bounding sphere)
    for(i = 0; i < numTarget; i++){
        x = target[i].vSize.x;
        y = target[i].vSize.y;
        z = target[i].vSize.z;
        if( target[i].kind == CUBE)//������(�p��)
            r[i] = sqrt(x * x + y * y + z * z) / 2.0f;
        else if(target[i].kind == SPHERE) //��(�ȉ~���ɂ͑Ή����Ă��Ȃ�)
            r[i] = x / 2.0f;
        else//�~��
            r[i] = sqrt(x * x + z * z) / 2.0f;
    }

    for(i = 0; i < numTarget-1; i++)
    {
        for(j = i+1; j < numTarget; j++)
        {
            d = dist(target[i].vPos, target[j].vPos); //����

            if(d <= r[i] + r[j]) //bounding sphere�Ŕ���
            {   //�Փ˂̉\������
                if( checkCollision3D(i, j, vNormal) == false) continue;
                vRg1 = target[i].vGravityToPoint;
                vRg2 = target[j].vGravityToPoint;
                m1 = target[i].mass;
                m2 = target[j].mass;

                vVelocityP1 = target[i].vVelocity + (target[i].vOmega ^ vRg1);//���ʂ��ȗ�����Ɓ{���Ɍv�Z
                vn1 = vVelocityP1 * vNormal;
                vVelocityP2 = target[j].vVelocity + (target[j].vOmega ^ vRg2);
                vn2 = vVelocityP2 * vNormal;
//char buf[50];
                //�Փˉ���
                vTangential = vNormal ^ ((vVelocityP1 - vVelocityP2) ^ vNormal);
                vTangential.normalize();
                //�͐�
                rikiseki = - (eRigid + 1.0f) * (vn1 - vn2) / (1.0f/m1 + 1.0f/m2
                        + vNormal * ((target[i].mInertiaInverse*(vRg1^vNormal))^vRg1)
                        + vNormal * ((target[j].mInertiaInverse*(vRg2^vNormal))^vRg2));

                A1 = ((target[i].mInertiaInverse*(vRg1^vTangential))) ^ vRg1;
                A2 = ((target[j].mInertiaInverse*(vRg2^vTangential))) ^ vRg2;
                B = - (vTangential*(vVelocityP1-vVelocityP2))/( 1.0f/m1+1.0f/m2+vTangential*(A1+A2) );
                if(rikiseki == 0.0f)
                    muc = 1000.0f;//�傫�Ȓl��
                else
                    muc = fabs(B / rikiseki);
                //�V���x
                target[i].vVelocity += (rikiseki / target[i].mass) * vNormal;
                target[j].vVelocity -= (rikiseki / target[j].mass) * vNormal;
                //�V�p���x
                target[i].vOmega += target[i].mInertiaInverse * (vRg1 ^ vNormal) * rikiseki;//rad/s
                target[j].vOmega -= target[j].mInertiaInverse * (vRg2 ^ vNormal) * rikiseki;
                //���C�̉e��
                if(muRigid > muc)
                {
                    target[i].vVelocity += vTangential * B / m1;
                    target[j].vVelocity -= vTangential * B / m2;
                    target[i].vOmega += target[i].mInertiaInverse*(vRg1 ^ vTangential) * B;
                    target[j].vOmega -= target[j].mInertiaInverse*(vRg2 ^ vTangential) * B;
                }
                else
                {
                    target[i].vVelocity += (rikiseki / m1) * (muRigid*vTangential);
                    target[j].vVelocity -= (rikiseki / m2) * (muRigid*vTangential);
                    target[i].vOmega += target[i].mInertiaInverse * (vRg1 ^ (vTangential)) * muRigid*rikiseki;//rad/s
                    target[j].vOmega -= target[j].mInertiaInverse * (vRg2 ^ (vTangential)) * muRigid*rikiseki;
                }
                //��]���Ɗp���x
                target[i].omega0 = sqrt(target[i].vOmega.x*target[i].vOmega.x
                         + target[i].vOmega.y*target[i].vOmega.y
                         + target[i].vOmega.z*target[i].vOmega.z );
                if(target[i].omega0 != 0.0) target[i].vAxis = target[i].vOmega / target[i].omega0;

                target[j].omega0 = sqrt(target[j].vOmega.x*target[j].vOmega.x
                         + target[j].vOmega.y*target[j].vOmega.y
                         + target[j].vOmega.z*target[j].vOmega.z );
                if(target[j].omega0 != 0.0) target[j].vAxis = target[j].vOmega / target[j].omega0;

                //�ՓˑO�̈ʒu�ɖ߂��i�߂荞�ݖh�~�j
                target[i].vPos = target[i].vPos0;
                target[j].vPos = target[j].vPos0;

                //�Î~�ڐG��ԁi���ݍ��ݖh�~�j
                //��ɂ��鍄�̂�^��Ɏ����グ��
                if(target[i].vPos.z > target[j].vPos.z + target[i].vSize.z / 2.0)
                    target[i].vPos.z += 0.001f;//#i�����������グ��
                else if(target[j].vPos.z > target[i].vPos.z + target[j].vSize.z / 2.0)
                    target[j].vPos.z += 0.001f;
                else
                {   //���S�Ԃ����Ԓ�����݂��ɔ��Ε����ֈړ�
                    vDir = target[i].vPos >> target[j].vPos;
                    target[i].vPos -= vDir * 0.001f;
                    target[j].vPos += vDir * 0.001f;
                }
                //�������������Ƃ��͐Î~��Ԃɂ���
                if(target[i].vVelocity.magnitude() < 0.2f)
                    target[i].vVelocity = CVector(0.0f, 0.0f, 0.0f);
                if(target[i].omega0 < 1.0f * M_PI/180.0f) target[i].omega0 = 0.0;
                if(target[j].vVelocity.magnitude() < 0.2f)
                    target[j].vVelocity = CVector(0.0f, 0.0f, 0.0f);
                if(target[j].omega0 < 1.0f * M_PI/180.0f) target[j].omega0 = 0.0;
            }
        }//j
    }//i
}
//------------------------------------------------------------------------------
private: System::Boolean checkCollision3D(int i, int j, CVector &vNormal)
{
    //�R�����̂Q���̂̏Փ˔���
    //decideCollision()�̃T�u���[�`��
//char buf[50];
    if(target[i].kind == CUBE) //#0��������
    {
        if(target[j].kind == CUBE)//#1��������
        {
            if(target[i].collisionCubeToCube3(target[j], vNormal) == true) {
                return true;
            }
            //target[1]�����画��
            if(target[j].collisionCubeToCube3(target[i], vNormal) == true)
            {   //target[1]������݂��@��������target[0]������͔��Ε���
//MessageBox(NULL,"abc" ,"Collision",MB_OK);
                vNormal.reverse();
                return true;
            }
            return false;
        }

        else if(target[j].kind == SPHERE)//#1����
        {
            if(target[i].collisionCubeToSphere3(target[j], vNormal)==true) return true;
            //target[1]�����画��
            if(target[j].collisionSphereToCube3(target[i], vNormal)==true)
            {
                vNormal.reverse();
                return true;
            }
            return false;
        }
        else//�~��
        {
//MessageBox(NULL,"a" ,"Collision",MB_OK);
            if(target[i].collisionCubeToCylinder3(target[j], vNormal)==true) return true;
            //target[1]�����画��
            if(target[j].collisionCylinderToCube3(target[i], vNormal)==true)
            {
                vNormal.reverse();
//MessageBox(NULL,"xxx" ,"Collision",MB_OK);
                return true;
            }
            return false;
        }
    }

    else if(target[i].kind == SPHERE)//#0����
    {
        if(target[j].kind == CUBE)
        {
            if(target[i].collisionSphereToCube3(target[j], vNormal) == true) return true;
            if(target[j].collisionCubeToSphere3(target[i], vNormal) == true)
            {
                vNormal.reverse();
                return true;
            }
            return false;
        }
        else if(target[j].kind == SPHERE)//�����m
        {
            vNormal = target[i].vPos >> target[j].vPos;//��0���狅1�֌������P�ʖ@���x�N�g��
            //�d�S����Փ˓_�܂ł̃x�N�g��
            target[i].vGravityToPoint = (target[i].vSize.x/2.0f) * vNormal ;
            target[j].vGravityToPoint = (-target[j].vSize.x/2.0f) * vNormal ;
 //           if(target[i].collisionSphereToSphere3(target[j], vNormal) == true) return true;
            return true;
        }
        else//�~��
        {
            if(target[i].collisionSphereToCylinder3(target[j], vNormal) == true) return true;
            if(target[j].collisionCylinderToSphere3(target[i], vNormal) == true)
            {
                vNormal.reverse();
                return true;
            }
            return false;
        }
    }
    else if(target[i].kind == CYLINDER)//#0���~��
    {
        if(target[j].kind == CUBE)
        {
            if(target[i].collisionCylinderToCube3(target[j], vNormal) == true) return true;
            if(target[j].collisionCubeToCylinder3(target[i], vNormal) == true)
            {
                vNormal.reverse();
                return true;
            }
            return false;
        }
        else if(target[j].kind == SPHERE)
        {
            if(target[i].collisionCylinderToSphere3(target[j], vNormal) == true) return true;
            if(target[j].collisionSphereToCylinder3(target[i], vNormal) == true)
            {
                vNormal.reverse();
                return true;
            }
            return false;
        }
        else//�~�����m
        {
            if(target[i].collisionCylinderToCylinder3(target[j], vNormal) == true) return true;
            if(target[j].collisionCylinderToCylinder3(target[i], vNormal) == true)
            {
                vNormal.reverse();
                return true;
            }
            return false;
        }
    }
    return false;
}
//--------------------------------------------------------------------------------

	private: System::Void btnScalingX1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vSize.x += 0.1f;
		else
			target[0].vSize.x -= 0.1f;

		txtScalingX1->Text = target[0].vSize.x.ToString();

		display();
	}

	private: System::Void btnScalingY1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vSize.y += 0.1f;
		else
			target[0].vSize.y -= 0.1f;

		txtScalingY1->Text = target[0].vSize.y.ToString();

		display();
	}

	private: System::Void btnScalingZ1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vSize.z += 0.1f;
		else
			target[0].vSize.z -= 0.1f;

		txtScalingZ1->Text = target[0].vSize.z.ToString();

		display();
	}

	private: System::Void btnTransX1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vPos.x += 0.05f;
		else
			target[0].vPos.x -= 0.05f;

		txtTransX1->Text = target[0].vPos.x.ToString();

		display();
	}

	private: System::Void btnTransY1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vPos.y += 0.05f;
		else
			target[0].vPos.y -= 0.05f;

		txtTransY1->Text = target[0].vPos.y.ToString();

		display();
	}

	private: System::Void btnTransZ1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vPos.z += 0.05f;
		else
			target[0].vPos.z -= 0.05f;

		txtTransZ1->Text = target[0].vPos.z.ToString();

		display();
	}

	private: System::Void btnRotX1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vEuler.x += 5.0f;
		else
			target[0].vEuler.x -= 5.0f;

		txtRotX1->Text = target[0].vEuler.x.ToString();

		display();
	}

	private: System::Void btnRotY1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vEuler.y += 5.0f;
		else
			target[0].vEuler.y -= 5.0f;

		txtRotY1->Text = target[0].vEuler.y.ToString();

		display();
	}

	private: System::Void btnRotZ1_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[0].vEuler.z += 5.0f;
		else
			target[0].vEuler.z -= 5.0f;

		txtRotZ1->Text = target[0].vEuler.z.ToString();

		display();
	}

	private: System::Void btnScalingX2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vSize.x += 0.1f;
		else
			target[1].vSize.x -= 0.1f;

		txtScalingX2->Text = target[1].vSize.x.ToString();

		display();
	}

	private: System::Void btnScalingY2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vSize.y += 0.1f;
		else
			target[1].vSize.y -= 0.1f;

		txtScalingY2->Text = target[1].vSize.y.ToString();

		display();
	}

	private: System::Void btnScalingZ2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vSize.z += 0.1f;
		else
			target[1].vSize.z -= 0.1f;

		txtScalingZ2->Text = target[1].vSize.z.ToString();

		display();
	}

	private: System::Void btnTransX2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vPos.x += 0.05f;
		else
			target[1].vPos.x -= 0.05f;

		txtTransX2->Text = target[1].vPos.x.ToString();

		display();
	}

	private: System::Void btnTransY2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vPos.y += 0.05f;
		else
			target[1].vPos.y -= 0.05f;

		txtTransY2->Text = target[1].vPos.y.ToString();

		display();
	}

	private: System::Void btnTransZ2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vPos.z += 0.05f;
		else
			target[1].vPos.z -= 0.05f;

		txtTransZ2->Text = target[1].vPos.z.ToString();

		display();
	}

	private: System::Void btnRotX2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vEuler.x += 5.0f;
		else
			target[1].vEuler.x -= 5.0f;

		txtRotX2->Text = target[1].vEuler.x.ToString();

		display();
	}

	private: System::Void btnRotY2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vEuler.y += 5.0f;
		else
			target[1].vEuler.y -= 5.0f;

		txtRotY2->Text = target[1].vEuler.y.ToString();

		display();
	}

	private: System::Void btnRotZ2_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			target[1].vEuler.z += 5.0f;
		else
			target[1].vEuler.z -= 5.0f;

		txtRotZ2->Text = target[1].vEuler.z.ToString();

		display();
	}

};
}


