#pragma once

#include "setup.h"
CSetup setup;
//#include "SpaceForm.h"

namespace CollisionE2R
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Form1 �̊T�v
	///
	/// �x�� : ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ 
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ����������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::Button *  btnReady1;
	private: System::Windows::Forms::Button *  btnReady2;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::TextBox *  txtNumRow;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::TextBox *  txtNumCol;
	private: System::Windows::Forms::Label *  label3;
	private: System::Windows::Forms::TextBox *  txtLength;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::TextBox *  txtMass;
	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::TextBox *  txtHeight;
	private: System::Windows::Forms::GroupBox *  groupBox2;
	private: System::Windows::Forms::RadioButton *  rdbCube;
	private: System::Windows::Forms::RadioButton *  rdbSphere;
	private: System::Windows::Forms::RadioButton *  rdbCylinder;
	private: System::Windows::Forms::Label *  label6;
	private: System::Windows::Forms::TextBox *  txtMassRigid;
	private: System::Windows::Forms::Button *  btnStructureK;
	private: System::Windows::Forms::Button *  btnShearK;
	private: System::Windows::Forms::Button *  btnHingeK;
	private: System::Windows::Forms::Button *  btnFriction;
	private: System::Windows::Forms::Button *  btnRestitution;
	private: System::Windows::Forms::Button *  btnRepulsion;
	private: System::Windows::Forms::TextBox *  txtStructK;
	private: System::Windows::Forms::TextBox *  txtShearK;
	private: System::Windows::Forms::TextBox *  txtHingeK;
	private: System::Windows::Forms::TextBox *  txtFriction;
	private: System::Windows::Forms::TextBox *  txtRestitution;
	private: System::Windows::Forms::TextBox *  txtRepParticle;
	private: System::Windows::Forms::Button *  btnDamping;
	private: System::Windows::Forms::TextBox *  txtDamping;
	private: System::Windows::Forms::Button *  btnDrag;
	private: System::Windows::Forms::TextBox *  txtDrag;
	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::TextBox *  txtNumFrame;
	private: System::Windows::Forms::Button *  btnForce;

	private: System::Windows::Forms::TextBox *  txtForce;
	private: System::Windows::Forms::TextBox *  txtDirection;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::TextBox *  txtDrawTime;
	private: System::Windows::Forms::Label *  label9;
	private: System::Windows::Forms::TextBox *  txtDeltaTime;
	private: System::Windows::Forms::Button *  btnThin;
	private: System::Windows::Forms::TextBox *  txtNumThin;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::RadioButton *  rdbPlaneXY;

	private: System::Windows::Forms::RadioButton *  rdbPlaneXZ;
	private: System::Windows::Forms::Button *  btnStart;
	private: System::Windows::Forms::Button *  btnStop;
	private: System::Windows::Forms::Button *  btnStep;
	private: System::Windows::Forms::CheckBox *  chkWireframe;
	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::Button *  btnCrane;
	private: System::Windows::Forms::Button *  btnTilt;
	private: System::Windows::Forms::Button *  btnTumble;
	private: System::Windows::Forms::Button *  btnPan;
	private: System::Windows::Forms::Button *  btnZoom;
	private: System::Windows::Forms::Button *  btnDolly;
	public: System::Windows::Forms::GroupBox *  groupBox5;
	private: System::Windows::Forms::CheckBox *  chkShadow;
	private: System::Windows::Forms::TextBox *  txtGridWidth;
	private: System::Windows::Forms::Button *  btnWidth;
	public: System::Windows::Forms::RadioButton *  rdbCheck;
	public: System::Windows::Forms::RadioButton *  rdbGrid;
	public: System::Windows::Forms::RadioButton *  rdbNon;
	private: System::Windows::Forms::GroupBox *  groupBox6;
	private: System::Windows::Forms::TextBox *  txtLightZ;
	private: System::Windows::Forms::Button *  btnLightZ;
	private: System::Windows::Forms::TextBox *  txtLightY;
	private: System::Windows::Forms::Button *  btnLightY;
	private: System::Windows::Forms::TextBox *  txtLightX;
	private: System::Windows::Forms::Button *  btnLightX;
	private: System::Windows::Forms::CheckBox *  chkTrack;
	private: System::Windows::Forms::GroupBox *  groupBox7;
	private: System::Windows::Forms::Button *  btnOpen;
	private: System::Windows::Forms::Button *  btnPaste;
	private: System::Windows::Forms::CheckBox *  chkSMM;
	private: System::Windows::Forms::CheckBox *  chkShearDisp;
	private: System::Windows::Forms::Button *  btnDirection;
	private: System::Windows::Forms::OpenFileDialog *  openFileDialog1;
	private: System::Windows::Forms::PictureBox *  picSpace;
private: System::Windows::Forms::RadioButton *  rdbPlaneYZ;
private: System::Windows::Forms::Label *  label10;

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->btnStep = new System::Windows::Forms::Button();
			this->btnStop = new System::Windows::Forms::Button();
			this->btnStart = new System::Windows::Forms::Button();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->rdbPlaneXZ = new System::Windows::Forms::RadioButton();
			this->rdbPlaneYZ = new System::Windows::Forms::RadioButton();
			this->rdbPlaneXY = new System::Windows::Forms::RadioButton();
			this->txtNumThin = new System::Windows::Forms::TextBox();
			this->btnThin = new System::Windows::Forms::Button();
			this->txtDeltaTime = new System::Windows::Forms::TextBox();
			this->label9 = new System::Windows::Forms::Label();
			this->txtDrawTime = new System::Windows::Forms::TextBox();
			this->label8 = new System::Windows::Forms::Label();
			this->txtDirection = new System::Windows::Forms::TextBox();
			this->txtForce = new System::Windows::Forms::TextBox();
			this->btnDirection = new System::Windows::Forms::Button();
			this->btnForce = new System::Windows::Forms::Button();
			this->txtNumFrame = new System::Windows::Forms::TextBox();
			this->label7 = new System::Windows::Forms::Label();
			this->txtDrag = new System::Windows::Forms::TextBox();
			this->btnDrag = new System::Windows::Forms::Button();
			this->txtDamping = new System::Windows::Forms::TextBox();
			this->btnDamping = new System::Windows::Forms::Button();
			this->txtRepParticle = new System::Windows::Forms::TextBox();
			this->txtRestitution = new System::Windows::Forms::TextBox();
			this->txtFriction = new System::Windows::Forms::TextBox();
			this->txtHingeK = new System::Windows::Forms::TextBox();
			this->txtShearK = new System::Windows::Forms::TextBox();
			this->txtStructK = new System::Windows::Forms::TextBox();
			this->btnRepulsion = new System::Windows::Forms::Button();
			this->btnRestitution = new System::Windows::Forms::Button();
			this->btnFriction = new System::Windows::Forms::Button();
			this->btnHingeK = new System::Windows::Forms::Button();
			this->btnShearK = new System::Windows::Forms::Button();
			this->btnStructureK = new System::Windows::Forms::Button();
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->txtMassRigid = new System::Windows::Forms::TextBox();
			this->label6 = new System::Windows::Forms::Label();
			this->rdbCylinder = new System::Windows::Forms::RadioButton();
			this->rdbSphere = new System::Windows::Forms::RadioButton();
			this->rdbCube = new System::Windows::Forms::RadioButton();
			this->txtHeight = new System::Windows::Forms::TextBox();
			this->label5 = new System::Windows::Forms::Label();
			this->txtMass = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->txtLength = new System::Windows::Forms::TextBox();
			this->label3 = new System::Windows::Forms::Label();
			this->txtNumCol = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->txtNumRow = new System::Windows::Forms::TextBox();
			this->label1 = new System::Windows::Forms::Label();
			this->btnReady2 = new System::Windows::Forms::Button();
			this->btnReady1 = new System::Windows::Forms::Button();
			this->chkWireframe = new System::Windows::Forms::CheckBox();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->btnCrane = new System::Windows::Forms::Button();
			this->btnTilt = new System::Windows::Forms::Button();
			this->btnTumble = new System::Windows::Forms::Button();
			this->btnPan = new System::Windows::Forms::Button();
			this->btnZoom = new System::Windows::Forms::Button();
			this->btnDolly = new System::Windows::Forms::Button();
			this->groupBox5 = new System::Windows::Forms::GroupBox();
			this->chkShadow = new System::Windows::Forms::CheckBox();
			this->txtGridWidth = new System::Windows::Forms::TextBox();
			this->btnWidth = new System::Windows::Forms::Button();
			this->rdbCheck = new System::Windows::Forms::RadioButton();
			this->rdbGrid = new System::Windows::Forms::RadioButton();
			this->rdbNon = new System::Windows::Forms::RadioButton();
			this->groupBox6 = new System::Windows::Forms::GroupBox();
			this->txtLightZ = new System::Windows::Forms::TextBox();
			this->btnLightZ = new System::Windows::Forms::Button();
			this->txtLightY = new System::Windows::Forms::TextBox();
			this->btnLightY = new System::Windows::Forms::Button();
			this->txtLightX = new System::Windows::Forms::TextBox();
			this->btnLightX = new System::Windows::Forms::Button();
			this->chkTrack = new System::Windows::Forms::CheckBox();
			this->groupBox7 = new System::Windows::Forms::GroupBox();
			this->btnPaste = new System::Windows::Forms::Button();
			this->btnOpen = new System::Windows::Forms::Button();
			this->chkSMM = new System::Windows::Forms::CheckBox();
			this->chkShearDisp = new System::Windows::Forms::CheckBox();
			this->openFileDialog1 = new System::Windows::Forms::OpenFileDialog();
			this->picSpace = new System::Windows::Forms::PictureBox();
			this->label10 = new System::Windows::Forms::Label();
			this->groupBox1->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox5->SuspendLayout();
			this->groupBox6->SuspendLayout();
			this->groupBox7->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label10);
			this->groupBox1->Controls->Add(this->btnStep);
			this->groupBox1->Controls->Add(this->btnStop);
			this->groupBox1->Controls->Add(this->btnStart);
			this->groupBox1->Controls->Add(this->groupBox3);
			this->groupBox1->Controls->Add(this->txtNumThin);
			this->groupBox1->Controls->Add(this->btnThin);
			this->groupBox1->Controls->Add(this->txtDeltaTime);
			this->groupBox1->Controls->Add(this->label9);
			this->groupBox1->Controls->Add(this->txtDrawTime);
			this->groupBox1->Controls->Add(this->label8);
			this->groupBox1->Controls->Add(this->txtDirection);
			this->groupBox1->Controls->Add(this->txtForce);
			this->groupBox1->Controls->Add(this->btnDirection);
			this->groupBox1->Controls->Add(this->btnForce);
			this->groupBox1->Controls->Add(this->txtNumFrame);
			this->groupBox1->Controls->Add(this->label7);
			this->groupBox1->Controls->Add(this->txtDrag);
			this->groupBox1->Controls->Add(this->btnDrag);
			this->groupBox1->Controls->Add(this->txtDamping);
			this->groupBox1->Controls->Add(this->btnDamping);
			this->groupBox1->Controls->Add(this->txtRepParticle);
			this->groupBox1->Controls->Add(this->txtRestitution);
			this->groupBox1->Controls->Add(this->txtFriction);
			this->groupBox1->Controls->Add(this->txtHingeK);
			this->groupBox1->Controls->Add(this->txtShearK);
			this->groupBox1->Controls->Add(this->txtStructK);
			this->groupBox1->Controls->Add(this->btnRepulsion);
			this->groupBox1->Controls->Add(this->btnRestitution);
			this->groupBox1->Controls->Add(this->btnFriction);
			this->groupBox1->Controls->Add(this->btnHingeK);
			this->groupBox1->Controls->Add(this->btnShearK);
			this->groupBox1->Controls->Add(this->btnStructureK);
			this->groupBox1->Controls->Add(this->groupBox2);
			this->groupBox1->Controls->Add(this->txtHeight);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->txtMass);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->txtLength);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->txtNumCol);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->txtNumRow);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->btnReady2);
			this->groupBox1->Controls->Add(this->btnReady1);
			this->groupBox1->Location = System::Drawing::Point(0, 0);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(488, 232);
			this->groupBox1->TabIndex = 0;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Animation";
			// 
			// btnStep
			// 
			this->btnStep->Location = System::Drawing::Point(432, 192);
			this->btnStep->Name = S"btnStep";
			this->btnStep->Size = System::Drawing::Size(48, 24);
			this->btnStep->TabIndex = 44;
			this->btnStep->Text = S"Step";
			this->btnStep->Click += new System::EventHandler(this, &Form1::btnStep_Click);
			// 
			// btnStop
			// 
			this->btnStop->Location = System::Drawing::Point(376, 192);
			this->btnStop->Name = S"btnStop";
			this->btnStop->Size = System::Drawing::Size(48, 24);
			this->btnStop->TabIndex = 43;
			this->btnStop->Text = S"Stop";
			this->btnStop->Click += new System::EventHandler(this, &Form1::btnStop_Click);
			// 
			// btnStart
			// 
			this->btnStart->Location = System::Drawing::Point(320, 192);
			this->btnStart->Name = S"btnStart";
			this->btnStart->Size = System::Drawing::Size(48, 24);
			this->btnStart->TabIndex = 42;
			this->btnStart->Text = S"Start";
			this->btnStart->Click += new System::EventHandler(this, &Form1::btnStart_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->rdbPlaneXZ);
			this->groupBox3->Controls->Add(this->rdbPlaneYZ);
			this->groupBox3->Controls->Add(this->rdbPlaneXY);
			this->groupBox3->Location = System::Drawing::Point(328, 136);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(152, 48);
			this->groupBox3->TabIndex = 41;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Mouse";
			// 
			// rdbPlaneXZ
			// 
			this->rdbPlaneXZ->Checked = true;
			this->rdbPlaneXZ->Location = System::Drawing::Point(104, 24);
			this->rdbPlaneXZ->Name = S"rdbPlaneXZ";
			this->rdbPlaneXZ->Size = System::Drawing::Size(40, 16);
			this->rdbPlaneXZ->TabIndex = 2;
			this->rdbPlaneXZ->TabStop = true;
			this->rdbPlaneXZ->Text = S"xz";
			// 
			// rdbPlaneYZ
			// 
			this->rdbPlaneYZ->Location = System::Drawing::Point(56, 21);
			this->rdbPlaneYZ->Name = S"rdbPlaneYZ";
			this->rdbPlaneYZ->Size = System::Drawing::Size(40, 24);
			this->rdbPlaneYZ->TabIndex = 1;
			this->rdbPlaneYZ->Text = S"yz";
			// 
			// rdbPlaneXY
			// 
			this->rdbPlaneXY->Location = System::Drawing::Point(8, 20);
			this->rdbPlaneXY->Name = S"rdbPlaneXY";
			this->rdbPlaneXY->Size = System::Drawing::Size(40, 24);
			this->rdbPlaneXY->TabIndex = 0;
			this->rdbPlaneXY->Text = S"xy";
			// 
			// txtNumThin
			// 
			this->txtNumThin->Location = System::Drawing::Point(272, 192);
			this->txtNumThin->Name = S"txtNumThin";
			this->txtNumThin->Size = System::Drawing::Size(32, 22);
			this->txtNumThin->TabIndex = 40;
			this->txtNumThin->Text = S"";
			// 
			// btnThin
			// 
			this->btnThin->Location = System::Drawing::Point(176, 192);
			this->btnThin->Name = S"btnThin";
			this->btnThin->Size = System::Drawing::Size(96, 24);
			this->btnThin->TabIndex = 39;
			this->btnThin->Text = S"�Ԉ����\��";
			this->btnThin->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnThin_MouseDown);
			// 
			// txtDeltaTime
			// 
			this->txtDeltaTime->Location = System::Drawing::Point(240, 160);
			this->txtDeltaTime->Name = S"txtDeltaTime";
			this->txtDeltaTime->Size = System::Drawing::Size(64, 22);
			this->txtDeltaTime->TabIndex = 38;
			this->txtDeltaTime->Text = S"";
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(208, 160);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(48, 24);
			this->label9->TabIndex = 37;
			this->label9->Text = S"����";
			// 
			// txtDrawTime
			// 
			this->txtDrawTime->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtDrawTime->Location = System::Drawing::Point(240, 136);
			this->txtDrawTime->Name = S"txtDrawTime";
			this->txtDrawTime->Size = System::Drawing::Size(64, 22);
			this->txtDrawTime->TabIndex = 36;
			this->txtDrawTime->Text = S"";
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(208, 136);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(48, 16);
			this->label8->TabIndex = 35;
			this->label8->Text = S"�`��";
			// 
			// txtDirection
			// 
			this->txtDirection->Location = System::Drawing::Point(432, 112);
			this->txtDirection->Name = S"txtDirection";
			this->txtDirection->Size = System::Drawing::Size(48, 22);
			this->txtDirection->TabIndex = 34;
			this->txtDirection->Text = S"";
			// 
			// txtForce
			// 
			this->txtForce->Location = System::Drawing::Point(432, 88);
			this->txtForce->Name = S"txtForce";
			this->txtForce->Size = System::Drawing::Size(48, 22);
			this->txtForce->TabIndex = 33;
			this->txtForce->Text = S"";
			// 
			// btnDirection
			// 
			this->btnDirection->Location = System::Drawing::Point(376, 112);
			this->btnDirection->Name = S"btnDirection";
			this->btnDirection->Size = System::Drawing::Size(56, 24);
			this->btnDirection->TabIndex = 32;
			this->btnDirection->Text = S"����";
			this->btnDirection->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDirection_MouseDown);
			// 
			// btnForce
			// 
			this->btnForce->Location = System::Drawing::Point(376, 88);
			this->btnForce->Name = S"btnForce";
			this->btnForce->Size = System::Drawing::Size(56, 24);
			this->btnForce->TabIndex = 31;
			this->btnForce->Text = S"�O��";
			this->btnForce->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnForce_MouseDown);
			// 
			// txtNumFrame
			// 
			this->txtNumFrame->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtNumFrame->Location = System::Drawing::Point(312, 104);
			this->txtNumFrame->Name = S"txtNumFrame";
			this->txtNumFrame->Size = System::Drawing::Size(48, 22);
			this->txtNumFrame->TabIndex = 30;
			this->txtNumFrame->Text = S"";
			// 
			// label7
			// 
			this->label7->Location = System::Drawing::Point(312, 88);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(48, 16);
			this->label7->TabIndex = 29;
			this->label7->Text = S"�R�}��";
			// 
			// txtDrag
			// 
			this->txtDrag->Location = System::Drawing::Point(264, 104);
			this->txtDrag->Name = S"txtDrag";
			this->txtDrag->Size = System::Drawing::Size(40, 22);
			this->txtDrag->TabIndex = 28;
			this->txtDrag->Text = S"";
			// 
			// btnDrag
			// 
			this->btnDrag->Location = System::Drawing::Point(176, 104);
			this->btnDrag->Name = S"btnDrag";
			this->btnDrag->Size = System::Drawing::Size(80, 24);
			this->btnDrag->TabIndex = 27;
			this->btnDrag->Text = S"�S���W��";
			this->btnDrag->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDrag_MouseDown);
			// 
			// txtDamping
			// 
			this->txtDamping->Location = System::Drawing::Point(264, 80);
			this->txtDamping->Name = S"txtDamping";
			this->txtDamping->Size = System::Drawing::Size(40, 22);
			this->txtDamping->TabIndex = 26;
			this->txtDamping->Text = S"";
			// 
			// btnDamping
			// 
			this->btnDamping->Location = System::Drawing::Point(176, 80);
			this->btnDamping->Name = S"btnDamping";
			this->btnDamping->Size = System::Drawing::Size(80, 24);
			this->btnDamping->TabIndex = 25;
			this->btnDamping->Text = S"�����萔";
			this->btnDamping->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDamping_MouseDown);
			// 
			// txtRepParticle
			// 
			this->txtRepParticle->Location = System::Drawing::Point(120, 200);
			this->txtRepParticle->Name = S"txtRepParticle";
			this->txtRepParticle->Size = System::Drawing::Size(48, 22);
			this->txtRepParticle->TabIndex = 24;
			this->txtRepParticle->Text = S"";
			// 
			// txtRestitution
			// 
			this->txtRestitution->Location = System::Drawing::Point(120, 176);
			this->txtRestitution->Name = S"txtRestitution";
			this->txtRestitution->Size = System::Drawing::Size(48, 22);
			this->txtRestitution->TabIndex = 23;
			this->txtRestitution->Text = S"";
			// 
			// txtFriction
			// 
			this->txtFriction->Location = System::Drawing::Point(120, 152);
			this->txtFriction->Name = S"txtFriction";
			this->txtFriction->Size = System::Drawing::Size(48, 22);
			this->txtFriction->TabIndex = 22;
			this->txtFriction->Text = S"";
			// 
			// txtHingeK
			// 
			this->txtHingeK->Location = System::Drawing::Point(120, 128);
			this->txtHingeK->Name = S"txtHingeK";
			this->txtHingeK->Size = System::Drawing::Size(48, 22);
			this->txtHingeK->TabIndex = 21;
			this->txtHingeK->Text = S"";
			// 
			// txtShearK
			// 
			this->txtShearK->Location = System::Drawing::Point(120, 104);
			this->txtShearK->Name = S"txtShearK";
			this->txtShearK->Size = System::Drawing::Size(48, 22);
			this->txtShearK->TabIndex = 20;
			this->txtShearK->Text = S"";
			// 
			// txtStructK
			// 
			this->txtStructK->Location = System::Drawing::Point(120, 80);
			this->txtStructK->Name = S"txtStructK";
			this->txtStructK->Size = System::Drawing::Size(48, 22);
			this->txtStructK->TabIndex = 19;
			this->txtStructK->Text = S"";
			// 
			// btnRepulsion
			// 
			this->btnRepulsion->Location = System::Drawing::Point(24, 200);
			this->btnRepulsion->Name = S"btnRepulsion";
			this->btnRepulsion->Size = System::Drawing::Size(96, 24);
			this->btnRepulsion->TabIndex = 18;
			this->btnRepulsion->Text = S"���_������";
			this->btnRepulsion->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRepulsion_MouseDown);
			// 
			// btnRestitution
			// 
			this->btnRestitution->Location = System::Drawing::Point(24, 176);
			this->btnRestitution->Name = S"btnRestitution";
			this->btnRestitution->Size = System::Drawing::Size(96, 24);
			this->btnRestitution->TabIndex = 17;
			this->btnRestitution->Text = S"�����W��";
			this->btnRestitution->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnRestitution_MouseDown);
			// 
			// btnFriction
			// 
			this->btnFriction->Location = System::Drawing::Point(24, 152);
			this->btnFriction->Name = S"btnFriction";
			this->btnFriction->Size = System::Drawing::Size(96, 24);
			this->btnFriction->TabIndex = 16;
			this->btnFriction->Text = S"���C�W��";
			this->btnFriction->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnFriction_MouseDown);
			// 
			// btnHingeK
			// 
			this->btnHingeK->Location = System::Drawing::Point(16, 128);
			this->btnHingeK->Name = S"btnHingeK";
			this->btnHingeK->Size = System::Drawing::Size(104, 24);
			this->btnHingeK->TabIndex = 15;
			this->btnHingeK->Text = S"���ԃo�l�萔";
			this->btnHingeK->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnHingeK_MouseDown);
			// 
			// btnShearK
			// 
			this->btnShearK->Location = System::Drawing::Point(8, 104);
			this->btnShearK->Name = S"btnShearK";
			this->btnShearK->Size = System::Drawing::Size(112, 24);
			this->btnShearK->TabIndex = 14;
			this->btnShearK->Text = S"����f�o�l�萔";
			this->btnShearK->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnShearK_MouseDown);
			// 
			// btnStructureK
			// 
			this->btnStructureK->Location = System::Drawing::Point(16, 80);
			this->btnStructureK->Name = S"btnStructureK";
			this->btnStructureK->Size = System::Drawing::Size(104, 24);
			this->btnStructureK->TabIndex = 13;
			this->btnStructureK->Text = S"�\���o�l�萔";
			this->btnStructureK->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnStructureK_MouseDown);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->txtMassRigid);
			this->groupBox2->Controls->Add(this->label6);
			this->groupBox2->Controls->Add(this->rdbCylinder);
			this->groupBox2->Controls->Add(this->rdbSphere);
			this->groupBox2->Controls->Add(this->rdbCube);
			this->groupBox2->Location = System::Drawing::Point(304, 16);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(176, 64);
			this->groupBox2->TabIndex = 12;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Rigid";
			// 
			// txtMassRigid
			// 
			this->txtMassRigid->Location = System::Drawing::Point(56, 38);
			this->txtMassRigid->Name = S"txtMassRigid";
			this->txtMassRigid->Size = System::Drawing::Size(56, 22);
			this->txtMassRigid->TabIndex = 4;
			this->txtMassRigid->Text = S"";
			// 
			// label6
			// 
			this->label6->Location = System::Drawing::Point(16, 40);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(48, 16);
			this->label6->TabIndex = 3;
			this->label6->Text = S"����";
			// 
			// rdbCylinder
			// 
			this->rdbCylinder->Location = System::Drawing::Point(112, 16);
			this->rdbCylinder->Name = S"rdbCylinder";
			this->rdbCylinder->Size = System::Drawing::Size(56, 24);
			this->rdbCylinder->TabIndex = 2;
			this->rdbCylinder->Text = S"�~��";
			// 
			// rdbSphere
			// 
			this->rdbSphere->Location = System::Drawing::Point(64, 16);
			this->rdbSphere->Name = S"rdbSphere";
			this->rdbSphere->Size = System::Drawing::Size(40, 24);
			this->rdbSphere->TabIndex = 1;
			this->rdbSphere->Text = S"��";
			// 
			// rdbCube
			// 
			this->rdbCube->Checked = true;
			this->rdbCube->Location = System::Drawing::Point(8, 16);
			this->rdbCube->Name = S"rdbCube";
			this->rdbCube->Size = System::Drawing::Size(56, 24);
			this->rdbCube->TabIndex = 0;
			this->rdbCube->TabStop = true;
			this->rdbCube->Text = S"�p��";
			// 
			// txtHeight
			// 
			this->txtHeight->Location = System::Drawing::Point(256, 40);
			this->txtHeight->Name = S"txtHeight";
			this->txtHeight->Size = System::Drawing::Size(40, 22);
			this->txtHeight->TabIndex = 11;
			this->txtHeight->Text = S"";
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(256, 24);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(40, 16);
			this->label5->TabIndex = 10;
			this->label5->Text = S"����";
			// 
			// txtMass
			// 
			this->txtMass->Location = System::Drawing::Point(200, 48);
			this->txtMass->Name = S"txtMass";
			this->txtMass->Size = System::Drawing::Size(40, 22);
			this->txtMass->TabIndex = 9;
			this->txtMass->Text = S"";
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(152, 48);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(48, 16);
			this->label4->TabIndex = 8;
			this->label4->Text = S"����";
			// 
			// txtLength
			// 
			this->txtLength->Location = System::Drawing::Point(200, 24);
			this->txtLength->Name = S"txtLength";
			this->txtLength->Size = System::Drawing::Size(40, 22);
			this->txtLength->TabIndex = 7;
			this->txtLength->Text = S"";
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(152, 24);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(56, 16);
			this->label3->TabIndex = 6;
			this->label3->Text = S"���R��";
			// 
			// txtNumCol
			// 
			this->txtNumCol->Location = System::Drawing::Point(112, 56);
			this->txtNumCol->Name = S"txtNumCol";
			this->txtNumCol->Size = System::Drawing::Size(24, 22);
			this->txtNumCol->TabIndex = 5;
			this->txtNumCol->Text = S"";
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(72, 56);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(40, 16);
			this->label2->TabIndex = 4;
			this->label2->Text = S"��";
			// 
			// txtNumRow
			// 
			this->txtNumRow->Location = System::Drawing::Point(40, 56);
			this->txtNumRow->Name = S"txtNumRow";
			this->txtNumRow->Size = System::Drawing::Size(24, 22);
			this->txtNumRow->TabIndex = 3;
			this->txtNumRow->Text = S"";
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(8, 56);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(40, 24);
			this->label1->TabIndex = 2;
			this->label1->Text = S"�s��";
			// 
			// btnReady2
			// 
			this->btnReady2->Location = System::Drawing::Point(80, 16);
			this->btnReady2->Name = S"btnReady2";
			this->btnReady2->Size = System::Drawing::Size(64, 32);
			this->btnReady2->TabIndex = 1;
			this->btnReady2->Text = S"Ready2";
			this->btnReady2->Click += new System::EventHandler(this, &Form1::btnReady2_Click);
			// 
			// btnReady1
			// 
			this->btnReady1->Location = System::Drawing::Point(8, 16);
			this->btnReady1->Name = S"btnReady1";
			this->btnReady1->Size = System::Drawing::Size(64, 32);
			this->btnReady1->TabIndex = 0;
			this->btnReady1->Text = S"Ready1";
			this->btnReady1->Click += new System::EventHandler(this, &Form1::btnReady1_Click);
			// 
			// chkWireframe
			// 
			this->chkWireframe->Location = System::Drawing::Point(8, 304);
			this->chkWireframe->Name = S"chkWireframe";
			this->chkWireframe->Size = System::Drawing::Size(96, 24);
			this->chkWireframe->TabIndex = 45;
			this->chkWireframe->Text = S"Wireframe";
			this->chkWireframe->CheckedChanged += new System::EventHandler(this, &Form1::chkWireframe_CheckedChanged);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->btnCrane);
			this->groupBox4->Controls->Add(this->btnTilt);
			this->groupBox4->Controls->Add(this->btnTumble);
			this->groupBox4->Controls->Add(this->btnPan);
			this->groupBox4->Controls->Add(this->btnZoom);
			this->groupBox4->Controls->Add(this->btnDolly);
			this->groupBox4->Location = System::Drawing::Point(208, 232);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(128, 96);
			this->groupBox4->TabIndex = 43;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Camera";
			// 
			// btnCrane
			// 
			this->btnCrane->Location = System::Drawing::Point(56, 62);
			this->btnCrane->Name = S"btnCrane";
			this->btnCrane->Size = System::Drawing::Size(64, 21);
			this->btnCrane->TabIndex = 5;
			this->btnCrane->Text = S"Crane";
			this->btnCrane->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnCrane_MouseDown);
			// 
			// btnTilt
			// 
			this->btnTilt->Location = System::Drawing::Point(8, 62);
			this->btnTilt->Name = S"btnTilt";
			this->btnTilt->Size = System::Drawing::Size(48, 21);
			this->btnTilt->TabIndex = 4;
			this->btnTilt->Text = S"Tilt";
			this->btnTilt->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTilt_MouseDown);
			// 
			// btnTumble
			// 
			this->btnTumble->Location = System::Drawing::Point(56, 41);
			this->btnTumble->Name = S"btnTumble";
			this->btnTumble->Size = System::Drawing::Size(64, 21);
			this->btnTumble->TabIndex = 3;
			this->btnTumble->Text = S"Tumble";
			this->btnTumble->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTumble_MouseDown);
			// 
			// btnPan
			// 
			this->btnPan->Location = System::Drawing::Point(8, 41);
			this->btnPan->Name = S"btnPan";
			this->btnPan->Size = System::Drawing::Size(48, 21);
			this->btnPan->TabIndex = 2;
			this->btnPan->Text = S"Pan";
			this->btnPan->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnPan_MouseDown);
			// 
			// btnZoom
			// 
			this->btnZoom->Location = System::Drawing::Point(56, 18);
			this->btnZoom->Name = S"btnZoom";
			this->btnZoom->Size = System::Drawing::Size(64, 22);
			this->btnZoom->TabIndex = 1;
			this->btnZoom->Text = S"Zoom";
			this->btnZoom->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnZoom_MouseDown);
			// 
			// btnDolly
			// 
			this->btnDolly->Location = System::Drawing::Point(8, 18);
			this->btnDolly->Name = S"btnDolly";
			this->btnDolly->Size = System::Drawing::Size(48, 22);
			this->btnDolly->TabIndex = 0;
			this->btnDolly->Text = S"Dolly";
			this->btnDolly->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDolly_MouseDown);
			// 
			// groupBox5
			// 
			this->groupBox5->Controls->Add(this->chkShadow);
			this->groupBox5->Controls->Add(this->txtGridWidth);
			this->groupBox5->Controls->Add(this->btnWidth);
			this->groupBox5->Controls->Add(this->rdbCheck);
			this->groupBox5->Controls->Add(this->rdbGrid);
			this->groupBox5->Controls->Add(this->rdbNon);
			this->groupBox5->Location = System::Drawing::Point(0, 232);
			this->groupBox5->Name = S"groupBox5";
			this->groupBox5->Size = System::Drawing::Size(208, 72);
			this->groupBox5->TabIndex = 42;
			this->groupBox5->TabStop = false;
			this->groupBox5->Text = S"Floor";
			// 
			// chkShadow
			// 
			this->chkShadow->Location = System::Drawing::Point(112, 40);
			this->chkShadow->Name = S"chkShadow";
			this->chkShadow->Size = System::Drawing::Size(88, 16);
			this->chkShadow->TabIndex = 5;
			this->chkShadow->Text = S"Shadow";
			this->chkShadow->CheckedChanged += new System::EventHandler(this, &Form1::chkShadow_CheckedChanged);
			// 
			// txtGridWidth
			// 
			this->txtGridWidth->Location = System::Drawing::Point(64, 40);
			this->txtGridWidth->Name = S"txtGridWidth";
			this->txtGridWidth->Size = System::Drawing::Size(40, 22);
			this->txtGridWidth->TabIndex = 4;
			this->txtGridWidth->Text = S"";
			// 
			// btnWidth
			// 
			this->btnWidth->Location = System::Drawing::Point(8, 40);
			this->btnWidth->Name = S"btnWidth";
			this->btnWidth->Size = System::Drawing::Size(56, 24);
			this->btnWidth->TabIndex = 3;
			this->btnWidth->Text = S"Width";
			this->btnWidth->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnWidth_MouseDown);
			// 
			// rdbCheck
			// 
			this->rdbCheck->Location = System::Drawing::Point(136, 16);
			this->rdbCheck->Name = S"rdbCheck";
			this->rdbCheck->Size = System::Drawing::Size(64, 24);
			this->rdbCheck->TabIndex = 2;
			this->rdbCheck->Text = S"Check";
			this->rdbCheck->CheckedChanged += new System::EventHandler(this, &Form1::rdbCheck_CheckedChanged);
			// 
			// rdbGrid
			// 
			this->rdbGrid->Checked = true;
			this->rdbGrid->Location = System::Drawing::Point(76, 16);
			this->rdbGrid->Name = S"rdbGrid";
			this->rdbGrid->Size = System::Drawing::Size(72, 24);
			this->rdbGrid->TabIndex = 1;
			this->rdbGrid->TabStop = true;
			this->rdbGrid->Text = S"Grid";
			this->rdbGrid->CheckedChanged += new System::EventHandler(this, &Form1::rdbGrid_CheckedChanged);
			// 
			// rdbNon
			// 
			this->rdbNon->Location = System::Drawing::Point(16, 16);
			this->rdbNon->Name = S"rdbNon";
			this->rdbNon->Size = System::Drawing::Size(56, 24);
			this->rdbNon->TabIndex = 0;
			this->rdbNon->Text = S"Non";
			this->rdbNon->CheckedChanged += new System::EventHandler(this, &Form1::rdbNon_CheckedChanged);
			// 
			// groupBox6
			// 
			this->groupBox6->Controls->Add(this->txtLightZ);
			this->groupBox6->Controls->Add(this->btnLightZ);
			this->groupBox6->Controls->Add(this->txtLightY);
			this->groupBox6->Controls->Add(this->btnLightY);
			this->groupBox6->Controls->Add(this->txtLightX);
			this->groupBox6->Controls->Add(this->btnLightX);
			this->groupBox6->Location = System::Drawing::Point(336, 232);
			this->groupBox6->Name = S"groupBox6";
			this->groupBox6->Size = System::Drawing::Size(80, 96);
			this->groupBox6->TabIndex = 44;
			this->groupBox6->TabStop = false;
			this->groupBox6->Text = S"Light";
			// 
			// txtLightZ
			// 
			this->txtLightZ->Location = System::Drawing::Point(32, 64);
			this->txtLightZ->Name = S"txtLightZ";
			this->txtLightZ->Size = System::Drawing::Size(34, 22);
			this->txtLightZ->TabIndex = 5;
			this->txtLightZ->Text = S"";
			// 
			// btnLightZ
			// 
			this->btnLightZ->Location = System::Drawing::Point(8, 64);
			this->btnLightZ->Name = S"btnLightZ";
			this->btnLightZ->Size = System::Drawing::Size(24, 22);
			this->btnLightZ->TabIndex = 4;
			this->btnLightZ->Text = S"Z";
			this->btnLightZ->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightZ_MouseDown);
			// 
			// txtLightY
			// 
			this->txtLightY->Location = System::Drawing::Point(32, 40);
			this->txtLightY->Name = S"txtLightY";
			this->txtLightY->Size = System::Drawing::Size(33, 22);
			this->txtLightY->TabIndex = 3;
			this->txtLightY->Text = S"";
			// 
			// btnLightY
			// 
			this->btnLightY->Location = System::Drawing::Point(8, 40);
			this->btnLightY->Name = S"btnLightY";
			this->btnLightY->Size = System::Drawing::Size(24, 24);
			this->btnLightY->TabIndex = 2;
			this->btnLightY->Text = S"Y";
			this->btnLightY->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightY_MouseDown);
			// 
			// txtLightX
			// 
			this->txtLightX->Location = System::Drawing::Point(32, 16);
			this->txtLightX->Name = S"txtLightX";
			this->txtLightX->Size = System::Drawing::Size(32, 22);
			this->txtLightX->TabIndex = 1;
			this->txtLightX->Text = S"";
			// 
			// btnLightX
			// 
			this->btnLightX->Location = System::Drawing::Point(8, 16);
			this->btnLightX->Name = S"btnLightX";
			this->btnLightX->Size = System::Drawing::Size(24, 24);
			this->btnLightX->TabIndex = 0;
			this->btnLightX->Text = S"X";
			this->btnLightX->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightX_MouseDown);
			// 
			// chkTrack
			// 
			this->chkTrack->Location = System::Drawing::Point(128, 304);
			this->chkTrack->Name = S"chkTrack";
			this->chkTrack->Size = System::Drawing::Size(72, 24);
			this->chkTrack->TabIndex = 46;
			this->chkTrack->Text = S"Track";
			// 
			// groupBox7
			// 
			this->groupBox7->Controls->Add(this->btnPaste);
			this->groupBox7->Controls->Add(this->btnOpen);
			this->groupBox7->Location = System::Drawing::Point(416, 240);
			this->groupBox7->Name = S"groupBox7";
			this->groupBox7->Size = System::Drawing::Size(72, 80);
			this->groupBox7->TabIndex = 47;
			this->groupBox7->TabStop = false;
			this->groupBox7->Text = S"Texture";
			// 
			// btnPaste
			// 
			this->btnPaste->Location = System::Drawing::Point(8, 48);
			this->btnPaste->Name = S"btnPaste";
			this->btnPaste->Size = System::Drawing::Size(56, 24);
			this->btnPaste->TabIndex = 1;
			this->btnPaste->Text = S"Paste";
			this->btnPaste->Click += new System::EventHandler(this, &Form1::btnPaste_Click);
			// 
			// btnOpen
			// 
			this->btnOpen->Location = System::Drawing::Point(8, 16);
			this->btnOpen->Name = S"btnOpen";
			this->btnOpen->Size = System::Drawing::Size(56, 24);
			this->btnOpen->TabIndex = 0;
			this->btnOpen->Text = S"Open";
			this->btnOpen->Click += new System::EventHandler(this, &Form1::btnOpen_Click);
			// 
			// chkSMM
			// 
			this->chkSMM->Location = System::Drawing::Point(208, 328);
			this->chkSMM->Name = S"chkSMM";
			this->chkSMM->Size = System::Drawing::Size(112, 24);
			this->chkSMM->TabIndex = 48;
			this->chkSMM->Text = S"�o�l���_�\��";
			this->chkSMM->CheckedChanged += new System::EventHandler(this, &Form1::chkSMM_CheckedChanged);
			// 
			// chkShearDisp
			// 
			this->chkShearDisp->Location = System::Drawing::Point(336, 328);
			this->chkShearDisp->Name = S"chkShearDisp";
			this->chkShearDisp->Size = System::Drawing::Size(136, 24);
			this->chkShearDisp->TabIndex = 49;
			this->chkShearDisp->Text = S"����f�o�l�\��";
			this->chkShearDisp->CheckedChanged += new System::EventHandler(this, &Form1::chkShearDisp_CheckedChanged);
			// 
			// picSpace
			// 
			this->picSpace->BorderStyle = System::Windows::Forms::BorderStyle::Fixed3D;
			this->picSpace->Location = System::Drawing::Point(496, 8);
			this->picSpace->Name = S"picSpace";
			this->picSpace->Size = System::Drawing::Size(288, 312);
			this->picSpace->TabIndex = 50;
			this->picSpace->TabStop = false;
			this->picSpace->MouseUp += new System::Windows::Forms::MouseEventHandler(this, &Form1::picSpace_MouseUp);
			this->picSpace->MouseMove += new System::Windows::Forms::MouseEventHandler(this, &Form1::picSpace_MouseMove);
			this->picSpace->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::picSpace_MouseDown);
			// 
			// label10
			// 
			this->label10->Location = System::Drawing::Point(304, 152);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(24, 16);
			this->label10->TabIndex = 45;
			this->label10->Text = S"s";
			// 
			// Form1
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(7, 15);
			this->ClientSize = System::Drawing::Size(792, 355);
			this->Controls->Add(this->picSpace);
			this->Controls->Add(this->chkShearDisp);
			this->Controls->Add(this->chkSMM);
			this->Controls->Add(this->groupBox7);
			this->Controls->Add(this->chkTrack);
			this->Controls->Add(this->chkWireframe);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox5);
			this->Controls->Add(this->groupBox6);
			this->Controls->Add(this->groupBox1);
			this->Name = S"Form1";
			this->Text = S"CollisionE2R(2�����e���̂ƍ��̂̏Փ�)";
			this->Resize += new System::EventHandler(this, &Form1::Form1_Resize);
			this->Load += new System::EventHandler(this, &Form1::Form1_Load);
			this->Closed += new System::EventHandler(this, &Form1::Form1_Closed);
			this->groupBox1->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox5->ResumeLayout(false);
			this->groupBox6->ResumeLayout(false);
			this->groupBox7->ResumeLayout(false);
			this->ResumeLayout(false);

		}	
//-------------------------------------------------------------------
	//SpaceForm* spaceForm;//�R�����`��t�H�[���̃C���X�^���X
	bool flagStart;//�A�j���[�V�������s�t���O
	bool flagStep;//�X�e�b�v���s�t���O
    bool flagFree;
    bool flagMouse;
    bool flagLeftButton;

    double structK;//�\���΂˒萔
    double shearK;//����f�o�l
    double hingeK;//���傤�����o�l
    double damping;//�o�l�����W��
    double drag;//��C�S���W��
    double ci;//������R
    double mu;//���ʂ̓����C�W��
    double ee;//���ʂ̔����W��
    double length0, lengthX0, lengthY0;//�΂˂̎��R��
    double radius;//���̔��a
    double massParticle;//���_�̎���
    double massRigid;//���̂̎���
    double height;//�Œ�_�̍���;
    double repParticle;//�˗�
    int numRow, numCol, numParticle;
    int numThin;
    double force, dir;
	double ratio;//texture�̉���/�����̔�
    int sI, sJ, sK;//�I�����ꂽ���_�ԍ�

	static double g = 9.8;//�d�͉����x
	static double pp = M_PI / 180.0;
    float t;//���̎��Ԍo�߁i���ԍ���dt�̘a�j
	int numFrame;//���R�}��

	private: System::Void Form1_Load(System::Object *  sender, System::EventArgs *  e)
	{
		//Form�̈ʒu
		Left = 100;
		Top = 100;
		//Floor�̏����l
		gridWidth = 1.0;
        txtGridWidth->Text = gridWidth.ToString();

		txtDeltaTime->Text = S"0.01";//�������ԑ���(s)
		numThin = 10;
		txtNumThin->Text = numThin.ToString();

		//�s���C��
		numRow = 10;//�ő�15
		numCol = 10;
		txtNumRow->Text = String::Format("{0:0}", __box(numRow));
		txtNumCol->Text = String::Format("{0:0}", __box(numCol));
		//�΂˂̒���
		length0 = 0.1; //�΂˂̎��R��
		txtLength->Text = String::Format("{0:0.00}", __box(length0));
		ratio = 1.0;
		//���_�̎���(���ׂē���)
		massParticle = 0.1;//Kg
		txtMass->Text = String::Format("{0:0.0}", __box(massParticle));
		massRigid = 1000.0;
		txtMassRigid->Text = String::Format("{0:0.0}", __box(massRigid));

		height = 0.7;//�e���̂̍����i�����ʒu)
		txtHeight->Text = String::Format("{0:0.0}", __box(height));
		force = 0.0;//Newton(���Ȃǂ̊O��)
		txtForce->Text = String::Format("{0:0.0}", __box(force));
		dir = 0.0;//deg(�O�͂̕���)
		txtDirection->Text = String::Format("{0:0.0}", __box(dir));
		//�����萔
		structK = 3000.0;//kg/s^2(�\���o�l�萔)
		txtStructK->Text = String::Format("{0:0.0}", __box(structK));
		shearK = 3000.0;//kg/s^2(����f�o�l�萔)
		txtShearK->Text = String::Format("{0:0.0}", __box(shearK));
		hingeK = 0.01;//kg/s^2(���ԃo�l�萔)
		txtHingeK->Text = String::Format("{0:0.00}", __box(hingeK));
		damping = 2.0;//kg/s(�����萔)
		txtDamping->Text = String::Format("{0:0.0}", __box(damping));
		drag = 0.1; //�S���W��
		txtDrag->Text = String::Format("{0:0.00}", __box(drag));
		repParticle = 0.05;//���_���m�̐˗�
		txtRepParticle->Text = String::Format("{0:0.000}", __box(repParticle));

		mu = 0.5;//
		txtFriction->Text = String::Format("{0:0.00}", __box(mu));
		ee = 0.3;//�����W��
		txtRestitution->Text = String::Format("{0:0.000}", __box(ee));
		//�Œ�_
		height = 1.5;
		//Floor�̏����l
		gridWidth = 1.0;

        txtLightX->Text = light.x.ToString();
        txtLightY->Text = light.y.ToString();
        txtLightZ->Text = light.z.ToString();
	}

	private: System::Void Form1_Closed(System::Object *  sender, System::EventArgs *  e)
	{
 		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);
	}

private: System::Void Form1_Resize(System::Object *  sender, System::EventArgs *  e)
	{
		picSpace->Left = groupBox1->Right + 10;
		picSpace->Width = this->Width - groupBox1->Width - 20;
		picSpace->Height = this->Height - 50;
	}
	private: System::Void setCamera()
	{
		if(chkTrack->Checked == true){
			camera.vCenter = elastic2[0].vPos;
			camera.position();
		}
	}

	//----------------------------------------------------------------
	private: System::Void display()
	{
		int i;

		setup.set3DAmbient(picSpace);
		setup.setLight();
		setCamera();
		flagShadow = chkShadow->Checked;

		glClear(GL_COLOR_BUFFER_BIT); //�װ�ޯ̧��ر
		glClear(GL_DEPTH_BUFFER_BIT); //���߽�ޯ̧��ر

		//�������̂�����Ƃ��͎���2�s���K�v
		glCullFace(GL_BACK);//���ʂ��폜
		glEnable(GL_CULL_FACE);//���ʍ폜��L���ɂ���

		setup.drawFloor(rdbNon, rdbCheck);//setup.h

		if(chkWireframe->Checked == true){//ܲ԰�ڰ�����
			glPolygonMode(GL_FRONT,GL_LINE);
			glPolygonMode(GL_BACK,GL_POINT);
		}

	//	for(i=0;i<numRigid;i++) rigid[i].draw();//�s�������̂̂Ƃ��͂��ꂾ��
		//�������̂�����Ƃ��͈ȉ��̂悤�ɕs�������̂����ׂĕ`��
		for(i = 0; i < numRigid; i++) {
			if(rigid[i].diffuse[3] == 1) {
				rigid[i].setTexture();
				rigid[i].draw(false);
			}
		}
		for(i = 0; i < numElastic2; i++) {
				elastic2[i].setTexture();
				elastic2[i].draw(false);
		}

		glDepthMask(GL_FALSE); //���߽�ޯ̧���������݋֎~
		glEnable(GL_BLEND);//��̧�����ިݸނ�L���ɂ���
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);//�F�����W�������߂�

		//���������̂�`��
		for(i=0;i<numRigid;i++) {
			if(rigid[i].diffuse[3] != 1) {
				rigid[i].setTexture();
				rigid[i].draw(false);
			}
		}
		glDepthMask(GL_TRUE); //���߽�ޯ̧�̏������݂�����
		glDisable(GL_BLEND);

		setup.drawShadow();
		SwapBuffers(hDC);
	}

	private: System::Void btnReady1_Click(System::Object *  sender, System::EventArgs *  e)
	{
		//OpenGL����
		IntPtr ptr = picSpace->Handle;//�f�o�C�X�R���e�L�X�g�̃n���h��
		hWnd = (HWND)ptr.ToInt32();
		hDC = GetDC(hWnd);
		setup.initOpenGL();

		int i, j, k;

		numRigid = 1;
		numElastic2 = 1;
		setCommonItems();

		//�e����
		//�Œ�_
		for(i = 0; i < numRow; i++)
			for(j = 0; j < numCol; j++){
				k = i * numCol +j;
				elastic2[0].particle[k].flagFixed = false;
			}
		//������texture�̃T�C�Y��Œ���
		elastic2[0].lengthY0 = length0 * ratio * (float)(numRow-1) / (float)(numCol-1);
		elastic2[0].initialize();
		elastic2[0].flagSMMDisp = chkSMM->Checked;

    //texture�̎擾(�ύX����Ƃ���Form��[Open]�܂���[Paste]�Łj
		Image* im = Image::FromFile("/CppNetOpenGL2005Exp/bmp128/face2.bmp");
//		Image* im = Image::FromFile("../../bmp128/face2.bmp");
		Bitmap* bitmap = new Bitmap(im);
		elastic2[0].loadTexture(bitmap);
	    ratio = (float)bitmap->Width / (float)bitmap->Height;
		elastic2[0].texMode = T_MODULATE;

		//����
		//�e�N�X�`���C�F
		rigid[0].texMode = T_MODULATE;
		rigid[0].texType = T_SOLID;//
		//solid texture�̏ꍇ�͑O������texImageS���v�Z���Ă���
		if(rigid[0].texType == T_SOLID) rigid[0].calcSolidTexCube(rigid[0].vSize);
		rigid[0].diffuse[0] = 0.9f; //red
		rigid[0].diffuse[1] = 0.9f;
		rigid[0].diffuse[2] = 0.9f;
		//����
		rigid[0].mass = massRigid; //�S��
		//�T�C�Y�C�ʒu,�p��
		rigid[0].vSize = CVector(0.4, 0.4, 0.4);
		rigid[0].vPos = CVector( 0.0, 0.0, rigid[0].vSize.z / 2.0);//����
		rigid[0].vEuler = CVector( 0.0, 0.0, 0.0);
		//�����x�C�p���x�̊e�����C
		rigid[0].vVelocity = CVector(0.0, 0.0, 0.0);
		rigid[0].omega0 = 0.0*M_PI/180.0;
		rigid[0].vAxis = CVector(0.0, 0.0, 1.0);
		rigid[0].vOmega = rigid[0].omega0 * rigid[0].vAxis; //rad
		//�O��
		rigid[0].vForce0 = CVector(0.0, 0.0,- massRigid * g) ;
		//�Œ����
		rigid[0].flagFixed = true;
		numFrame = 0;
	    txtNumFrame->Text = numFrame.ToString();
		setCamera();
		display();
	}

	private: System::Void btnReady2_Click(System::Object *  sender, System::EventArgs *  e)
	{
		//OpenGL����
		IntPtr ptr = picSpace->Handle;//�f�o�C�X�R���e�L�X�g�̃n���h��
		hWnd = (HWND)ptr.ToInt32();
		hDC = GetDC(hWnd);
		setup.initOpenGL();

		int i, j, k;

		numRigid = 5;
		numElastic2 = 1;

		setCommonItems();

		//�e����
		elastic2[0].numRow = numRow;
		elastic2[0].numCol = numCol;
		numParticle = numRow * numCol;

		//�Œ�_
		for(i = 0; i < numRow; i++)
			for(j = 0; j < numCol; j++){
				k = i * numCol +j;
				elastic2[0].particle[k].flagFixed = false;
				if(i == 0 && j == 0) elastic2[0].particle[k].flagFixed = true;
				if(i == 0 && j == numCol-1) elastic2[0].particle[k].flagFixed = true;
				if(i == numRow-1 && j == 0) elastic2[0].particle[k].flagFixed = true;
				if(i == numRow-1 && j == numCol-1) elastic2[0].particle[k].flagFixed = true;

			}
		//������texture�̃T�C�Y��Œ���
		elastic2[0].lengthY0 = length0 * ratio * (float)(numRow-1) / (float)(numCol-1);
		elastic2[0].initialize();
		elastic2[0].flagSMMDisp = chkSMM->Checked;
	//    elastic2[0].texMode = T_MODULATE;

		//����
		Image* im = Image::FromFile("/CppNetOpenGL2005Exp/bmp128/checkMono1.bmp");
		Bitmap* bitmap = new Bitmap(im);
		rigid[0].texMode = T_MODULATE;
		rigid[0].makeTexture(bitmap);
		rigid[0].diffuse[0] = 0.9f; //red
		rigid[0].diffuse[1] = 0.9f;
		rigid[0].diffuse[2] = 0.9f;

		//�T�C�Y�C�ʒu,�p��
		rigid[0].vSize = CVector(0.3, 0.3, 0.3);
		rigid[0].vPos = CVector( 0.0, 0.0, rigid[0].vSize.z / 2.0+height+0.1);
		rigid[0].vEuler = CVector(0.0, 0.0, 0.0);
		rigid[0].omega0 = 0.0 * M_PI/180.0;//Convert::ToDouble(txtOmega->Text);
		rigid[0].vAxis = CVector(0.0, 0.0, 1.0);
		rigid[0].vOmega = CVector(0.0, 0.0, 0.0);
		//����
		if(massRigid > 30.0) {
			massRigid = 30.0;
			txtMassRigid->Text = String::Format("{0:0.0}", __box(massRigid));
		}
		rigid[0].mass = massRigid; //�S��
		//�����x�̊e����
		rigid[0].vVelocity = CVector(0.0, 0.0, 0.0);
		//�O��
		rigid[0].vForce0 = CVector(0.0, 0.0, - massRigid * g);
		//�Œ����
		rigid[0].flagFixed = false;
		//�x���_
		for(i = 1; i < numRigid; i++){
			rigid[i].kind = CYLINDER ;
			rigid[i].texType = T_SOLID;//
			rigid[i].texMode = T_MODULATE;
			rigid[i].vSize = CVector(0.1, 0.1, height);
			rigid[i].vEuler = CVector(0.0, 0.0, 0.0);
			rigid[i].diffuse[0] = 0.9f; //red
			rigid[i].diffuse[1] = 0.9f;
			rigid[i].diffuse[2] = 0.9f;
			rigid[i].mass = 1000.0;
			rigid[i].calcSolidTexCylinder(rigid[i].vSize);//�ؖ�
			rigid[i].flagFixed = true;
		}
		rigid[1].vPos = CVector( -lengthX0*(float)(numRow-1)/2.0, -lengthY0*(float)(numCol-1)/2.0, height/2.0);
		rigid[2].vPos = CVector( lengthX0*(float)(numRow-1)/2.0, -lengthY0*(float)(numCol-1)/2.0, height/2.0);
		rigid[3].vPos = CVector( lengthX0*(float)(numRow-1)/2.0, lengthY0*(float)(numCol-1)/2.0, height/2.0);
		rigid[4].vPos = CVector( -lengthX0*(float)(numRow-1)/2.0, lengthY0*(float)(numCol-1)/2.0, height/2.0);
		numFrame = 0;
		setCamera();
		display();
	}

	private: System::Void setCommonItems()
	{
		int k;

		//�����ݒ�
		length0 = Convert::ToDouble(txtLength->Text);
		lengthX0 = length0;
		lengthY0 = ratio * length0;
		elastic2[0].lengthX0 = lengthX0;
		elastic2[0].lengthY0 = lengthY0;
		height = Convert::ToDouble(txtHeight->Text);
		//�萔
		mu = Convert::ToDouble(txtFriction->Text);//�����C��R(��)
		ee = Convert::ToDouble(txtRestitution->Text);//�����W��(���ƍ���)
		structK = Convert::ToDouble(txtStructK->Text);
		shearK = Convert::ToDouble(txtShearK->Text);
		hingeK = Convert::ToDouble(txtHingeK->Text);
		damping = Convert::ToDouble(txtDamping->Text);
		drag = Convert::ToDouble(txtDrag->Text);
		ci = 0.0;//��C�̊�����R�W��
		massParticle = Convert::ToDouble(txtMass->Text);
		massRigid = Convert::ToDouble(txtMassRigid->Text);
		//���f���̍s���E�񐔁E���_��
		numRow = Convert::ToInt32(txtNumRow->Text);
		numCol = Convert::ToInt32(txtNumCol->Text);
		if(numRow > 15) numRow = 15;//
		if(numCol > 15) numCol = 15;
		elastic2[0].numRow = numRow;
		elastic2[0].numCol = numCol;
		numParticle = numRow * numCol;
		txtNumRow->Text = String::Format("{0:0}", __box(numRow));
		txtNumCol->Text = String::Format("{0:0}", __box(numCol));

		//�e����
		//�萔�C�W��
		elastic2[0].structK = structK;
		elastic2[0].shearK = shearK;
		elastic2[0].hingeK = hingeK;
		elastic2[0].damping = damping;
		elastic2[0].drag = drag;
		//����
		elastic2[0].massParticle = massParticle;//���_1������
		//���x
		for(k = 0; k < numParticle; k++){
			elastic2[0].particle[k].vVelocity = CVector(0.0, 0.0, 0.0);
		}
		//�O��
		elastic2[0].vForce0.x = 0.0;
		elastic2[0].vForce0.y = 0.0;
		elastic2[0].vForce0.z = - massParticle * g;

		//���݈ʒu�i�l�p�`�̒��S��xy���W�̌��_�ɂȂ�悤�Ɂj�j
		elastic2[0].vPos.x = 0.0;
		elastic2[0].vPos.y = 0.0;
		elastic2[0].vPos.z = height;//����
		elastic2[0].vEuler.y = 0.0; //��{�p���ł�x-y����
		elastic2[0].vEuler.x = 0.0;

		//����
		if(rdbSphere->Checked == true){
			rigid[0].kind = SPHERE; rigid[0].texType = T_SPHERICAL;
		}
		else if(rdbCube->Checked == true){
			rigid[0].kind = CUBE; rigid[0].texType = T_PLANAR2;
		}
		else{
			rigid[0].kind = CYLINDER; rigid[0].texType = T_CYLINDRICAL;
		}
	}

	private: System::Void execute()
	{
		float drawTime, lapse;
		int h1, m1, s1, ms1;
		int h2, m2, s2, ms2;
		float dt;//��������
		double g = 9.8;
		double pp = M_PI / 180.0;
    
		//����
		dt = Convert::ToSingle(txtDeltaTime->Text);//�b�P�ʂŎw��

		txtDrawTime->Text = S" ";
		flagStart = true;

		Cursor = Cursors::AppStarting;//�J�[�\����ύX
		DateTime tStart = DateTime::Now;//���݂̎���
		h1 = tStart.Hour;
		m1 = tStart.Minute;
		s1 = tStart.Second;
		ms1 = tStart.Millisecond;

		int i, k, n;
		int numFrame0 = 0;
		float ddt;
	//    rigid[0].flagFixed = false;
		for(i = 0; i < numRigid; i++) rigid[i].calcInertia();//�������[�����g�̌v�Z

		while(true){
			elastic2[0].flagSMMDisp = chkSMM->Checked;
			elastic2[0].flagShearDisp = chkShearDisp->Checked;
			numThin = Convert::ToInt32(txtNumThin->Text);
			ddt = dt / (float)numThin; //�Ԉ����\���i���s���ύX�j
			//�萔�C�W��
			elastic2[0].structK = structK;
			elastic2[0].shearK = shearK;
			elastic2[0].hingeK = hingeK;
			elastic2[0].damping = damping;
			elastic2[0].drag = drag;
			elastic2[0].repParticle = repParticle;
			//�d�͈ȊO�̊O��
			elastic2[0].vForce0.x = force * cos(dir * M_PI / 180.0);
			elastic2[0].vForce0.y = force * sin(dir * M_PI / 180.0);
			rigid[0].vForce0.x = force * cos(dir * M_PI / 180.0);
			rigid[0].vForce0.y = force * sin(dir * M_PI / 180.0);

			for(k = 0; k < numThin; k++){
				for(n = 0; n < numRigid; n++){
					rigid[n].vPos0 = rigid[n].vPos;
					if(rigid[n].flagFixed == false){
						rigid[n].projection(ee, mu, drag, ci, ddt);
					}
				}
				for(n = 0; n < numElastic2; n++) {
						elastic2[n].calcElastic2(numRigid, rigid, mu, ee, ddt);
				}
			}
			display();
			Application::DoEvents();//���̃C�x���g��҂�
			if( flagStart == false ) break;
	//if(numFrame == 20) break;
			numFrame++;
			numFrame0++;
			if(flagStep == true) break;
		}

		Cursor = Cursors::Default;
		DateTime tStop = DateTime::Now;
		h2 = tStop.Hour;
		m2 = tStop.Minute;
		s2 = tStop.Second;
		ms2 = tStop.Millisecond;
		//�o�ߎ���(sec)
		lapse = (float)(h2-h1) * 3600.0f + (float)(m2-m1) * 60.0f + (float)(s2-s1) + (float)(ms2-ms1) / 1000.0f;
		//1�R�}������̕`�掞��(sec)
		drawTime = lapse / (float)numFrame0;
		txtDrawTime->Text = drawTime.ToString();//�e�L�X�g�{�b�N�X�ɕ\��
		txtNumFrame->Text = numFrame.ToString();//���R�}��
	}

	private: System::Void btnStart_Click(System::Object *  sender, System::EventArgs *  e)
	{
		execute();
	}

	private: System::Void btnStop_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = false;
	}

	private: System::Void btnStep_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = true;
		flagStep = true;
		execute();
	}

private: System::Void btnStructureK_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        structK += 100.0;
    else
        structK -= 100.0;
    if(structK < 0) structK = 0.0;
    txtStructK->Text = String::Format("{0:0.0}", __box(structK));
	}

private: System::Void btnShearK_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        shearK += 100.0;
    else
        shearK -= 100.0;
    if(shearK < 0) shearK = 0.0;
    txtShearK->Text = String::Format("{0:0.0}", __box(shearK));
	}

private: System::Void btnHingeK_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        hingeK += 0.01;
    else
        hingeK -= 0.01;
    if(hingeK < 0.0) hingeK = 0.0;
    txtHingeK->Text = String::Format("{0:0.00}", __box(hingeK));
	}

private: System::Void btnFriction_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        mu += 0.1;
    else
        mu -= 0.1;
    txtFriction->Text = String::Format("{0:0.0}", __box(mu));
	}

private: System::Void btnRestitution_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        ee += 0.1;
    else
        ee -= 0.1;
    txtRestitution->Text = String::Format("{0:0.00}", __box(ee));
	}

private: System::Void btnRepulsion_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        repParticle += 0.01;
    else
        repParticle -= 0.01;
    if(repParticle < 0.0) repParticle = 0.0;
    txtRepParticle->Text = String::Format("{0:0.00}", __box(repParticle));
	}

private: System::Void btnDamping_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        damping += 0.1;
    else
        damping -= 0.1;
    txtDamping->Text = String::Format("{0:0.0}", __box(damping));
	}

private: System::Void btnDrag_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        drag += 0.01;
    else
        drag -= 0.01;
    txtDrag->Text = String::Format("{0:0.00}", __box(drag));
	}

private: System::Void btnThin_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        numThin += 1;
    else
        numThin -= 1;
    if(numThin < 1) numThin = 1;
    txtNumThin->Text = String::Format("{0:0}", __box(numThin));
	}

private: System::Void btnForce_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        force += 0.5;
    else
        force -= 0.5;
    txtForce->Text = String::Format("{0:0.0}", __box(force));
	}

private: System::Void btnDirection_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
    if(e->Button == MouseButtons::Left)
        dir += 10.0;
    else
        dir -= 10.0;
    txtDirection->Text = String::Format("{0:0.0}", __box(dir));
	}

    private: System::Void rdbCheck_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbGrid_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbNon_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void btnWidth_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
         if(e->Button == MouseButtons::Left)
                gridWidth += 0.1f;
         else
                gridWidth -= 0.1f;
         txtGridWidth->Text = gridWidth.ToString();
         display();
    }

    private: System::Void chkShadow_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        flagShadow = chkShadow->Checked;
        display();
    }

    private: System::Void btnDolly_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.dist -= 0.5f;
        else
            camera.dist += 0.5f;

        camera.position();
        setup.set3DAmbient(picSpace);
        display();
    }

    private: System::Void btnZoom_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.fov -= 0.1f;
        else
            camera.fov += 0.1f;

        camera.position();
        setup.set3DAmbient(picSpace);
        display();
    }

    private: System::Void btnPan_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta += 1.0f; //deg
   	    else
            camera.theta -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.position();
        setup.set3DAmbient(picSpace);
        display();
    }

    private: System::Void btnTumble_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta -= 5.0f;
        else
            camera.theta += 5.0f;

        camera.position();
        setup.set3DAmbient(picSpace);
        display();
    }

    private: System::Void btnTilt_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 1.0f; //deg
   	    else
            camera.phi -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.vCenter.z = camera.vPos.z - camera.dist * (float)sin(pp * camera.phi);
        setup.set3DAmbient(picSpace);
        display();
    }

    private: System::Void btnCrane_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 2.0f;
        else
            camera.phi -= 2.0f;

        camera.position();
        setup.set3DAmbient(picSpace);
        display();
    }

    private: System::Void btnLightX_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.x += 1.0f;
        else
            light.x -= 1.0f;
        txtLightX->Text = String::Format("{0:0.0}", __box(light.x));

        display();
    }

    private: System::Void btnLightY_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.y += 1.0f;
        else
            light.y -= 1.0f;
        txtLightY->Text = String::Format("{0:0.0}", __box(light.y));

        display();
    }

    private: System::Void btnLightZ_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.z += 1.0f;
        else
            light.z -= 1.0f;
        txtLightZ->Text = String::Format("{0:0.0}", __box(light.z));

        display();
    }

	private: System::Void chkWireframe_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
        setup.initOpenGL(); //Mode�؂�ւ����ɂ͕K�v
        display();
	}


private: System::Void btnOpen_Click(System::Object *  sender, System::EventArgs *  e)
	{
		if(openFileDialog1->ShowDialog() == DialogResult::OK)
		{
			Bitmap* bmp = new Bitmap(openFileDialog1->FileName);
		
			elastic2[0].loadTexture(bmp);
			if( bmp->Height == 0.0) return;
			ratio = (float)bmp->Width / (float)bmp->Height;
			//bitmap�̃T�C�Y��ɍ��킹�ăo�l���_���f���̉������̎��R����ς���
			elastic2[0].lengthY0 = ratio * elastic2[0].lengthX0
				*(float)(elastic2[0].numRow-1) / (float)(elastic2[0].numCol-1);
			elastic2[0].initialize();
		}
		display();
	}

private: System::Void btnPaste_Click(System::Object *  sender, System::EventArgs *  e)
	{
		IDataObject *id = Clipboard::GetDataObject();
		
		if(id->GetDataPresent(DataFormats::Bitmap))
		{
			Bitmap* bmp = new Bitmap((Image*)id->GetData(DataFormats::Bitmap));

			elastic2[0].loadTexture(bmp);
			if( bmp->Height == 0.0) return;
			ratio = (float)bmp->Width / (float)bmp->Height;
			//bitmap�̃T�C�Y��ɍ��킹�ăo�l���_���f���̉������̎��R����ς���
			elastic2[0].lengthY0 = ratio * elastic2[0].lengthX0
				*(float)(elastic2[0].numRow-1) / (float)(elastic2[0].numCol-1);
			elastic2[0].initialize();
			display();
		}
	}

private: System::Void chkSMM_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
		elastic2[0].flagSMMDisp = chkSMM->Checked;
		display();
	}

private: System::Void chkShearDisp_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
		elastic2[0].flagShearDisp = chkShearDisp->Checked;
		display();
	}

//---------------------------------------------------------------------------

//mouse�ɂ��C���^���N�V����
//---------------------------------------------------------------------------


private: System::Void picSpace_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
    flagMouse = true;
	Cursor = Cursors::Hand;
    mouse.vMousePosWorld = mouse.getMousePosWorld(e->X, e->Y, picSpace);
    mouse.vDirMouse =  mouse.vMousePosWorld - camera.vPos;//�J��������}�E�X�ւ̃x�N�g��

    if(rdbPlaneXY->Checked == true)//x-y����(����z�͑I�����ꂽparticle�̈ʒu�ŌŒ�j
         mouse.vNormal = CVector(0.0, 0.0, 1.0);
    else if(rdbPlaneYZ->Checked == true)
         mouse.vNormal = CVector(1.0, 0.0, 0.0);
    else
         mouse.vNormal = CVector(0.0,1.0, 0.0);

    if(e->Button == MouseButtons::Left)//�e���̂̎��_
    {
        flagLeftButton = true;
        sK = mouse.selectParticleNo(mouse.vDirMouse);
        elastic2[0].particle[sK].flagFixed = true;
         mouse.pos = elastic2[0].particle[sK].vPos;//���_�̈ʒu
        //�J�����ƃ}�E�X�����Ԓ����Ǝ��_���܂ޕ��ʂƂ̌�_
         mouse.vOld = camera.vPos - ( mouse.vNormal*(camera.vPos -  mouse.pos)
            / ( mouse.vNormal* mouse.vDirMouse)) *  mouse.vDirMouse;
    }
    else //���̂��ړ��i���̂�1�����j
    {
        rigid[0].flagFixed = true;
         mouse.vOld = camera.vPos - ( mouse.vNormal*(camera.vPos - rigid[0].vPos)
            / ( mouse.vNormal* mouse.vDirMouse)) *  mouse.vDirMouse;
    }
}

private: System::Void picSpace_MouseMove(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
    if(flagMouse == false) return ;
    mouse.vMousePosWorld = mouse.getMousePosWorld(e->X, e->Y, picSpace);
    mouse.vDirMouse = mouse.vMousePosWorld - camera.vPos;

    if(rdbPlaneXY->Checked == true)//x-y����(����z�͑I�����ꂽparticle�̈ʒu�ŌŒ�j
        mouse.vNormal = CVector(0.0, 0.0, 1.0);
    else if(rdbPlaneYZ->Checked == true)
        mouse.vNormal = CVector(1.0, 0.0, 0.0);
    else
        mouse.vNormal = CVector(0.0,1.0, 0.0);

    if(flagLeftButton == true) //�e���̂̎��_
    {
        mouse.pos = elastic2[0].particle[sK].vPos;//���_�̈ʒu
        //�J�����ƃ}�E�X�����Ԓ����Ǝ��_���܂ޕ��ʂƂ̌�_
        mouse.vNew = camera.vPos - (mouse.vNormal*(camera.vPos - mouse.pos)
           / (mouse.vNormal*mouse.vDirMouse)) * mouse.vDirMouse;
        elastic2[0].particle[sK].vPos += mouse.vNew - mouse.vOld;
    }
    else//����
    {
        mouse.vNew = camera.vPos - (mouse.vNormal*(camera.vPos - rigid[0].vPos)
           / (mouse.vNormal*mouse.vDirMouse)) * mouse.vDirMouse;
        rigid[0].vPos += mouse.vNew - mouse.vOld;
    }
    mouse.vOld = mouse.vNew;
}

private: System::Void picSpace_MouseUp(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
{
    if(flagLeftButton == true){
        elastic2[0].particle[sK].flagFixed = false;
    }
    else
    {
        rigid[0].flagFixed = false;
        rigid[0].vVelocity = CVector(0.0, 0.0, 0.0);
        rigid[0].omega0 = 0.0;
    }
    flagMouse = false;
    flagLeftButton = false;
 	Cursor = Cursors::AppStarting;
}


};
}


