#pragma once

#include "setup.h"
CSetup setup;
#include "SpaceForm.h"

namespace Projectile2
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Form1 �̊T�v
	///
	/// �x�� : ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ 
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ����������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::GroupBox *  groupBox2;
	private: System::Windows::Forms::Button *  btnCrane;
	private: System::Windows::Forms::Button *  btnTilt;
	private: System::Windows::Forms::Button *  btnTumble;
	private: System::Windows::Forms::Button *  btnPan;
	private: System::Windows::Forms::Button *  btnZoom;
	private: System::Windows::Forms::Button *  btnDolly;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::TextBox *  txtLightZ;
	private: System::Windows::Forms::Button *  btnLightZ;
	private: System::Windows::Forms::TextBox *  txtLightY;
	private: System::Windows::Forms::Button *  btnLightY;
	private: System::Windows::Forms::TextBox *  txtLightX;
	private: System::Windows::Forms::Button *  btnLightX;
	public: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::CheckBox *  chkShadow;
	private: System::Windows::Forms::TextBox *  txtGridWidth;
	private: System::Windows::Forms::Button *  btnWidth;
	public: System::Windows::Forms::RadioButton *  rdbCheck;
	public: System::Windows::Forms::RadioButton *  rdbGrid;
	public: System::Windows::Forms::RadioButton *  rdbNon;
	private: System::Windows::Forms::CheckBox *  chkWireframe;
	public: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::Label *  label10;

	private: System::Windows::Forms::TextBox *  txtHeight;
	private: System::Windows::Forms::Button *  btnHeight;
	private: System::Windows::Forms::Button *  btnStop;
	private: System::Windows::Forms::Button *  btnStart;


	private: System::Windows::Forms::TextBox *  txtDeltaTime;
	private: System::Windows::Forms::Label *  label9;
	private: System::Windows::Forms::TextBox *  txtDrawTime;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::TextBox *  txtNumFrame;
	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::Label *  label6;
	private: System::Windows::Forms::TextBox *  txtDirection;
	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::Label *  label3;
	private: System::Windows::Forms::TextBox *  txtBeta;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::TextBox *  txtSpeed;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Button *  btnReady;
	private: System::Windows::Forms::Label *  label11;
	private: System::Windows::Forms::TextBox *  txtRestitution;
	private: System::Windows::Forms::Label *  label12;
	private: System::Windows::Forms::TextBox *  txtFriction;
	private: System::Windows::Forms::Label *  label13;
	private: System::Windows::Forms::TextBox *  txtOmega;
	private: System::Windows::Forms::Label *  label14;
	private: System::Windows::Forms::Label *  label15;
	private: System::Windows::Forms::TextBox *  txtForceX;
	private: System::Windows::Forms::TextBox *  txtForceY;
	private: System::Windows::Forms::Label *  label16;
	private: System::Windows::Forms::Label *  label17;
	private: System::Windows::Forms::TextBox *  txtMass;
	private: System::Windows::Forms::Label *  label18;
	private: System::Windows::Forms::Label *  label19;
	private: System::Windows::Forms::TextBox *  txtDrag;
	private: System::Windows::Forms::Label *  label20;
	private: System::Windows::Forms::Label *  label21;
	private: System::Windows::Forms::TextBox *  txtResistance;
	private: System::Windows::Forms::Label *  label22;
	private: System::Windows::Forms::Button *  btnStep;
	private: System::Windows::Forms::RadioButton *  rdbSphere;
	private: System::Windows::Forms::RadioButton *  rdbCube;
	private: System::Windows::Forms::RadioButton *  rdbCylinder;
	private: System::Windows::Forms::Label *  label23;
	private: System::Windows::Forms::TextBox *  txtRotX;
	private: System::Windows::Forms::TextBox *  txtRotY;
	private: System::Windows::Forms::TextBox *  txtRotZ;
	private: System::Windows::Forms::Label *  label24;
	private: System::Windows::Forms::TextBox *  txtAxisX;
	private: System::Windows::Forms::TextBox *  txtAxisY;
	private: System::Windows::Forms::TextBox *  txtAxisZ;
	private: System::Windows::Forms::CheckBox *  chkTrack;
	private: System::Windows::Forms::Label *  label25;

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->btnCrane = new System::Windows::Forms::Button();
			this->btnTilt = new System::Windows::Forms::Button();
			this->btnTumble = new System::Windows::Forms::Button();
			this->btnPan = new System::Windows::Forms::Button();
			this->btnZoom = new System::Windows::Forms::Button();
			this->btnDolly = new System::Windows::Forms::Button();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->txtLightZ = new System::Windows::Forms::TextBox();
			this->btnLightZ = new System::Windows::Forms::Button();
			this->txtLightY = new System::Windows::Forms::TextBox();
			this->btnLightY = new System::Windows::Forms::Button();
			this->txtLightX = new System::Windows::Forms::TextBox();
			this->btnLightX = new System::Windows::Forms::Button();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->chkShadow = new System::Windows::Forms::CheckBox();
			this->txtGridWidth = new System::Windows::Forms::TextBox();
			this->btnWidth = new System::Windows::Forms::Button();
			this->rdbCheck = new System::Windows::Forms::RadioButton();
			this->rdbGrid = new System::Windows::Forms::RadioButton();
			this->rdbNon = new System::Windows::Forms::RadioButton();
			this->chkWireframe = new System::Windows::Forms::CheckBox();
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->txtAxisZ = new System::Windows::Forms::TextBox();
			this->txtAxisY = new System::Windows::Forms::TextBox();
			this->txtAxisX = new System::Windows::Forms::TextBox();
			this->label24 = new System::Windows::Forms::Label();
			this->txtRotZ = new System::Windows::Forms::TextBox();
			this->txtRotY = new System::Windows::Forms::TextBox();
			this->txtRotX = new System::Windows::Forms::TextBox();
			this->label23 = new System::Windows::Forms::Label();
			this->rdbCylinder = new System::Windows::Forms::RadioButton();
			this->rdbCube = new System::Windows::Forms::RadioButton();
			this->rdbSphere = new System::Windows::Forms::RadioButton();
			this->btnStep = new System::Windows::Forms::Button();
			this->label22 = new System::Windows::Forms::Label();
			this->txtResistance = new System::Windows::Forms::TextBox();
			this->label21 = new System::Windows::Forms::Label();
			this->label20 = new System::Windows::Forms::Label();
			this->txtDrag = new System::Windows::Forms::TextBox();
			this->label19 = new System::Windows::Forms::Label();
			this->label18 = new System::Windows::Forms::Label();
			this->txtMass = new System::Windows::Forms::TextBox();
			this->label17 = new System::Windows::Forms::Label();
			this->label16 = new System::Windows::Forms::Label();
			this->txtForceY = new System::Windows::Forms::TextBox();
			this->txtForceX = new System::Windows::Forms::TextBox();
			this->label15 = new System::Windows::Forms::Label();
			this->label14 = new System::Windows::Forms::Label();
			this->txtOmega = new System::Windows::Forms::TextBox();
			this->label13 = new System::Windows::Forms::Label();
			this->txtFriction = new System::Windows::Forms::TextBox();
			this->label12 = new System::Windows::Forms::Label();
			this->txtRestitution = new System::Windows::Forms::TextBox();
			this->label11 = new System::Windows::Forms::Label();
			this->label10 = new System::Windows::Forms::Label();
			this->txtHeight = new System::Windows::Forms::TextBox();
			this->btnHeight = new System::Windows::Forms::Button();
			this->btnStop = new System::Windows::Forms::Button();
			this->btnStart = new System::Windows::Forms::Button();
			this->txtDeltaTime = new System::Windows::Forms::TextBox();
			this->label9 = new System::Windows::Forms::Label();
			this->txtDrawTime = new System::Windows::Forms::TextBox();
			this->label8 = new System::Windows::Forms::Label();
			this->txtNumFrame = new System::Windows::Forms::TextBox();
			this->label7 = new System::Windows::Forms::Label();
			this->label6 = new System::Windows::Forms::Label();
			this->txtDirection = new System::Windows::Forms::TextBox();
			this->label5 = new System::Windows::Forms::Label();
			this->label4 = new System::Windows::Forms::Label();
			this->label3 = new System::Windows::Forms::Label();
			this->txtBeta = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->txtSpeed = new System::Windows::Forms::TextBox();
			this->label1 = new System::Windows::Forms::Label();
			this->btnReady = new System::Windows::Forms::Button();
			this->chkTrack = new System::Windows::Forms::CheckBox();
			this->label25 = new System::Windows::Forms::Label();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->btnCrane);
			this->groupBox2->Controls->Add(this->btnTilt);
			this->groupBox2->Controls->Add(this->btnTumble);
			this->groupBox2->Controls->Add(this->btnPan);
			this->groupBox2->Controls->Add(this->btnZoom);
			this->groupBox2->Controls->Add(this->btnDolly);
			this->groupBox2->Location = System::Drawing::Point(224, 192);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(128, 96);
			this->groupBox2->TabIndex = 33;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Camera";
			// 
			// btnCrane
			// 
			this->btnCrane->Location = System::Drawing::Point(56, 62);
			this->btnCrane->Name = S"btnCrane";
			this->btnCrane->Size = System::Drawing::Size(64, 21);
			this->btnCrane->TabIndex = 5;
			this->btnCrane->Text = S"Crane";
			this->btnCrane->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnCrane_MouseDown);
			// 
			// btnTilt
			// 
			this->btnTilt->Location = System::Drawing::Point(8, 62);
			this->btnTilt->Name = S"btnTilt";
			this->btnTilt->Size = System::Drawing::Size(48, 21);
			this->btnTilt->TabIndex = 4;
			this->btnTilt->Text = S"Tilt";
			this->btnTilt->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTilt_MouseDown);
			// 
			// btnTumble
			// 
			this->btnTumble->Location = System::Drawing::Point(56, 41);
			this->btnTumble->Name = S"btnTumble";
			this->btnTumble->Size = System::Drawing::Size(64, 21);
			this->btnTumble->TabIndex = 3;
			this->btnTumble->Text = S"Tumble";
			this->btnTumble->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTumble_MouseDown);
			// 
			// btnPan
			// 
			this->btnPan->Location = System::Drawing::Point(8, 41);
			this->btnPan->Name = S"btnPan";
			this->btnPan->Size = System::Drawing::Size(48, 21);
			this->btnPan->TabIndex = 2;
			this->btnPan->Text = S"Pan";
			this->btnPan->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnPan_MouseDown);
			// 
			// btnZoom
			// 
			this->btnZoom->Location = System::Drawing::Point(56, 18);
			this->btnZoom->Name = S"btnZoom";
			this->btnZoom->Size = System::Drawing::Size(64, 22);
			this->btnZoom->TabIndex = 1;
			this->btnZoom->Text = S"Zoom";
			this->btnZoom->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnZoom_MouseDown);
			// 
			// btnDolly
			// 
			this->btnDolly->Location = System::Drawing::Point(8, 18);
			this->btnDolly->Name = S"btnDolly";
			this->btnDolly->Size = System::Drawing::Size(48, 22);
			this->btnDolly->TabIndex = 0;
			this->btnDolly->Text = S"Dolly";
			this->btnDolly->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDolly_MouseDown);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->txtLightZ);
			this->groupBox3->Controls->Add(this->btnLightZ);
			this->groupBox3->Controls->Add(this->txtLightY);
			this->groupBox3->Controls->Add(this->btnLightY);
			this->groupBox3->Controls->Add(this->txtLightX);
			this->groupBox3->Controls->Add(this->btnLightX);
			this->groupBox3->Location = System::Drawing::Point(360, 192);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(80, 96);
			this->groupBox3->TabIndex = 34;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Light";
			// 
			// txtLightZ
			// 
			this->txtLightZ->Location = System::Drawing::Point(32, 64);
			this->txtLightZ->Name = S"txtLightZ";
			this->txtLightZ->Size = System::Drawing::Size(34, 22);
			this->txtLightZ->TabIndex = 5;
			this->txtLightZ->Text = S"";
			// 
			// btnLightZ
			// 
			this->btnLightZ->Location = System::Drawing::Point(8, 64);
			this->btnLightZ->Name = S"btnLightZ";
			this->btnLightZ->Size = System::Drawing::Size(24, 22);
			this->btnLightZ->TabIndex = 4;
			this->btnLightZ->Text = S"Z";
			this->btnLightZ->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightZ_MouseDown);
			// 
			// txtLightY
			// 
			this->txtLightY->Location = System::Drawing::Point(32, 40);
			this->txtLightY->Name = S"txtLightY";
			this->txtLightY->Size = System::Drawing::Size(33, 22);
			this->txtLightY->TabIndex = 3;
			this->txtLightY->Text = S"";
			// 
			// btnLightY
			// 
			this->btnLightY->Location = System::Drawing::Point(8, 40);
			this->btnLightY->Name = S"btnLightY";
			this->btnLightY->Size = System::Drawing::Size(24, 24);
			this->btnLightY->TabIndex = 2;
			this->btnLightY->Text = S"Y";
			this->btnLightY->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightY_MouseDown);
			// 
			// txtLightX
			// 
			this->txtLightX->Location = System::Drawing::Point(32, 16);
			this->txtLightX->Name = S"txtLightX";
			this->txtLightX->Size = System::Drawing::Size(32, 22);
			this->txtLightX->TabIndex = 1;
			this->txtLightX->Text = S"";
			// 
			// btnLightX
			// 
			this->btnLightX->Location = System::Drawing::Point(8, 16);
			this->btnLightX->Name = S"btnLightX";
			this->btnLightX->Size = System::Drawing::Size(24, 24);
			this->btnLightX->TabIndex = 0;
			this->btnLightX->Text = S"X";
			this->btnLightX->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightX_MouseDown);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->chkShadow);
			this->groupBox4->Controls->Add(this->txtGridWidth);
			this->groupBox4->Controls->Add(this->btnWidth);
			this->groupBox4->Controls->Add(this->rdbCheck);
			this->groupBox4->Controls->Add(this->rdbGrid);
			this->groupBox4->Controls->Add(this->rdbNon);
			this->groupBox4->Location = System::Drawing::Point(0, 192);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(216, 72);
			this->groupBox4->TabIndex = 32;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Floor";
			// 
			// chkShadow
			// 
			this->chkShadow->Location = System::Drawing::Point(112, 40);
			this->chkShadow->Name = S"chkShadow";
			this->chkShadow->Size = System::Drawing::Size(88, 16);
			this->chkShadow->TabIndex = 5;
			this->chkShadow->Text = S"Shadow";
			this->chkShadow->CheckedChanged += new System::EventHandler(this, &Form1::chkShadow_CheckedChanged);
			// 
			// txtGridWidth
			// 
			this->txtGridWidth->Location = System::Drawing::Point(64, 40);
			this->txtGridWidth->Name = S"txtGridWidth";
			this->txtGridWidth->Size = System::Drawing::Size(40, 22);
			this->txtGridWidth->TabIndex = 4;
			this->txtGridWidth->Text = S"";
			// 
			// btnWidth
			// 
			this->btnWidth->Location = System::Drawing::Point(8, 40);
			this->btnWidth->Name = S"btnWidth";
			this->btnWidth->Size = System::Drawing::Size(56, 24);
			this->btnWidth->TabIndex = 3;
			this->btnWidth->Text = S"Width";
			this->btnWidth->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnWidth_MouseDown);
			// 
			// rdbCheck
			// 
			this->rdbCheck->Location = System::Drawing::Point(136, 16);
			this->rdbCheck->Name = S"rdbCheck";
			this->rdbCheck->Size = System::Drawing::Size(72, 24);
			this->rdbCheck->TabIndex = 2;
			this->rdbCheck->Text = S"Check";
			this->rdbCheck->CheckedChanged += new System::EventHandler(this, &Form1::rdbCheck_CheckedChanged);
			// 
			// rdbGrid
			// 
			this->rdbGrid->Checked = true;
			this->rdbGrid->Location = System::Drawing::Point(76, 16);
			this->rdbGrid->Name = S"rdbGrid";
			this->rdbGrid->Size = System::Drawing::Size(72, 24);
			this->rdbGrid->TabIndex = 1;
			this->rdbGrid->TabStop = true;
			this->rdbGrid->Text = S"Grid";
			this->rdbGrid->CheckedChanged += new System::EventHandler(this, &Form1::rdbGrid_CheckedChanged);
			// 
			// rdbNon
			// 
			this->rdbNon->Location = System::Drawing::Point(16, 16);
			this->rdbNon->Name = S"rdbNon";
			this->rdbNon->Size = System::Drawing::Size(56, 24);
			this->rdbNon->TabIndex = 0;
			this->rdbNon->Text = S"Non";
			this->rdbNon->CheckedChanged += new System::EventHandler(this, &Form1::rdbNon_CheckedChanged);
			// 
			// chkWireframe
			// 
			this->chkWireframe->Location = System::Drawing::Point(8, 264);
			this->chkWireframe->Name = S"chkWireframe";
			this->chkWireframe->Size = System::Drawing::Size(96, 24);
			this->chkWireframe->TabIndex = 35;
			this->chkWireframe->Text = S"Wireframe";
			this->chkWireframe->CheckedChanged += new System::EventHandler(this, &Form1::chkWireframe_CheckedChanged);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label25);
			this->groupBox1->Controls->Add(this->txtAxisZ);
			this->groupBox1->Controls->Add(this->txtAxisY);
			this->groupBox1->Controls->Add(this->txtAxisX);
			this->groupBox1->Controls->Add(this->label24);
			this->groupBox1->Controls->Add(this->txtRotZ);
			this->groupBox1->Controls->Add(this->txtRotY);
			this->groupBox1->Controls->Add(this->txtRotX);
			this->groupBox1->Controls->Add(this->label23);
			this->groupBox1->Controls->Add(this->rdbCylinder);
			this->groupBox1->Controls->Add(this->rdbCube);
			this->groupBox1->Controls->Add(this->rdbSphere);
			this->groupBox1->Controls->Add(this->btnStep);
			this->groupBox1->Controls->Add(this->label22);
			this->groupBox1->Controls->Add(this->txtResistance);
			this->groupBox1->Controls->Add(this->label21);
			this->groupBox1->Controls->Add(this->label20);
			this->groupBox1->Controls->Add(this->txtDrag);
			this->groupBox1->Controls->Add(this->label19);
			this->groupBox1->Controls->Add(this->label18);
			this->groupBox1->Controls->Add(this->txtMass);
			this->groupBox1->Controls->Add(this->label17);
			this->groupBox1->Controls->Add(this->label16);
			this->groupBox1->Controls->Add(this->txtForceY);
			this->groupBox1->Controls->Add(this->txtForceX);
			this->groupBox1->Controls->Add(this->label15);
			this->groupBox1->Controls->Add(this->label14);
			this->groupBox1->Controls->Add(this->txtOmega);
			this->groupBox1->Controls->Add(this->label13);
			this->groupBox1->Controls->Add(this->txtFriction);
			this->groupBox1->Controls->Add(this->label12);
			this->groupBox1->Controls->Add(this->txtRestitution);
			this->groupBox1->Controls->Add(this->label11);
			this->groupBox1->Controls->Add(this->label10);
			this->groupBox1->Controls->Add(this->txtHeight);
			this->groupBox1->Controls->Add(this->btnHeight);
			this->groupBox1->Controls->Add(this->btnStop);
			this->groupBox1->Controls->Add(this->btnStart);
			this->groupBox1->Controls->Add(this->txtDeltaTime);
			this->groupBox1->Controls->Add(this->label9);
			this->groupBox1->Controls->Add(this->txtDrawTime);
			this->groupBox1->Controls->Add(this->label8);
			this->groupBox1->Controls->Add(this->txtNumFrame);
			this->groupBox1->Controls->Add(this->label7);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->txtDirection);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->txtBeta);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->txtSpeed);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->btnReady);
			this->groupBox1->Location = System::Drawing::Point(0, 8);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(496, 184);
			this->groupBox1->TabIndex = 31;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Animation";
			// 
			// txtAxisZ
			// 
			this->txtAxisZ->Location = System::Drawing::Point(136, 152);
			this->txtAxisZ->Name = S"txtAxisZ";
			this->txtAxisZ->Size = System::Drawing::Size(32, 22);
			this->txtAxisZ->TabIndex = 55;
			this->txtAxisZ->Text = S"Z";
			// 
			// txtAxisY
			// 
			this->txtAxisY->Location = System::Drawing::Point(104, 152);
			this->txtAxisY->Name = S"txtAxisY";
			this->txtAxisY->Size = System::Drawing::Size(32, 22);
			this->txtAxisY->TabIndex = 54;
			this->txtAxisY->Text = S"Y";
			// 
			// txtAxisX
			// 
			this->txtAxisX->Location = System::Drawing::Point(72, 152);
			this->txtAxisX->Name = S"txtAxisX";
			this->txtAxisX->Size = System::Drawing::Size(32, 22);
			this->txtAxisX->TabIndex = 53;
			this->txtAxisX->Text = S"X";
			// 
			// label24
			// 
			this->label24->Location = System::Drawing::Point(16, 152);
			this->label24->Name = S"label24";
			this->label24->Size = System::Drawing::Size(56, 16);
			this->label24->TabIndex = 52;
			this->label24->Text = S"��]��";
			// 
			// txtRotZ
			// 
			this->txtRotZ->Location = System::Drawing::Point(136, 128);
			this->txtRotZ->Name = S"txtRotZ";
			this->txtRotZ->Size = System::Drawing::Size(32, 22);
			this->txtRotZ->TabIndex = 51;
			this->txtRotZ->Text = S"Z";
			// 
			// txtRotY
			// 
			this->txtRotY->Location = System::Drawing::Point(104, 128);
			this->txtRotY->Name = S"txtRotY";
			this->txtRotY->Size = System::Drawing::Size(32, 22);
			this->txtRotY->TabIndex = 50;
			this->txtRotY->Text = S"Y";
			// 
			// txtRotX
			// 
			this->txtRotX->Location = System::Drawing::Point(72, 128);
			this->txtRotX->Name = S"txtRotX";
			this->txtRotX->Size = System::Drawing::Size(32, 22);
			this->txtRotX->TabIndex = 49;
			this->txtRotX->Text = S"X";
			// 
			// label23
			// 
			this->label23->Location = System::Drawing::Point(8, 128);
			this->label23->Name = S"label23";
			this->label23->Size = System::Drawing::Size(72, 16);
			this->label23->TabIndex = 48;
			this->label23->Text = S"�����p��";
			// 
			// rdbCylinder
			// 
			this->rdbCylinder->Location = System::Drawing::Point(112, 104);
			this->rdbCylinder->Name = S"rdbCylinder";
			this->rdbCylinder->Size = System::Drawing::Size(56, 24);
			this->rdbCylinder->TabIndex = 47;
			this->rdbCylinder->Text = S"�~��";
			// 
			// rdbCube
			// 
			this->rdbCube->Location = System::Drawing::Point(56, 104);
			this->rdbCube->Name = S"rdbCube";
			this->rdbCube->Size = System::Drawing::Size(56, 24);
			this->rdbCube->TabIndex = 46;
			this->rdbCube->Text = S"�p��";
			// 
			// rdbSphere
			// 
			this->rdbSphere->Checked = true;
			this->rdbSphere->Location = System::Drawing::Point(16, 104);
			this->rdbSphere->Name = S"rdbSphere";
			this->rdbSphere->Size = System::Drawing::Size(48, 24);
			this->rdbSphere->TabIndex = 45;
			this->rdbSphere->TabStop = true;
			this->rdbSphere->Text = S"��";
			// 
			// btnStep
			// 
			this->btnStep->Location = System::Drawing::Point(432, 136);
			this->btnStep->Name = S"btnStep";
			this->btnStep->Size = System::Drawing::Size(48, 32);
			this->btnStep->TabIndex = 44;
			this->btnStep->Text = S"Step";
			this->btnStep->Click += new System::EventHandler(this, &Form1::btnStep_Click);
			// 
			// label22
			// 
			this->label22->Location = System::Drawing::Point(440, 80);
			this->label22->Name = S"label22";
			this->label22->Size = System::Drawing::Size(40, 16);
			this->label22->TabIndex = 43;
			this->label22->Text = S"Kg/s";
			// 
			// txtResistance
			// 
			this->txtResistance->Location = System::Drawing::Point(408, 72);
			this->txtResistance->Name = S"txtResistance";
			this->txtResistance->Size = System::Drawing::Size(32, 22);
			this->txtResistance->TabIndex = 42;
			this->txtResistance->Text = S"";
			// 
			// label21
			// 
			this->label21->Location = System::Drawing::Point(312, 72);
			this->label21->Name = S"label21";
			this->label21->Size = System::Drawing::Size(104, 16);
			this->label21->TabIndex = 41;
			this->label21->Text = S"������R�W��";
			// 
			// label20
			// 
			this->label20->Location = System::Drawing::Point(440, 56);
			this->label20->Name = S"label20";
			this->label20->Size = System::Drawing::Size(48, 16);
			this->label20->TabIndex = 40;
			this->label20->Text = S"Kg/m";
			// 
			// txtDrag
			// 
			this->txtDrag->Location = System::Drawing::Point(408, 48);
			this->txtDrag->Name = S"txtDrag";
			this->txtDrag->Size = System::Drawing::Size(32, 22);
			this->txtDrag->TabIndex = 39;
			this->txtDrag->Text = S"";
			// 
			// label19
			// 
			this->label19->Location = System::Drawing::Point(312, 48);
			this->label19->Name = S"label19";
			this->label19->Size = System::Drawing::Size(104, 16);
			this->label19->TabIndex = 38;
			this->label19->Text = S"�S����R�W��";
			// 
			// label18
			// 
			this->label18->Location = System::Drawing::Point(400, 24);
			this->label18->Name = S"label18";
			this->label18->Size = System::Drawing::Size(32, 16);
			this->label18->TabIndex = 37;
			this->label18->Text = S"Kg";
			// 
			// txtMass
			// 
			this->txtMass->Location = System::Drawing::Point(360, 16);
			this->txtMass->Name = S"txtMass";
			this->txtMass->Size = System::Drawing::Size(40, 22);
			this->txtMass->TabIndex = 36;
			this->txtMass->Text = S"";
			// 
			// label17
			// 
			this->label17->Location = System::Drawing::Point(328, 16);
			this->label17->Name = S"label17";
			this->label17->Size = System::Drawing::Size(40, 16);
			this->label17->TabIndex = 35;
			this->label17->Text = S"����";
			// 
			// label16
			// 
			this->label16->Location = System::Drawing::Point(264, 104);
			this->label16->Name = S"label16";
			this->label16->Size = System::Drawing::Size(16, 16);
			this->label16->TabIndex = 34;
			this->label16->Text = S"N";
			// 
			// txtForceY
			// 
			this->txtForceY->Location = System::Drawing::Point(232, 96);
			this->txtForceY->Name = S"txtForceY";
			this->txtForceY->Size = System::Drawing::Size(32, 22);
			this->txtForceY->TabIndex = 33;
			this->txtForceY->Text = S"Y";
			// 
			// txtForceX
			// 
			this->txtForceX->Location = System::Drawing::Point(200, 96);
			this->txtForceX->Name = S"txtForceX";
			this->txtForceX->Size = System::Drawing::Size(32, 22);
			this->txtForceX->TabIndex = 32;
			this->txtForceX->Text = S"X";
			// 
			// label15
			// 
			this->label15->Location = System::Drawing::Point(168, 104);
			this->label15->Name = S"label15";
			this->label15->Size = System::Drawing::Size(40, 16);
			this->label15->TabIndex = 31;
			this->label15->Text = S"�O��";
			// 
			// label14
			// 
			this->label14->Location = System::Drawing::Point(232, 72);
			this->label14->Name = S"label14";
			this->label14->Size = System::Drawing::Size(48, 16);
			this->label14->TabIndex = 30;
			this->label14->Text = S"deg/sec";
			// 
			// txtOmega
			// 
			this->txtOmega->Location = System::Drawing::Point(184, 72);
			this->txtOmega->Name = S"txtOmega";
			this->txtOmega->Size = System::Drawing::Size(48, 22);
			this->txtOmega->TabIndex = 29;
			this->txtOmega->Text = S"";
			// 
			// label13
			// 
			this->label13->Location = System::Drawing::Point(136, 72);
			this->label13->Name = S"label13";
			this->label13->Size = System::Drawing::Size(56, 16);
			this->label13->TabIndex = 28;
			this->label13->Text = S"�p���x";
			// 
			// txtFriction
			// 
			this->txtFriction->Location = System::Drawing::Point(72, 80);
			this->txtFriction->Name = S"txtFriction";
			this->txtFriction->Size = System::Drawing::Size(40, 22);
			this->txtFriction->TabIndex = 27;
			this->txtFriction->Text = S"";
			// 
			// label12
			// 
			this->label12->Location = System::Drawing::Point(8, 80);
			this->label12->Name = S"label12";
			this->label12->Size = System::Drawing::Size(72, 16);
			this->label12->TabIndex = 26;
			this->label12->Text = S"���C�W��";
			// 
			// txtRestitution
			// 
			this->txtRestitution->Location = System::Drawing::Point(72, 56);
			this->txtRestitution->Name = S"txtRestitution";
			this->txtRestitution->Size = System::Drawing::Size(40, 22);
			this->txtRestitution->TabIndex = 25;
			this->txtRestitution->Text = S"";
			// 
			// label11
			// 
			this->label11->Location = System::Drawing::Point(8, 56);
			this->label11->Name = S"label11";
			this->label11->Size = System::Drawing::Size(72, 16);
			this->label11->TabIndex = 24;
			this->label11->Text = S"�����W��";
			// 
			// label10
			// 
			this->label10->Location = System::Drawing::Point(288, 40);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(24, 16);
			this->label10->TabIndex = 23;
			this->label10->Text = S"m";
			// 
			// txtHeight
			// 
			this->txtHeight->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtHeight->Location = System::Drawing::Point(248, 40);
			this->txtHeight->Name = S"txtHeight";
			this->txtHeight->Size = System::Drawing::Size(40, 22);
			this->txtHeight->TabIndex = 21;
			this->txtHeight->Text = S"";
			// 
			// btnHeight
			// 
			this->btnHeight->Location = System::Drawing::Point(208, 40);
			this->btnHeight->Name = S"btnHeight";
			this->btnHeight->Size = System::Drawing::Size(40, 24);
			this->btnHeight->TabIndex = 20;
			this->btnHeight->Text = S"����";
			this->btnHeight->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnHeight_MouseDown);
			// 
			// btnStop
			// 
			this->btnStop->Location = System::Drawing::Point(376, 136);
			this->btnStop->Name = S"btnStop";
			this->btnStop->Size = System::Drawing::Size(48, 32);
			this->btnStop->TabIndex = 19;
			this->btnStop->Text = S"Stop";
			this->btnStop->Click += new System::EventHandler(this, &Form1::btnStop_Click);
			// 
			// btnStart
			// 
			this->btnStart->Location = System::Drawing::Point(320, 136);
			this->btnStart->Name = S"btnStart";
			this->btnStart->Size = System::Drawing::Size(48, 32);
			this->btnStart->TabIndex = 18;
			this->btnStart->Text = S"Start";
			this->btnStart->Click += new System::EventHandler(this, &Form1::btnStart_Click);
			// 
			// txtDeltaTime
			// 
			this->txtDeltaTime->Location = System::Drawing::Point(240, 152);
			this->txtDeltaTime->Name = S"txtDeltaTime";
			this->txtDeltaTime->Size = System::Drawing::Size(64, 22);
			this->txtDeltaTime->TabIndex = 15;
			this->txtDeltaTime->Text = S"";
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(208, 152);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(40, 16);
			this->label9->TabIndex = 14;
			this->label9->Text = S"����";
			// 
			// txtDrawTime
			// 
			this->txtDrawTime->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtDrawTime->Location = System::Drawing::Point(240, 128);
			this->txtDrawTime->Name = S"txtDrawTime";
			this->txtDrawTime->Size = System::Drawing::Size(64, 22);
			this->txtDrawTime->TabIndex = 13;
			this->txtDrawTime->Text = S"";
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(208, 128);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(40, 16);
			this->label8->TabIndex = 12;
			this->label8->Text = S"�`��";
			// 
			// txtNumFrame
			// 
			this->txtNumFrame->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtNumFrame->Location = System::Drawing::Point(400, 104);
			this->txtNumFrame->Name = S"txtNumFrame";
			this->txtNumFrame->Size = System::Drawing::Size(56, 22);
			this->txtNumFrame->TabIndex = 11;
			this->txtNumFrame->Text = S"";
			// 
			// label7
			// 
			this->label7->Location = System::Drawing::Point(352, 104);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(48, 16);
			this->label7->TabIndex = 10;
			this->label7->Text = S"�R�}��";
			// 
			// label6
			// 
			this->label6->Location = System::Drawing::Point(288, 16);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(32, 16);
			this->label6->TabIndex = 9;
			this->label6->Text = S"deg";
			// 
			// txtDirection
			// 
			this->txtDirection->Location = System::Drawing::Point(248, 16);
			this->txtDirection->Name = S"txtDirection";
			this->txtDirection->Size = System::Drawing::Size(40, 22);
			this->txtDirection->TabIndex = 8;
			this->txtDirection->Text = S"";
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(216, 16);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(40, 16);
			this->label5->TabIndex = 7;
			this->label5->Text = S"����";
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(176, 48);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(48, 16);
			this->label4->TabIndex = 6;
			this->label4->Text = S"deg";
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(176, 24);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(32, 16);
			this->label3->TabIndex = 5;
			this->label3->Text = S"m/s";
			// 
			// txtBeta
			// 
			this->txtBeta->Location = System::Drawing::Point(136, 40);
			this->txtBeta->Name = S"txtBeta";
			this->txtBeta->Size = System::Drawing::Size(40, 22);
			this->txtBeta->TabIndex = 4;
			this->txtBeta->Text = S"";
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(88, 40);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(56, 16);
			this->label2->TabIndex = 3;
			this->label2->Text = S"���ˊp";
			// 
			// txtSpeed
			// 
			this->txtSpeed->Location = System::Drawing::Point(136, 16);
			this->txtSpeed->Name = S"txtSpeed";
			this->txtSpeed->Size = System::Drawing::Size(40, 22);
			this->txtSpeed->TabIndex = 2;
			this->txtSpeed->Text = S"";
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(88, 16);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(56, 24);
			this->label1->TabIndex = 1;
			this->label1->Text = S"�����x";
			// 
			// btnReady
			// 
			this->btnReady->Location = System::Drawing::Point(8, 16);
			this->btnReady->Name = S"btnReady";
			this->btnReady->Size = System::Drawing::Size(72, 32);
			this->btnReady->TabIndex = 0;
			this->btnReady->Text = S"Ready";
			this->btnReady->Click += new System::EventHandler(this, &Form1::btnReady_Click);
			// 
			// chkTrack
			// 
			this->chkTrack->Location = System::Drawing::Point(144, 264);
			this->chkTrack->Name = S"chkTrack";
			this->chkTrack->Size = System::Drawing::Size(64, 24);
			this->chkTrack->TabIndex = 36;
			this->chkTrack->Text = S"Track";
			// 
			// label25
			// 
			this->label25->Location = System::Drawing::Point(304, 144);
			this->label25->Name = S"label25";
			this->label25->Size = System::Drawing::Size(16, 16);
			this->label25->TabIndex = 56;
			this->label25->Text = S"s";
			// 
			// Form1
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(7, 15);
			this->ClientSize = System::Drawing::Size(504, 291);
			this->Controls->Add(this->chkTrack);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->chkWireframe);
			this->Controls->Add(this->groupBox1);
			this->Name = S"Form1";
			this->Text = S"Projectile�U(�����^��)";
			this->Load += new System::EventHandler(this, &Form1::Form1_Load);
			this->Closed += new System::EventHandler(this, &Form1::Form1_Closed);
			this->groupBox2->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->ResumeLayout(false);

		}	


//------------------------------------------------------------------------------
	SpaceForm* spaceForm;//�R�����`��t�H�[���̃C���X�^���X
	bool flagStart;//�A�j���[�V�������s�t���O
	bool flagStep;//�X�e�b�v���s�t���O
    double speed;//�����^���̑��x
    double dir;//����
	double beta;//���ˊp
	double height;//����
	double ci, cv, mu, e;
	static double g = 9.8;//�d�͉����x
	static double pp = M_PI / 180.0;
    float t;//���̎��Ԍo�߁i���ԍ���dt�̘a�j
	int numFrame;//���R�}��

private: System::Void Form1_Load(System::Object *  sender, System::EventArgs *  e)
	{
		//Form�̈ʒu
		Left = 100;
		Top = 100;
		//SpaceForm��\��
		spaceForm = new SpaceForm();
		spaceForm -> Show();
		//Floor�̏����l
		gridWidth = 1.0;
        txtGridWidth->Text = gridWidth.ToString();

		txtDeltaTime->Text = S"0.001";//�������ԑ���(s)

		//���x,����,�����̏����ݒ�
		txtSpeed->Text = S"5.0";
		txtDirection->Text = S"0.0";
		txtBeta->Text = S"45.0";
		height = 0.2;
		txtHeight->Text = S"0.0";
		//�����p���i�I�C���[�p�j
		txtRotX->Text = S"0.0";
		txtRotY->Text = S"0.0";
		txtRotZ->Text = S"0.0";
		//�p���x
		txtOmega->Text ="1000.0";    
		//��]��
		txtAxisX->Text = S"0.0";
		txtAxisY->Text = S"0.0";
		txtAxisZ->Text = S"1.0";
		//��������
		txtMass->Text = S"1.0";      //����
		txtDrag->Text = S"0.1"; //�S����R�W��(v�ɔ�Ⴗ��)
		txtResistance->Text = S"0.2";//������R�W��(v^2�ɔ�Ⴗ��)
		txtRestitution->Text = S"0.5";//���ʂ̔����W��
		txtFriction->Text = S"0.2";  //���ʂ̓����C�W��
		//�O��
		txtForceX->Text = S"0.0";
		txtForceY->Text = S"0.0";
		//�����ʒu
        txtLightX->Text = light.x.ToString();
        txtLightY->Text = light.y.ToString();
        txtLightZ->Text = light.z.ToString();
	}

private: System::Void Form1_Closed(System::Object *  sender, System::EventArgs *  e)
	{
 		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);
	}

private: System::Void btnReady_Click(System::Object *  sender, System::EventArgs *  e)
	{
		//OpenGL����
		IntPtr ptr = spaceForm->picSpace->Handle;//�f�o�C�X�R���e�L�X�g�̃n���h��
		hWnd = (HWND)ptr.ToInt32();
		hDC = GetDC(hWnd);
		setup.initOpenGL();
		
		Image* im = Image::FromFile("../../bmp128/check1.bmp");
		Bitmap* bitmap = new Bitmap(im);

		//�`��I�u�W�F�N�g
		numTarget = 1;
		if(rdbSphere->Checked == true){
			target[0].kind = SPHERE;
			target[0].texType = T_SPHERICAL;
		}
		else if(rdbCube->Checked == true){
			target[0].kind = CUBE;
			target[0].texType = T_PLANAR2;
		}
		else { //�~��
			target[0].kind = CYLINDER;
			target[0].texType = T_CYLINDRICAL;
		}

		target[0].texMode = T_MODULATE;
		target[0].makeTexture(bitmap);
		target[0].vSize = CVector(0.4, 0.4, 0.4);

		target[0].diffuse[0] = 1.0f; //red
		target[0].diffuse[1] = 0.9f;
		target[0].diffuse[2] = 0.9f;
		initObject();

		t = 0;
		numFrame = 0;//�R�}���N���A
	    txtNumFrame->Text = numFrame.ToString();
		setCamera();
		display();
	}

	private: System::Void initObject()
	{
		//��������
		cv = Convert::ToDouble(txtDrag->Text);//��C�̔S����R�W��
		ci = Convert::ToDouble(txtResistance->Text);//��C�̊�����R�W��
		mu = Convert::ToDouble(txtFriction->Text);//�����C��R
		e = Convert::ToDouble(txtRestitution->Text);//���ʂƎ��_�̔����W��
		height = Convert::ToDouble(txtHeight->Text);
		target[0].mass = Convert::ToDouble(txtMass->Text);

		//�����ݒ�
		target[0].vPos0 = CVector(0.0, 0.0, 0.0);
		target[0].vPos0.z = target[0].vSize.z / 2.0f + height;//���S�̍���
		target[0].vPos = target[0].vPos0;
		speed = Convert::ToDouble(txtSpeed->Text);//m/s
		dir = Convert::ToDouble(txtDirection->Text);//�����ɑ΂�����ʊp�i�x�j
		beta = Convert::ToDouble(txtBeta->Text);
		double vh0 = speed * cos(beta * pp);//�����x�������� (�傫��)
		double vz0 = speed * sin(beta * pp);//�����x��������
		//�����x�̊e����
		target[0].vVelocity0.x = vh0 * cos(dir * pp);
		target[0].vVelocity0.y = vh0 * sin(dir * pp);
		target[0].vVelocity0.z = vz0;
		target[0].vVelocity = target[0].vVelocity0;
		//�O��(��ɕ��̂ɂ�����O�́j
		target[0].vForce0.x = Convert::ToDouble(txtForceX->Text);//���Ȃǂ̊O��
		target[0].vForce0.y = Convert::ToDouble(txtForceY->Text);
		target[0].vForce0.z = - g * (target[0].mass); //�����͏d�͂���
		//�����p���i�I�C���[�p�j
		target[0].vEuler.x = Convert::ToDouble(txtRotX->Text);
		target[0].vEuler.y = Convert::ToDouble(txtRotY->Text);
		target[0].vEuler.z = Convert::ToDouble(txtRotZ->Text);
		//�p���x
		target[0].omega0 = Convert::ToDouble(txtOmega->Text) * pp; //rad/s�P�ʂɕύX
		//��]��
		target[0].vAxis.x = Convert::ToDouble(txtAxisX->Text);
		target[0].vAxis.y = Convert::ToDouble(txtAxisY->Text);
		target[0].vAxis.z = Convert::ToDouble(txtAxisZ->Text);
		//�p���x
		target[0].vOmega = target[0].omega0 * target[0].vAxis;
	}

	private: System::Void display()
	{
	    int i;
		setup.set3DAmbient(spaceForm->picSpace);
		setup.setLight();
		setCamera();
		flagShadow = chkShadow->Checked;

		glClear(GL_COLOR_BUFFER_BIT); //�װ�ޯ̧��ر
		glClear(GL_DEPTH_BUFFER_BIT); //���߽�ޯ̧��ر
	    //���������̂�����Ƃ��͎���2�s���K�v
	    glCullFace(GL_BACK);   //���ʂ��폜
	    glEnable(GL_CULL_FACE);//���ʍ폜��L���ɂ���

		setup.drawFloor(rdbNon, rdbCheck);//setup.h

	    if(chkWireframe->Checked == true){//ܲ԰�ڰ�����
		    glPolygonMode(GL_FRONT,GL_LINE);
		    glPolygonMode(GL_BACK,GL_POINT);
	    }
				
		//�������̂�����Ƃ��͈ȉ��̂悤�ɕs�������̂��ɂ��ׂĕ`��
		for(i = 0; i < numTarget; i++) {
			if(target[i].diffuse[3] == 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_FALSE); //���߽�ޯ̧���������݋֎~
		glEnable(GL_BLEND);//��̧�����ިݸނ�L���ɂ���
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);//�F�����W�������߂�

		//���������̂�`��
		for(i=0;i<numTarget;i++) {
			if(target[i].diffuse[3] != 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_TRUE); //���߽�ޯ̧�̏������݂�����
		glDisable(GL_BLEND);

        setup.drawShadow();//setup.h

        glPopMatrix();
	    SwapBuffers(hDC);
    }

	private: System::Void setCamera()
	{
		if(chkTrack->Checked == true){
			camera.vCenter.x = target[0].vPos.x;
			camera.vCenter.y = target[0].vPos.y;
			camera.vCenter.z = target[0].vPos.z;
			camera.position();
		}
	}


	private: System::Void execute()
	{
		float drawTime, lapse;
		int h1, m1, s1, ms1;
		int h2, m2, s2, ms2;
		float dt;//��������
    
		//����
		dt = Convert::ToSingle(txtDeltaTime->Text);//�b�P�ʂŎw��

		txtDrawTime->Text = S" ";
		flagStart = true;

		Cursor = Cursors::AppStarting;//�J�[�\����ύX
		DateTime tStart = DateTime::Now;//���݂̎���
		h1 = tStart.Hour;
		m1 = tStart.Minute;
		s1 = tStart.Second;
		ms1 = tStart.Millisecond;

		int numFrame0 = 0;

		target[0].calcInertia();//�������[�����g�̌v�Z
		while(true){
			target[0].projection(e, mu, cv, ci, dt);//�����o�֐�
			//�����W��,�����C�W��,�S����R�W��,������R�W��,��������
			display();
			Application::DoEvents();//���̃C�x���g��҂�
			if( flagStart == false ) break;
			//�I�������i���ʂœ������������Ƃ��͐Î~��Ԃɂ���j
	/*        if(target[0].checkCollisionToFloor() < 0.01)
			{
				if(target[0].vVelocity.magnitude() < 0.01
				&& fabs(target[0].omega0/pp) < 10.0) break;
			}   */
			numFrame++;
			numFrame0++;
	//        if(numFrame == 500) break;
			if(flagStep == true) break;
		}

		Cursor = Cursors::Default;
		DateTime tStop = DateTime::Now;
		h2 = tStop.Hour;
		m2 = tStop.Minute;
		s2 = tStop.Second;
		ms2 = tStop.Millisecond;
		//�o�ߎ���(sec)
		lapse = (float)(h2-h1) * 3600.0f + (float)(m2-m1) * 60.0f + (float)(s2-s1) + (float)(ms2-ms1) / 1000.0f;
		//1�R�}������̕`�掞��(sec)
		drawTime = lapse / (float)numFrame0;
		txtDrawTime->Text = drawTime.ToString();//�e�L�X�g�{�b�N�X�ɕ\��
		txtNumFrame->Text = numFrame.ToString();//���R�}��
	}

private: System::Void btnHeight_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			height += 0.1;
		else
			height -= 0.1;
		txtHeight->Text = String::Format("{0:0.0}", __box(height));
		target[0].vPos.z = height;
		display();		 
	}

private: System::Void btnStart_Click(System::Object *  sender, System::EventArgs *  e)
	{
		execute();
	}

private: System::Void btnStop_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = false;
	}

private: System::Void btnStep_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStep = true;
		flagStep = true;
		execute();
	}

    private: System::Void rdbCheck_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbGrid_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbNon_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void btnWidth_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
         if(e->Button == MouseButtons::Left)
                gridWidth += 0.1f;
         else
                gridWidth -= 0.1f;
         txtGridWidth->Text = gridWidth.ToString();
         display();
    }

    private: System::Void chkShadow_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        flagShadow = chkShadow->Checked;
        display();
    }

    private: System::Void btnDolly_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.dist -= 0.5f;
        else
            camera.dist += 0.5f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnZoom_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.fov -= 0.1f;
        else
            camera.fov += 0.1f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnPan_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta += 1.0f; //deg
   	    else
            camera.theta -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTumble_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta -= 5.0f;
        else
            camera.theta += 5.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTilt_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 1.0f; //deg
   	    else
            camera.phi -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.vCenter.z = camera.vPos.z - camera.dist * (float)sin(pp * camera.phi);
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnCrane_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 2.0f;
        else
            camera.phi -= 2.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnLightX_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.x += 1.0f;
        else
            light.x -= 1.0f;
        txtLightX->Text = String::Format("{0:0.0}", __box(light.x));

        display();
    }

    private: System::Void btnLightY_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.y += 1.0f;
        else
            light.y -= 1.0f;
        txtLightY->Text = String::Format("{0:0.0}", __box(light.y));

        display();
    }

    private: System::Void btnLightZ_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.z += 1.0f;
        else
            light.z -= 1.0f;
        txtLightZ->Text = String::Format("{0:0.0}", __box(light.z));

        display();
    }


	private: System::Void chkWireframe_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
        setup.initOpenGL(); //Mode�؂�ւ����ɂ͕K�v
        display();
	}
};
}


