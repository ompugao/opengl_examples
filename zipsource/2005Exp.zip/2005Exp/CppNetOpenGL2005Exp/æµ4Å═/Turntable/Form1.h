#pragma once

#include "setup.h"
CSetup setup;
#include "SpaceForm.h"

namespace Turntable
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Form1 �̊T�v
	///
	/// �x�� : ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ 
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ����������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::GroupBox *  groupBox2;
	private: System::Windows::Forms::Button *  btnCrane;
	private: System::Windows::Forms::Button *  btnTilt;
	private: System::Windows::Forms::Button *  btnTumble;
	private: System::Windows::Forms::Button *  btnPan;
	private: System::Windows::Forms::Button *  btnZoom;
	private: System::Windows::Forms::Button *  btnDolly;
	public: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::CheckBox *  chkShadow;
	private: System::Windows::Forms::TextBox *  txtGridWidth;
	private: System::Windows::Forms::Button *  btnWidth;
	public: System::Windows::Forms::RadioButton *  rdbCheck;
	public: System::Windows::Forms::RadioButton *  rdbGrid;
	public: System::Windows::Forms::RadioButton *  rdbNon;
	private: System::Windows::Forms::CheckBox *  chkWireframe;
	public: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::Button *  btnStop;
	private: System::Windows::Forms::Button *  btnStart;
	private: System::Windows::Forms::TextBox *  txtDeltaTime;
	private: System::Windows::Forms::Label *  label9;
	private: System::Windows::Forms::TextBox *  txtDrawTime;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::TextBox *  txtNumFrame;
	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::TextBox *  txtMuStatic;
	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::Label *  label3;
	private: System::Windows::Forms::TextBox *  txtOmega;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::TextBox *  txtRadius;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Button *  btnReady;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::TextBox *  txtLightZ;
	private: System::Windows::Forms::Button *  btnLightZ;
	private: System::Windows::Forms::TextBox *  txtLightY;
	private: System::Windows::Forms::Button *  btnLightY;
	private: System::Windows::Forms::TextBox *  txtLightX;
	private: System::Windows::Forms::Button *  btnLightX;
	private: System::Windows::Forms::Label *  label6;
	private: System::Windows::Forms::TextBox *  txtMuKinetic;
	private: System::Windows::Forms::CheckBox *  chkRotation;
	private: System::Windows::Forms::Label *  label10;

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->chkRotation = new System::Windows::Forms::CheckBox();
			this->btnCrane = new System::Windows::Forms::Button();
			this->btnTilt = new System::Windows::Forms::Button();
			this->btnTumble = new System::Windows::Forms::Button();
			this->btnPan = new System::Windows::Forms::Button();
			this->btnZoom = new System::Windows::Forms::Button();
			this->btnDolly = new System::Windows::Forms::Button();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->chkShadow = new System::Windows::Forms::CheckBox();
			this->txtGridWidth = new System::Windows::Forms::TextBox();
			this->btnWidth = new System::Windows::Forms::Button();
			this->rdbCheck = new System::Windows::Forms::RadioButton();
			this->rdbGrid = new System::Windows::Forms::RadioButton();
			this->rdbNon = new System::Windows::Forms::RadioButton();
			this->chkWireframe = new System::Windows::Forms::CheckBox();
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->txtMuKinetic = new System::Windows::Forms::TextBox();
			this->label6 = new System::Windows::Forms::Label();
			this->btnStop = new System::Windows::Forms::Button();
			this->btnStart = new System::Windows::Forms::Button();
			this->txtDeltaTime = new System::Windows::Forms::TextBox();
			this->label9 = new System::Windows::Forms::Label();
			this->txtDrawTime = new System::Windows::Forms::TextBox();
			this->label8 = new System::Windows::Forms::Label();
			this->txtNumFrame = new System::Windows::Forms::TextBox();
			this->label7 = new System::Windows::Forms::Label();
			this->txtMuStatic = new System::Windows::Forms::TextBox();
			this->label5 = new System::Windows::Forms::Label();
			this->label4 = new System::Windows::Forms::Label();
			this->label3 = new System::Windows::Forms::Label();
			this->txtOmega = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->txtRadius = new System::Windows::Forms::TextBox();
			this->label1 = new System::Windows::Forms::Label();
			this->btnReady = new System::Windows::Forms::Button();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->txtLightZ = new System::Windows::Forms::TextBox();
			this->btnLightZ = new System::Windows::Forms::Button();
			this->txtLightY = new System::Windows::Forms::TextBox();
			this->btnLightY = new System::Windows::Forms::Button();
			this->txtLightX = new System::Windows::Forms::TextBox();
			this->btnLightX = new System::Windows::Forms::Button();
			this->label10 = new System::Windows::Forms::Label();
			this->groupBox2->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->chkRotation);
			this->groupBox2->Controls->Add(this->btnCrane);
			this->groupBox2->Controls->Add(this->btnTilt);
			this->groupBox2->Controls->Add(this->btnTumble);
			this->groupBox2->Controls->Add(this->btnPan);
			this->groupBox2->Controls->Add(this->btnZoom);
			this->groupBox2->Controls->Add(this->btnDolly);
			this->groupBox2->Location = System::Drawing::Point(232, 136);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(128, 112);
			this->groupBox2->TabIndex = 28;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Camera";
			// 
			// chkRotation
			// 
			this->chkRotation->Location = System::Drawing::Point(8, 82);
			this->chkRotation->Name = S"chkRotation";
			this->chkRotation->Size = System::Drawing::Size(64, 24);
			this->chkRotation->TabIndex = 6;
			this->chkRotation->Text = S"��]";
			// 
			// btnCrane
			// 
			this->btnCrane->Location = System::Drawing::Point(56, 62);
			this->btnCrane->Name = S"btnCrane";
			this->btnCrane->Size = System::Drawing::Size(64, 21);
			this->btnCrane->TabIndex = 5;
			this->btnCrane->Text = S"Crane";
			this->btnCrane->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnCrane_MouseDown);
			// 
			// btnTilt
			// 
			this->btnTilt->Location = System::Drawing::Point(8, 62);
			this->btnTilt->Name = S"btnTilt";
			this->btnTilt->Size = System::Drawing::Size(48, 21);
			this->btnTilt->TabIndex = 4;
			this->btnTilt->Text = S"Tilt";
			this->btnTilt->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTilt_MouseDown);
			// 
			// btnTumble
			// 
			this->btnTumble->Location = System::Drawing::Point(56, 41);
			this->btnTumble->Name = S"btnTumble";
			this->btnTumble->Size = System::Drawing::Size(64, 21);
			this->btnTumble->TabIndex = 3;
			this->btnTumble->Text = S"Tumble";
			this->btnTumble->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTumble_MouseDown);
			// 
			// btnPan
			// 
			this->btnPan->Location = System::Drawing::Point(8, 41);
			this->btnPan->Name = S"btnPan";
			this->btnPan->Size = System::Drawing::Size(48, 21);
			this->btnPan->TabIndex = 2;
			this->btnPan->Text = S"Pan";
			this->btnPan->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnPan_MouseDown);
			// 
			// btnZoom
			// 
			this->btnZoom->Location = System::Drawing::Point(56, 18);
			this->btnZoom->Name = S"btnZoom";
			this->btnZoom->Size = System::Drawing::Size(64, 22);
			this->btnZoom->TabIndex = 1;
			this->btnZoom->Text = S"Zoom";
			this->btnZoom->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnZoom_MouseDown);
			// 
			// btnDolly
			// 
			this->btnDolly->Location = System::Drawing::Point(8, 18);
			this->btnDolly->Name = S"btnDolly";
			this->btnDolly->Size = System::Drawing::Size(48, 22);
			this->btnDolly->TabIndex = 0;
			this->btnDolly->Text = S"Dolly";
			this->btnDolly->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDolly_MouseDown);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->chkShadow);
			this->groupBox4->Controls->Add(this->txtGridWidth);
			this->groupBox4->Controls->Add(this->btnWidth);
			this->groupBox4->Controls->Add(this->rdbCheck);
			this->groupBox4->Controls->Add(this->rdbGrid);
			this->groupBox4->Controls->Add(this->rdbNon);
			this->groupBox4->Location = System::Drawing::Point(8, 136);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(216, 72);
			this->groupBox4->TabIndex = 27;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Floor";
			// 
			// chkShadow
			// 
			this->chkShadow->Location = System::Drawing::Point(112, 40);
			this->chkShadow->Name = S"chkShadow";
			this->chkShadow->Size = System::Drawing::Size(88, 16);
			this->chkShadow->TabIndex = 5;
			this->chkShadow->Text = S"Shadow";
			this->chkShadow->CheckedChanged += new System::EventHandler(this, &Form1::chkShadow_CheckedChanged);
			// 
			// txtGridWidth
			// 
			this->txtGridWidth->Location = System::Drawing::Point(64, 40);
			this->txtGridWidth->Name = S"txtGridWidth";
			this->txtGridWidth->Size = System::Drawing::Size(40, 22);
			this->txtGridWidth->TabIndex = 4;
			this->txtGridWidth->Text = S"";
			// 
			// btnWidth
			// 
			this->btnWidth->Location = System::Drawing::Point(8, 40);
			this->btnWidth->Name = S"btnWidth";
			this->btnWidth->Size = System::Drawing::Size(56, 24);
			this->btnWidth->TabIndex = 3;
			this->btnWidth->Text = S"Width";
			this->btnWidth->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnWidth_MouseDown);
			// 
			// rdbCheck
			// 
			this->rdbCheck->Location = System::Drawing::Point(136, 16);
			this->rdbCheck->Name = S"rdbCheck";
			this->rdbCheck->Size = System::Drawing::Size(72, 24);
			this->rdbCheck->TabIndex = 2;
			this->rdbCheck->Text = S"Check";
			this->rdbCheck->CheckedChanged += new System::EventHandler(this, &Form1::rdbCheck_CheckedChanged);
			// 
			// rdbGrid
			// 
			this->rdbGrid->Checked = true;
			this->rdbGrid->Location = System::Drawing::Point(76, 16);
			this->rdbGrid->Name = S"rdbGrid";
			this->rdbGrid->Size = System::Drawing::Size(72, 24);
			this->rdbGrid->TabIndex = 1;
			this->rdbGrid->TabStop = true;
			this->rdbGrid->Text = S"Grid";
			this->rdbGrid->CheckedChanged += new System::EventHandler(this, &Form1::rdbGrid_CheckedChanged);
			// 
			// rdbNon
			// 
			this->rdbNon->Location = System::Drawing::Point(16, 16);
			this->rdbNon->Name = S"rdbNon";
			this->rdbNon->Size = System::Drawing::Size(56, 24);
			this->rdbNon->TabIndex = 0;
			this->rdbNon->Text = S"Non";
			this->rdbNon->CheckedChanged += new System::EventHandler(this, &Form1::rdbNon_CheckedChanged);
			// 
			// chkWireframe
			// 
			this->chkWireframe->Location = System::Drawing::Point(232, 248);
			this->chkWireframe->Name = S"chkWireframe";
			this->chkWireframe->Size = System::Drawing::Size(96, 24);
			this->chkWireframe->TabIndex = 30;
			this->chkWireframe->Text = S"Wireframe";
			this->chkWireframe->CheckedChanged += new System::EventHandler(this, &Form1::chkWireframe_CheckedChanged);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label10);
			this->groupBox1->Controls->Add(this->txtMuKinetic);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->btnStop);
			this->groupBox1->Controls->Add(this->btnStart);
			this->groupBox1->Controls->Add(this->txtDeltaTime);
			this->groupBox1->Controls->Add(this->label9);
			this->groupBox1->Controls->Add(this->txtDrawTime);
			this->groupBox1->Controls->Add(this->label8);
			this->groupBox1->Controls->Add(this->txtNumFrame);
			this->groupBox1->Controls->Add(this->label7);
			this->groupBox1->Controls->Add(this->txtMuStatic);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->txtOmega);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->txtRadius);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->btnReady);
			this->groupBox1->Location = System::Drawing::Point(8, 8);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(352, 128);
			this->groupBox1->TabIndex = 26;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Animation";
			// 
			// txtMuKinetic
			// 
			this->txtMuKinetic->Location = System::Drawing::Point(304, 48);
			this->txtMuKinetic->Name = S"txtMuKinetic";
			this->txtMuKinetic->Size = System::Drawing::Size(40, 22);
			this->txtMuKinetic->TabIndex = 21;
			this->txtMuKinetic->Text = S"";
			// 
			// label6
			// 
			this->label6->Location = System::Drawing::Point(224, 56);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(88, 16);
			this->label6->TabIndex = 20;
			this->label6->Text = S"�����C�W��";
			// 
			// btnStop
			// 
			this->btnStop->Location = System::Drawing::Point(288, 80);
			this->btnStop->Name = S"btnStop";
			this->btnStop->Size = System::Drawing::Size(56, 32);
			this->btnStop->TabIndex = 19;
			this->btnStop->Text = S"Stop";
			this->btnStop->Click += new System::EventHandler(this, &Form1::btnStop_Click);
			// 
			// btnStart
			// 
			this->btnStart->Location = System::Drawing::Point(224, 80);
			this->btnStart->Name = S"btnStart";
			this->btnStart->Size = System::Drawing::Size(56, 32);
			this->btnStart->TabIndex = 18;
			this->btnStart->Text = S"Start";
			this->btnStart->Click += new System::EventHandler(this, &Form1::btnStart_Click);
			// 
			// txtDeltaTime
			// 
			this->txtDeltaTime->Location = System::Drawing::Point(128, 96);
			this->txtDeltaTime->Name = S"txtDeltaTime";
			this->txtDeltaTime->Size = System::Drawing::Size(64, 22);
			this->txtDeltaTime->TabIndex = 15;
			this->txtDeltaTime->Text = S"";
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(96, 96);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(40, 16);
			this->label9->TabIndex = 14;
			this->label9->Text = S"����";
			// 
			// txtDrawTime
			// 
			this->txtDrawTime->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtDrawTime->Location = System::Drawing::Point(128, 72);
			this->txtDrawTime->Name = S"txtDrawTime";
			this->txtDrawTime->Size = System::Drawing::Size(64, 22);
			this->txtDrawTime->TabIndex = 13;
			this->txtDrawTime->Text = S"";
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(96, 72);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(56, 16);
			this->label8->TabIndex = 12;
			this->label8->Text = S"�`��";
			// 
			// txtNumFrame
			// 
			this->txtNumFrame->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtNumFrame->Location = System::Drawing::Point(16, 88);
			this->txtNumFrame->Name = S"txtNumFrame";
			this->txtNumFrame->Size = System::Drawing::Size(56, 22);
			this->txtNumFrame->TabIndex = 11;
			this->txtNumFrame->Text = S"";
			// 
			// label7
			// 
			this->label7->Location = System::Drawing::Point(16, 72);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(48, 16);
			this->label7->TabIndex = 10;
			this->label7->Text = S"�R�}��";
			// 
			// txtMuStatic
			// 
			this->txtMuStatic->Location = System::Drawing::Point(304, 24);
			this->txtMuStatic->Name = S"txtMuStatic";
			this->txtMuStatic->Size = System::Drawing::Size(40, 22);
			this->txtMuStatic->TabIndex = 8;
			this->txtMuStatic->Text = S"";
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(224, 32);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(88, 16);
			this->label5->TabIndex = 7;
			this->label5->Text = S"�Ö��C�W��";
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(176, 48);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(48, 16);
			this->label4->TabIndex = 6;
			this->label4->Text = S"deg/s";
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(176, 24);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(32, 16);
			this->label3->TabIndex = 5;
			this->label3->Text = S"m";
			// 
			// txtOmega
			// 
			this->txtOmega->Location = System::Drawing::Point(136, 40);
			this->txtOmega->Name = S"txtOmega";
			this->txtOmega->Size = System::Drawing::Size(40, 22);
			this->txtOmega->TabIndex = 4;
			this->txtOmega->Text = S"";
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(88, 40);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(56, 16);
			this->label2->TabIndex = 3;
			this->label2->Text = S"�����x";
			// 
			// txtRadius
			// 
			this->txtRadius->Location = System::Drawing::Point(136, 16);
			this->txtRadius->Name = S"txtRadius";
			this->txtRadius->Size = System::Drawing::Size(40, 22);
			this->txtRadius->TabIndex = 2;
			this->txtRadius->Text = S"";
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(88, 16);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(56, 24);
			this->label1->TabIndex = 1;
			this->label1->Text = S"�����x";
			// 
			// btnReady
			// 
			this->btnReady->Location = System::Drawing::Point(8, 24);
			this->btnReady->Name = S"btnReady";
			this->btnReady->Size = System::Drawing::Size(72, 32);
			this->btnReady->TabIndex = 0;
			this->btnReady->Text = S"Ready";
			this->btnReady->Click += new System::EventHandler(this, &Form1::btnReady_Click);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->txtLightZ);
			this->groupBox3->Controls->Add(this->btnLightZ);
			this->groupBox3->Controls->Add(this->txtLightY);
			this->groupBox3->Controls->Add(this->btnLightY);
			this->groupBox3->Controls->Add(this->txtLightX);
			this->groupBox3->Controls->Add(this->btnLightX);
			this->groupBox3->Location = System::Drawing::Point(8, 208);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(216, 48);
			this->groupBox3->TabIndex = 29;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Light";
			// 
			// txtLightZ
			// 
			this->txtLightZ->Location = System::Drawing::Point(168, 16);
			this->txtLightZ->Name = S"txtLightZ";
			this->txtLightZ->Size = System::Drawing::Size(34, 22);
			this->txtLightZ->TabIndex = 5;
			this->txtLightZ->Text = S"";
			// 
			// btnLightZ
			// 
			this->btnLightZ->Location = System::Drawing::Point(144, 16);
			this->btnLightZ->Name = S"btnLightZ";
			this->btnLightZ->Size = System::Drawing::Size(24, 22);
			this->btnLightZ->TabIndex = 4;
			this->btnLightZ->Text = S"Z";
			this->btnLightZ->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightZ_MouseDown);
			// 
			// txtLightY
			// 
			this->txtLightY->Location = System::Drawing::Point(100, 16);
			this->txtLightY->Name = S"txtLightY";
			this->txtLightY->Size = System::Drawing::Size(33, 22);
			this->txtLightY->TabIndex = 3;
			this->txtLightY->Text = S"";
			// 
			// btnLightY
			// 
			this->btnLightY->Location = System::Drawing::Point(76, 16);
			this->btnLightY->Name = S"btnLightY";
			this->btnLightY->Size = System::Drawing::Size(24, 24);
			this->btnLightY->TabIndex = 2;
			this->btnLightY->Text = S"Y";
			this->btnLightY->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightY_MouseDown);
			// 
			// txtLightX
			// 
			this->txtLightX->Location = System::Drawing::Point(32, 16);
			this->txtLightX->Name = S"txtLightX";
			this->txtLightX->Size = System::Drawing::Size(32, 22);
			this->txtLightX->TabIndex = 1;
			this->txtLightX->Text = S"";
			// 
			// btnLightX
			// 
			this->btnLightX->Location = System::Drawing::Point(8, 16);
			this->btnLightX->Name = S"btnLightX";
			this->btnLightX->Size = System::Drawing::Size(24, 24);
			this->btnLightX->TabIndex = 0;
			this->btnLightX->Text = S"X";
			this->btnLightX->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightX_MouseDown);
			// 
			// label10
			// 
			this->label10->Location = System::Drawing::Point(192, 88);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(24, 16);
			this->label10->TabIndex = 22;
			this->label10->Text = S"s";
			// 
			// Form1
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(7, 15);
			this->ClientSize = System::Drawing::Size(368, 267);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->chkWireframe);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->groupBox3);
			this->Name = S"Form1";
			this->Text = S"Turntable(��]���̍���)";
			this->Load += new System::EventHandler(this, &Form1::Form1_Load);
			this->Closed += new System::EventHandler(this, &Form1::Form1_Closed);
			this->groupBox2->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->ResumeLayout(false);

		}	
//----------------------------------------------------------------
	SpaceForm* spaceForm;//�R�����`��t�H�[���̃C���X�^���X
	bool flagStart;//�A�j���[�V�������s�t���O
    double radius;//��]���a
    double omega;//�p���x
	double muStatic;//�Î~���C�W��
	double muKinetic;//�����C�W��
    float t;//���̎��Ԍo�߁i���ԍ���dt�̘a�j
	int numFrame;//���R�}��

	private: System::Void Form1_Load(System::Object *  sender, System::EventArgs *  e)
	{
		//Form�̈ʒu
		Left = 100;
		Top = 100;
		//SpaceForm��\��
		spaceForm = new SpaceForm();
		spaceForm -> Show();
		//Floor�̏����l
		gridWidth = 1.0;
        txtGridWidth->Text = gridWidth.ToString();

		txtDeltaTime->Text = S"0.001";//�������ԑ���(s)
		//���̂̉�]���a
		txtRadius->Text = S"0.5";
		//�Ö��C�W��
		txtMuStatic->Text = S"1.0";
		//�����C�W��
		txtMuKinetic->Text = S"0.01";
		//�p���x
		txtOmega->Text = S"50.0";
		//����
        txtLightX->Text = light.x.ToString();
        txtLightY->Text = light.y.ToString();
        txtLightZ->Text = light.z.ToString();
	}

private: System::Void Form1_Closed(System::Object *  sender, System::EventArgs *  e)
	{
 		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);
	}

private: System::Void btnReady_Click(System::Object *  sender, System::EventArgs *  e)
	{
		//OpenGL����
		IntPtr ptr = spaceForm->picSpace->Handle;//�f�o�C�X�R���e�L�X�g�̃n���h��
		hWnd = (HWND)ptr.ToInt32();
		hDC = GetDC(hWnd);
		setup.initOpenGL();
		
		Image* im = Image::FromFile("../../bmp128/checkMono1.bmp");
		Bitmap* bitmap = new Bitmap(im);

		//�`��I�u�W�F�N�g
		numTarget = 2;
		//����
		target[0].kind = CUBE;
		target[0].texType = T_PLANAR2;
		target[0].texMode = T_MODULATE;
		target[0].makeTexture(bitmap);
		target[0].makeTexture(bitmap);
		target[0].vSize = CVector(0.3, 0.3, 0.3);
		radius = Convert::ToDouble(txtRadius->Text);
		target[0].vPos0.x = radius;
		target[0].vPos0.y = 0.0;
		target[0].vPos0.z = target[0].vSize.z / 2.0;
		target[0].vPos = target[0].vPos0;
		target[0].diffuse[0] = 1.0f; //red
		target[0].diffuse[1] = 0.9f;
		target[0].diffuse[2] = 0.9f;

		target[0].vEuler.z = 0.0;
		txtOmega->Text = "50.0";

		//�~��
		target[1].kind = CYLINDER;
		target[1].texType = T_SOLID;
		target[1].texMode = T_MODULATE;
		target[1].vSize = CVector(2.0*radius+0.5 , 2.0*radius+0.5, 0.01);
		target[1].num1 = 18;
		target[1].diffuse[0] = 1.0f; //red
		target[1].diffuse[1] = 0.9f;
		target[1].diffuse[2] = 0.9f;
		target[1].vPos = CVector(0.0, 0.0, 0.005);
		target[1].vEuler.z = 0.0;
		//solid texture�̏ꍇ�͑O������texImageS���v�Z���Ă���
   		if(target[1].texType == T_SOLID)
			target[1].calcSolidTexCylinder(target[1].vSize);

		t = 0.0;
		numFrame = 0;
		txtNumFrame->Text = numFrame.ToString();//���R�}��
		setCamera();
		display();
	}

	private: System::Void setCamera()
	{
		//�����_��target[0]�ɌŒ�
		if(chkRotation->Checked == true){
			camera.vCenter.x = target[0].vPos0.x;
			camera.vCenter.y = target[0].vPos0.y;
			camera.vCenter.z = target[0].vPos0.z;
			camera.vPos.x = 0.0;
			camera.vPos.y = 0.0;
			camera.vPos.z = 10.0;
		}
	}

	private: System::Void display()
	{
	    int i;
		setup.set3DAmbient(spaceForm->picSpace);
		setup.setLight();
		setCamera();
		flagShadow = chkShadow->Checked;

		glClear(GL_COLOR_BUFFER_BIT); //�װ�ޯ̧��ر
		glClear(GL_DEPTH_BUFFER_BIT); //���߽�ޯ̧��ر
	    //���������̂�����Ƃ��͎���2�s���K�v
	    glCullFace(GL_BACK);   //���ʂ��폜
	    glEnable(GL_CULL_FACE);//���ʍ폜��L���ɂ���

		setup.drawFloor(rdbNon, rdbCheck);//setup.h

	    if(chkWireframe->Checked == true){//ܲ԰�ڰ�����
		    glPolygonMode(GL_FRONT,GL_LINE);
		    glPolygonMode(GL_BACK,GL_POINT);
	    }
				
		//�������̂�����Ƃ��͈ȉ��̂悤�ɕs�������̂��ɂ��ׂĕ`��
		for(i = 0; i < numTarget; i++) {
			if(target[i].diffuse[3] == 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_FALSE); //���߽�ޯ̧���������݋֎~
		glEnable(GL_BLEND);//��̧�����ިݸނ�L���ɂ���
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);//�F�����W�������߂�

		//���������̂�`��
		for(i=0;i<numTarget;i++) {
			if(target[i].diffuse[3] != 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_TRUE); //���߽�ޯ̧�̏������݂�����
		glDisable(GL_BLEND);

        setup.drawShadow();//setup.h

        glPopMatrix();
	    SwapBuffers(hDC);
    }

	private: System::Void execute()
	{
		float drawTime, lapse;
		int h1, m1, s1, ms1;
		int h2, m2, s2, ms2;
		float dt;//��������
		double g = 9.8;
		double pp = M_PI / 180.0;
    
		//����
		dt = Convert::ToSingle(txtDeltaTime->Text);//�b�P�ʂŎw��

		txtDrawTime->Text = S" ";
		flagStart = true;

		Cursor = Cursors::AppStarting;//�J�[�\����ύX
		DateTime tStart = DateTime::Now;//���݂̎���
		h1 = tStart.Hour;
		m1 = tStart.Minute;
		s1 = tStart.Second;
		ms1 = tStart.Millisecond;

		target[1].vSize = CVector(2.0*radius+0.5 , 2.0*radius+0.5, 0.01);

		target[0].mass = 1.0;
		omega = Convert::ToDouble(txtOmega->Text);//�p���xdeg/s
		muStatic = Convert::ToDouble(txtMuStatic->Text);
		muKinetic = Convert::ToDouble(txtMuKinetic->Text);

		int numFrame0 = 0;
//		float dir;//�ڐ�����
		double omegaC = sqrt(muStatic * g / radius) / pp;//�ՊE�p���x
		//omega > omegaC�ō��͔̂�яo��
		if(fabs(omega) > omegaC) goto slide;
		while(true){
			omega += 0.1;//�p���xdeg/s
			txtOmega->Text = String::Format("{0:0.0}", __box(omega));
			target[1].vEuler.z += omega * dt;
			target[0].vEuler.z += omega * dt; //�~�Տ�̍��̂��p���x������
			target[0].vPos.x = radius * cos(target[1].vEuler.z * pp);
			target[0].vPos.y = radius * sin(target[1].vEuler.z * pp);
			target[0].vPos0 = target[0].vPos;
			if(fabs(omega) > omegaC) {
				//�ڐ�����
				target[0].dir = target[1].vEuler.z + 90.0;
				//���x�̑傫��
				target[0].speed = radius * omega * pp;
				//�p���x
				target[0].vOmega.z = omega * pp; //vOmega��rad/s�P��
				goto slide;
			}
			display();
			Application::DoEvents();//���̃C�x���g��҂�
			if( flagStart == false ) break;
			numFrame++;
			numFrame0++;
		}
		goto afterProcess;

slide:;
		//��]��
		target[0].vAxis = CVector(0.0, 0.0, 1.0);
		//�p���x
		target[0].vOmega  = omega * target[0].vAxis * pp;//omega��deg/s,��Omega��rad/s
		while(true){
			//���̂�����o�����Ƃ��̊p���x�ŉ~�Ղ���]
			target[1].vEuler.z += omega * dt;

			//camera����]���W�n�ɂ������Ƃ��̒����_�͌��̍��̈ʒuvPos0
			target[0].vPos0.x = radius * cos(target[1].vEuler.z * pp);
			target[0].vPos0.y = radius * sin(target[1].vEuler.z * pp);

			//���͉̂�]���Ȃ��璼���^��
			target[0].sliding(muKinetic, dt);
			display();
			Application::DoEvents();//���̃C�x���g��҂�
			if( flagStart == false ) break;
			//�I������
			if( target[0].speed < 0.001 ) break;
			numFrame++;
			numFrame0++;
		}
afterProcess:;
		Cursor = Cursors::Default;
		DateTime tStop = DateTime::Now;
		h2 = tStop.Hour;
		m2 = tStop.Minute;
		s2 = tStop.Second;
		ms2 = tStop.Millisecond;
		//�o�ߎ���(sec)
		lapse = (float)(h2-h1) * 3600.0f + (float)(m2-m1) * 60.0f + (float)(s2-s1) + (float)(ms2-ms1) / 1000.0f;
		//1�R�}������̕`�掞��(sec)
		drawTime = lapse / (float)numFrame0;
		txtDrawTime->Text = drawTime.ToString();//�e�L�X�g�{�b�N�X�ɕ\��
		txtNumFrame->Text = numFrame.ToString();//���R�}��
	}

	private: System::Void btnStart_Click(System::Object *  sender, System::EventArgs *  e)
	{
		execute();
	}

	private: System::Void btnStop_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = false;
	}

    private: System::Void rdbCheck_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbGrid_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbNon_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void btnWidth_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
         if(e->Button == MouseButtons::Left)
                gridWidth += 0.1f;
         else
                gridWidth -= 0.1f;
         txtGridWidth->Text = gridWidth.ToString();
         display();
    }

    private: System::Void chkShadow_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        flagShadow = chkShadow->Checked;
        display();
    }

    private: System::Void btnDolly_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.dist -= 0.5f;
        else
            camera.dist += 0.5f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnZoom_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.fov -= 0.1f;
        else
            camera.fov += 0.1f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnPan_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta += 1.0f; //deg
   	    else
            camera.theta -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTumble_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta -= 5.0f;
        else
            camera.theta += 5.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTilt_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 1.0f; //deg
   	    else
            camera.phi -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.vCenter.z = camera.vPos.z - camera.dist * (float)sin(pp * camera.phi);
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnCrane_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 2.0f;
        else
            camera.phi -= 2.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnLightX_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.x += 1.0f;
        else
            light.x -= 1.0f;
        txtLightX->Text = String::Format("{0:0.0}", __box(light.x));

        display();
    }

    private: System::Void btnLightY_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.y += 1.0f;
        else
            light.y -= 1.0f;
        txtLightY->Text = String::Format("{0:0.0}", __box(light.y));

        display();
    }

    private: System::Void btnLightZ_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.z += 1.0f;
        else
            light.z -= 1.0f;
        txtLightZ->Text = String::Format("{0:0.0}", __box(light.z));

        display();
    }

	private: System::Void chkWireframe_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
        setup.initOpenGL(); //Mode�؂�ւ����ɂ͕K�v
        display();
	}

};
}


