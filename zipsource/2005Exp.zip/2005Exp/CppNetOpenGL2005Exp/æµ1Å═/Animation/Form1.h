#pragma once

#include "setup.h"
CSetup setup;
#include "SpaceForm.h"

namespace Animation
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Form1 �̊T�v
	///
	/// �x�� : ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ 
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ����������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	private: System::Windows::Forms::GroupBox *  groupBox2;
	private: System::Windows::Forms::Button *  btnCrane;
	private: System::Windows::Forms::Button *  btnTilt;
	private: System::Windows::Forms::Button *  btnTumble;
	private: System::Windows::Forms::Button *  btnPan;
	private: System::Windows::Forms::Button *  btnZoom;
	private: System::Windows::Forms::Button *  btnDolly;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::TextBox *  txtLightZ;
	private: System::Windows::Forms::Button *  btnLightZ;
	private: System::Windows::Forms::TextBox *  txtLightY;
	private: System::Windows::Forms::Button *  btnLightY;
	private: System::Windows::Forms::TextBox *  txtLightX;
	private: System::Windows::Forms::Button *  btnLightX;
	private: System::Windows::Forms::CheckBox *  chkWireframe;
	public: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::CheckBox *  chkShadow;
	private: System::Windows::Forms::TextBox *  txtGridWidth;
	private: System::Windows::Forms::Button *  btnWidth;
	public: System::Windows::Forms::RadioButton *  rdbCheck;
	public: System::Windows::Forms::RadioButton *  rdbGrid;
	public: System::Windows::Forms::RadioButton *  rdbNon;
	private: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::Button *  btnReady;
	private: System::Windows::Forms::Label *  label7;
	private: System::Windows::Forms::Label *  label6;
	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::Button *  btnStop;
	private: System::Windows::Forms::Button *  btnStart;
	private: System::Windows::Forms::TextBox *  txtDeltaTime;
	private: System::Windows::Forms::TextBox *  txtDrawTime;
	private: System::Windows::Forms::TextBox *  txtNumFrame;
	private: System::Windows::Forms::TextBox *  txtPeriod2;
	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::TextBox *  txtPeriod1;
	private: System::Windows::Forms::Label *  label3;
	private: System::Windows::Forms::Label *  label2;
	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::TextBox *  txtSpeed;
	private: System::Windows::Forms::RadioButton *  rdbRotation;
	private: System::Windows::Forms::RadioButton *  rdbLinear;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::Label *  label9;

	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->btnCrane = new System::Windows::Forms::Button();
			this->btnTilt = new System::Windows::Forms::Button();
			this->btnTumble = new System::Windows::Forms::Button();
			this->btnPan = new System::Windows::Forms::Button();
			this->btnZoom = new System::Windows::Forms::Button();
			this->btnDolly = new System::Windows::Forms::Button();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->txtLightZ = new System::Windows::Forms::TextBox();
			this->btnLightZ = new System::Windows::Forms::Button();
			this->txtLightY = new System::Windows::Forms::TextBox();
			this->btnLightY = new System::Windows::Forms::Button();
			this->txtLightX = new System::Windows::Forms::TextBox();
			this->btnLightX = new System::Windows::Forms::Button();
			this->chkWireframe = new System::Windows::Forms::CheckBox();
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->chkShadow = new System::Windows::Forms::CheckBox();
			this->txtGridWidth = new System::Windows::Forms::TextBox();
			this->btnWidth = new System::Windows::Forms::Button();
			this->rdbCheck = new System::Windows::Forms::RadioButton();
			this->rdbGrid = new System::Windows::Forms::RadioButton();
			this->rdbNon = new System::Windows::Forms::RadioButton();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->label8 = new System::Windows::Forms::Label();
			this->txtSpeed = new System::Windows::Forms::TextBox();
			this->txtNumFrame = new System::Windows::Forms::TextBox();
			this->txtDeltaTime = new System::Windows::Forms::TextBox();
			this->txtDrawTime = new System::Windows::Forms::TextBox();
			this->btnReady = new System::Windows::Forms::Button();
			this->label7 = new System::Windows::Forms::Label();
			this->label6 = new System::Windows::Forms::Label();
			this->label5 = new System::Windows::Forms::Label();
			this->btnStop = new System::Windows::Forms::Button();
			this->btnStart = new System::Windows::Forms::Button();
			this->txtPeriod2 = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->txtPeriod1 = new System::Windows::Forms::TextBox();
			this->label3 = new System::Windows::Forms::Label();
			this->label2 = new System::Windows::Forms::Label();
			this->label1 = new System::Windows::Forms::Label();
			this->rdbRotation = new System::Windows::Forms::RadioButton();
			this->rdbLinear = new System::Windows::Forms::RadioButton();
			this->label9 = new System::Windows::Forms::Label();
			this->groupBox2->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->groupBox1->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->btnCrane);
			this->groupBox2->Controls->Add(this->btnTilt);
			this->groupBox2->Controls->Add(this->btnTumble);
			this->groupBox2->Controls->Add(this->btnPan);
			this->groupBox2->Controls->Add(this->btnZoom);
			this->groupBox2->Controls->Add(this->btnDolly);
			this->groupBox2->Location = System::Drawing::Point(232, 0);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(128, 96);
			this->groupBox2->TabIndex = 19;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Camera";
			// 
			// btnCrane
			// 
			this->btnCrane->Location = System::Drawing::Point(56, 62);
			this->btnCrane->Name = S"btnCrane";
			this->btnCrane->Size = System::Drawing::Size(64, 21);
			this->btnCrane->TabIndex = 5;
			this->btnCrane->Text = S"Crane";
			this->btnCrane->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnCrane_MouseDown);
			// 
			// btnTilt
			// 
			this->btnTilt->Location = System::Drawing::Point(8, 62);
			this->btnTilt->Name = S"btnTilt";
			this->btnTilt->Size = System::Drawing::Size(48, 21);
			this->btnTilt->TabIndex = 4;
			this->btnTilt->Text = S"Tilt";
			this->btnTilt->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTilt_MouseDown);
			// 
			// btnTumble
			// 
			this->btnTumble->Location = System::Drawing::Point(56, 41);
			this->btnTumble->Name = S"btnTumble";
			this->btnTumble->Size = System::Drawing::Size(64, 21);
			this->btnTumble->TabIndex = 3;
			this->btnTumble->Text = S"Tumble";
			this->btnTumble->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTumble_MouseDown);
			// 
			// btnPan
			// 
			this->btnPan->Location = System::Drawing::Point(8, 41);
			this->btnPan->Name = S"btnPan";
			this->btnPan->Size = System::Drawing::Size(48, 21);
			this->btnPan->TabIndex = 2;
			this->btnPan->Text = S"Pan";
			this->btnPan->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnPan_MouseDown);
			// 
			// btnZoom
			// 
			this->btnZoom->Location = System::Drawing::Point(56, 18);
			this->btnZoom->Name = S"btnZoom";
			this->btnZoom->Size = System::Drawing::Size(64, 22);
			this->btnZoom->TabIndex = 1;
			this->btnZoom->Text = S"Zoom";
			this->btnZoom->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnZoom_MouseDown);
			// 
			// btnDolly
			// 
			this->btnDolly->Location = System::Drawing::Point(8, 18);
			this->btnDolly->Name = S"btnDolly";
			this->btnDolly->Size = System::Drawing::Size(48, 22);
			this->btnDolly->TabIndex = 0;
			this->btnDolly->Text = S"Dolly";
			this->btnDolly->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDolly_MouseDown);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->txtLightZ);
			this->groupBox3->Controls->Add(this->btnLightZ);
			this->groupBox3->Controls->Add(this->txtLightY);
			this->groupBox3->Controls->Add(this->btnLightY);
			this->groupBox3->Controls->Add(this->txtLightX);
			this->groupBox3->Controls->Add(this->btnLightX);
			this->groupBox3->Location = System::Drawing::Point(8, 72);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(216, 48);
			this->groupBox3->TabIndex = 20;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Light";
			// 
			// txtLightZ
			// 
			this->txtLightZ->Location = System::Drawing::Point(168, 16);
			this->txtLightZ->Name = S"txtLightZ";
			this->txtLightZ->Size = System::Drawing::Size(34, 22);
			this->txtLightZ->TabIndex = 5;
			this->txtLightZ->Text = S"";
			// 
			// btnLightZ
			// 
			this->btnLightZ->Location = System::Drawing::Point(144, 16);
			this->btnLightZ->Name = S"btnLightZ";
			this->btnLightZ->Size = System::Drawing::Size(24, 22);
			this->btnLightZ->TabIndex = 4;
			this->btnLightZ->Text = S"Z";
			this->btnLightZ->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightZ_MouseDown);
			// 
			// txtLightY
			// 
			this->txtLightY->Location = System::Drawing::Point(100, 16);
			this->txtLightY->Name = S"txtLightY";
			this->txtLightY->Size = System::Drawing::Size(33, 22);
			this->txtLightY->TabIndex = 3;
			this->txtLightY->Text = S"";
			// 
			// btnLightY
			// 
			this->btnLightY->Location = System::Drawing::Point(76, 16);
			this->btnLightY->Name = S"btnLightY";
			this->btnLightY->Size = System::Drawing::Size(24, 24);
			this->btnLightY->TabIndex = 2;
			this->btnLightY->Text = S"Y";
			this->btnLightY->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightY_MouseDown);
			// 
			// txtLightX
			// 
			this->txtLightX->Location = System::Drawing::Point(32, 16);
			this->txtLightX->Name = S"txtLightX";
			this->txtLightX->Size = System::Drawing::Size(32, 22);
			this->txtLightX->TabIndex = 1;
			this->txtLightX->Text = S"";
			// 
			// btnLightX
			// 
			this->btnLightX->Location = System::Drawing::Point(8, 16);
			this->btnLightX->Name = S"btnLightX";
			this->btnLightX->Size = System::Drawing::Size(24, 24);
			this->btnLightX->TabIndex = 0;
			this->btnLightX->Text = S"X";
			this->btnLightX->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightX_MouseDown);
			// 
			// chkWireframe
			// 
			this->chkWireframe->Location = System::Drawing::Point(232, 96);
			this->chkWireframe->Name = S"chkWireframe";
			this->chkWireframe->Size = System::Drawing::Size(96, 24);
			this->chkWireframe->TabIndex = 21;
			this->chkWireframe->Text = S"Wireframe";
			this->chkWireframe->CheckedChanged += new System::EventHandler(this, &Form1::chkWireframe_CheckedChanged);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->chkShadow);
			this->groupBox1->Controls->Add(this->txtGridWidth);
			this->groupBox1->Controls->Add(this->btnWidth);
			this->groupBox1->Controls->Add(this->rdbCheck);
			this->groupBox1->Controls->Add(this->rdbGrid);
			this->groupBox1->Controls->Add(this->rdbNon);
			this->groupBox1->Location = System::Drawing::Point(8, 0);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(216, 72);
			this->groupBox1->TabIndex = 18;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Floor";
			// 
			// chkShadow
			// 
			this->chkShadow->Location = System::Drawing::Point(112, 40);
			this->chkShadow->Name = S"chkShadow";
			this->chkShadow->Size = System::Drawing::Size(88, 16);
			this->chkShadow->TabIndex = 5;
			this->chkShadow->Text = S"Shadow";
			this->chkShadow->CheckedChanged += new System::EventHandler(this, &Form1::chkShadow_CheckedChanged);
			// 
			// txtGridWidth
			// 
			this->txtGridWidth->Location = System::Drawing::Point(64, 40);
			this->txtGridWidth->Name = S"txtGridWidth";
			this->txtGridWidth->Size = System::Drawing::Size(40, 22);
			this->txtGridWidth->TabIndex = 4;
			this->txtGridWidth->Text = S"";
			// 
			// btnWidth
			// 
			this->btnWidth->Location = System::Drawing::Point(8, 40);
			this->btnWidth->Name = S"btnWidth";
			this->btnWidth->Size = System::Drawing::Size(56, 24);
			this->btnWidth->TabIndex = 3;
			this->btnWidth->Text = S"Width";
			this->btnWidth->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnWidth_MouseDown);
			// 
			// rdbCheck
			// 
			this->rdbCheck->Location = System::Drawing::Point(136, 16);
			this->rdbCheck->Name = S"rdbCheck";
			this->rdbCheck->Size = System::Drawing::Size(72, 24);
			this->rdbCheck->TabIndex = 2;
			this->rdbCheck->Text = S"Check";
			this->rdbCheck->CheckedChanged += new System::EventHandler(this, &Form1::rdbGrid_CheckedChanged);
			// 
			// rdbGrid
			// 
			this->rdbGrid->Checked = true;
			this->rdbGrid->Location = System::Drawing::Point(76, 16);
			this->rdbGrid->Name = S"rdbGrid";
			this->rdbGrid->Size = System::Drawing::Size(72, 24);
			this->rdbGrid->TabIndex = 1;
			this->rdbGrid->TabStop = true;
			this->rdbGrid->Text = S"Grid";
			this->rdbGrid->CheckedChanged += new System::EventHandler(this, &Form1::rdbGrid_CheckedChanged);
			// 
			// rdbNon
			// 
			this->rdbNon->Location = System::Drawing::Point(16, 16);
			this->rdbNon->Name = S"rdbNon";
			this->rdbNon->Size = System::Drawing::Size(56, 24);
			this->rdbNon->TabIndex = 0;
			this->rdbNon->Text = S"Non";
			this->rdbNon->CheckedChanged += new System::EventHandler(this, &Form1::rdbNon_CheckedChanged);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->label9);
			this->groupBox4->Controls->Add(this->label8);
			this->groupBox4->Controls->Add(this->txtSpeed);
			this->groupBox4->Controls->Add(this->txtNumFrame);
			this->groupBox4->Controls->Add(this->txtDeltaTime);
			this->groupBox4->Controls->Add(this->txtDrawTime);
			this->groupBox4->Controls->Add(this->btnReady);
			this->groupBox4->Controls->Add(this->label7);
			this->groupBox4->Controls->Add(this->label6);
			this->groupBox4->Controls->Add(this->label5);
			this->groupBox4->Controls->Add(this->btnStop);
			this->groupBox4->Controls->Add(this->btnStart);
			this->groupBox4->Controls->Add(this->txtPeriod2);
			this->groupBox4->Controls->Add(this->label4);
			this->groupBox4->Controls->Add(this->txtPeriod1);
			this->groupBox4->Controls->Add(this->label3);
			this->groupBox4->Controls->Add(this->label2);
			this->groupBox4->Controls->Add(this->label1);
			this->groupBox4->Controls->Add(this->rdbRotation);
			this->groupBox4->Controls->Add(this->rdbLinear);
			this->groupBox4->Location = System::Drawing::Point(8, 120);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(352, 144);
			this->groupBox4->TabIndex = 22;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Animation";
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(224, 104);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(16, 16);
			this->label8->TabIndex = 18;
			this->label8->Text = S"s";
			// 
			// txtSpeed
			// 
			this->txtSpeed->Location = System::Drawing::Point(48, 64);
			this->txtSpeed->Name = S"txtSpeed";
			this->txtSpeed->Size = System::Drawing::Size(56, 22);
			this->txtSpeed->TabIndex = 2;
			this->txtSpeed->Text = S"";
			// 
			// txtNumFrame
			// 
			this->txtNumFrame->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtNumFrame->Location = System::Drawing::Point(48, 96);
			this->txtNumFrame->Name = S"txtNumFrame";
			this->txtNumFrame->Size = System::Drawing::Size(56, 22);
			this->txtNumFrame->TabIndex = 9;
			this->txtNumFrame->Text = S"";
			// 
			// txtDeltaTime
			// 
			this->txtDeltaTime->Location = System::Drawing::Point(152, 112);
			this->txtDeltaTime->Name = S"txtDeltaTime";
			this->txtDeltaTime->Size = System::Drawing::Size(72, 22);
			this->txtDeltaTime->TabIndex = 11;
			this->txtDeltaTime->Text = S"";
			// 
			// txtDrawTime
			// 
			this->txtDrawTime->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtDrawTime->Location = System::Drawing::Point(152, 88);
			this->txtDrawTime->Name = S"txtDrawTime";
			this->txtDrawTime->Size = System::Drawing::Size(72, 22);
			this->txtDrawTime->TabIndex = 10;
			this->txtDrawTime->Text = S"";
			// 
			// btnReady
			// 
			this->btnReady->Location = System::Drawing::Point(8, 24);
			this->btnReady->Name = S"btnReady";
			this->btnReady->Size = System::Drawing::Size(64, 32);
			this->btnReady->TabIndex = 17;
			this->btnReady->Text = S"Ready";
			this->btnReady->Click += new System::EventHandler(this, &Form1::btnReady_Click);
			// 
			// label7
			// 
			this->label7->Location = System::Drawing::Point(120, 112);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(40, 24);
			this->label7->TabIndex = 16;
			this->label7->Text = S"����";
			// 
			// label6
			// 
			this->label6->Location = System::Drawing::Point(120, 88);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(40, 24);
			this->label6->TabIndex = 15;
			this->label6->Text = S"�`��";
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(8, 96);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(48, 24);
			this->label5->TabIndex = 14;
			this->label5->Text = S"�R�}��";
			// 
			// btnStop
			// 
			this->btnStop->Location = System::Drawing::Point(298, 96);
			this->btnStop->Name = S"btnStop";
			this->btnStop->Size = System::Drawing::Size(48, 32);
			this->btnStop->TabIndex = 13;
			this->btnStop->Text = S"Stop";
			this->btnStop->Click += new System::EventHandler(this, &Form1::btnStop_Click);
			// 
			// btnStart
			// 
			this->btnStart->Location = System::Drawing::Point(240, 96);
			this->btnStart->Name = S"btnStart";
			this->btnStart->Size = System::Drawing::Size(56, 32);
			this->btnStart->TabIndex = 12;
			this->btnStart->Text = S"Start";
			this->btnStart->Click += new System::EventHandler(this, &Form1::btnStart_Click);
			// 
			// txtPeriod2
			// 
			this->txtPeriod2->Location = System::Drawing::Point(264, 64);
			this->txtPeriod2->Name = S"txtPeriod2";
			this->txtPeriod2->Size = System::Drawing::Size(56, 22);
			this->txtPeriod2->TabIndex = 8;
			this->txtPeriod2->Text = S"";
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(192, 64);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(72, 24);
			this->label4->TabIndex = 7;
			this->label4->Text = S"���]����";
			// 
			// txtPeriod1
			// 
			this->txtPeriod1->Location = System::Drawing::Point(264, 40);
			this->txtPeriod1->Name = S"txtPeriod1";
			this->txtPeriod1->Size = System::Drawing::Size(56, 22);
			this->txtPeriod1->TabIndex = 6;
			this->txtPeriod1->Text = S"";
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(192, 40);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(72, 24);
			this->label3->TabIndex = 5;
			this->label3->Text = S"���]����";
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(104, 64);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(40, 24);
			this->label2->TabIndex = 4;
			this->label2->Text = S"m/s";
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(16, 64);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(40, 24);
			this->label1->TabIndex = 3;
			this->label1->Text = S"���x";
			// 
			// rdbRotation
			// 
			this->rdbRotation->Location = System::Drawing::Point(216, 16);
			this->rdbRotation->Name = S"rdbRotation";
			this->rdbRotation->TabIndex = 1;
			this->rdbRotation->Text = S"��]�^��";
			// 
			// rdbLinear
			// 
			this->rdbLinear->Location = System::Drawing::Point(96, 16);
			this->rdbLinear->Name = S"rdbLinear";
			this->rdbLinear->Size = System::Drawing::Size(96, 24);
			this->rdbLinear->TabIndex = 0;
			this->rdbLinear->Text = S"�����^��";
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(320, 56);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(16, 23);
			this->label9->TabIndex = 19;
			this->label9->Text = S"s";
			// 
			// Form1
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(7, 15);
			this->ClientSize = System::Drawing::Size(368, 267);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox3);
			this->Controls->Add(this->chkWireframe);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->groupBox4);
			this->Name = S"Form1";
			this->Text = S"Animation(�A�j���[�V����)";
			this->Load += new System::EventHandler(this, &Form1::Form1_Load);
			this->Closed += new System::EventHandler(this, &Form1::Form1_Closed);
			this->groupBox2->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->groupBox1->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->ResumeLayout(false);

		}	

//-----------------------------------------------------------------------------------
	SpaceForm* spaceForm;//�R�����`��t�H�[���̃C���X�^���X
	bool flagStart;//�A�j���[�V�������s�t���O
    float speed;//�����^���̑��x
    float period1,period2;//��]�^���̎��]�C���]����
    float radius;//���]���a
    float t;//���̎��Ԍo�߁i���ԍ���dt�̘a�j
	int numFrame;//���R�}��
	private: System::Void Form1_Load(System::Object *  sender, System::EventArgs *  e)
	{
		//Form�̈ʒu
		Left = 100;
		Top = 100;
		//SpaceForm��\��
		spaceForm = new SpaceForm();
		spaceForm -> Show();
		//Floor�̏����l
		gridWidth = 1.0;
        txtGridWidth->Text = gridWidth.ToString();

		txtDeltaTime->Text = S"0.001";//�������ԑ���(s)
		//���x�̏����ݒ�
		txtSpeed->Text = S"1.0";
		//���]����
		txtPeriod1->Text = S"1.0";
		//���]����
		txtPeriod2->Text = S"10.0";
		//�����ʒu
        //txtLightX->Text = String::Format("{0:0.0}", __box(light.x));
        //txtLightY->Text = String::Format("{0:0.0}", __box(light.y));
        //txtLightZ->Text = String::Format("{0:0.0}", __box(light.z));
        txtLightX->Text = light.x.ToString();
        txtLightY->Text = light.y.ToString();
        txtLightZ->Text = light.z.ToString();
		rdbLinear->Checked = true;
	}

	private: System::Void btnReady_Click(System::Object *  sender, System::EventArgs *  e)
	{
		//OpenGL����
		IntPtr ptr = spaceForm->picSpace->Handle;//�f�o�C�X�R���e�L�X�g�̃n���h��
		hWnd = (HWND)ptr.ToInt32();
		hDC = GetDC(hWnd);
		setup.initOpenGL();
	
//		Image* im = Image::FromFile("\\CPPNetOpenGL\\bmp128\\check1.bmp");
		Image* im = Image::FromFile("../../bmp128/check1.bmp");
		Bitmap* bitmap = new Bitmap(im);

		//�`��I�u�W�F�N�g
		numTarget = 1;
		target[0].kind = CUBE;
		flagShadow = false;
		target[0].kind = CUBE;
		target[0].texType = T_PLANAR2;
		target[0].texMode = T_MODULATE;
	    target[0].makeTexture(bitmap);
		target[0].vSize = CVector(0.2f, 0.2f, 0.2f);
		//�g�U�F
		target[0].diffuse[0] = 0.9f; //red
		target[0].diffuse[1] = 0.9f;
		target[0].diffuse[2] = 0.9f;
		//�����ݒ�
		if(rdbLinear->Checked == true){
			target[0].vPos = CVector(0.0f, 0.0f, 0.0f);
			target[0].vPos.z = target[0].vSize.z / 2.0f;//���S�̍���
			speed = Convert::ToSingle(txtSpeed->Text);//m/s
		}
		else{
			radius = 2.0;
			target[0].vPos = CVector(radius, 0.0f, 0.0f);
			target[0].vPos.z = target[0].vSize.z / 2.0f;//���S�̍���
			period1 = Convert::ToSingle(txtPeriod1->Text);//�b�P�ʂŎw��
			period2 = Convert::ToSingle(txtPeriod2->Text);//�b�P�ʂŎw��
			t = 0.0f;//���̌o�ߎ��ԃN���A
		}

		numFrame = 0;//�R�}���N���A
	    txtNumFrame->Text = numFrame.ToString();

		display();
	}

	private: System::Void Form1_Closed(System::Object *  sender, System::EventArgs *  e)
	{
 		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);
	}

	private: System::Void display()
	{
	    int i;
		setup.set3DAmbient(spaceForm->picSpace);
		setup.setLight();
		flagShadow = chkShadow->Checked;

		glClear(GL_COLOR_BUFFER_BIT); //�װ�ޯ̧��ر
		glClear(GL_DEPTH_BUFFER_BIT); //���߽�ޯ̧��ر
	    //���������̂�����Ƃ��͎���2�s���K�v
	    glCullFace(GL_BACK);   //���ʂ��폜
	    glEnable(GL_CULL_FACE);//���ʍ폜��L���ɂ���

		setup.drawFloor(rdbNon, rdbCheck);//setup.h

	    if(chkWireframe->Checked == true){//ܲ԰�ڰ�����
		    glPolygonMode(GL_FRONT,GL_LINE);
		    glPolygonMode(GL_BACK,GL_POINT);
	    }
				
		//�������̂�����Ƃ��͈ȉ��̂悤�ɕs�������̂��ɂ��ׂĕ`��
		for(i = 0; i < numTarget; i++) {
			if(target[i].diffuse[3] == 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_FALSE); //���߽�ޯ̧���������݋֎~
		glEnable(GL_BLEND);//��̧�����ިݸނ�L���ɂ���
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);//�F�����W�������߂�

		//���������̂�`��
		for(i=0;i<numTarget;i++) {
			if(target[i].diffuse[3] != 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_TRUE); //���߽�ޯ̧�̏������݂�����
		glDisable(GL_BLEND);

        setup.drawShadow();//setup.h

        glPopMatrix();
	    SwapBuffers(hDC);
    }

	private: System::Void execute()
	{
		float drawTime, lapse;
		int h1, m1, s1, ms1;
		int h2, m2, s2, ms2;
		float dt;//��������
		double pp = 2.0 * M_PI;
		int k;
    
		//����
		dt = Convert::ToSingle(txtDeltaTime->Text);//�b�P�ʂŎw��

		txtDrawTime->Text = S" ";
		flagStart = true;

		Cursor = Cursors::AppStarting;//�J�[�\����ύX
		DateTime tStart = DateTime::Now;//���݂̎���
		h1 = tStart.Hour;
		m1 = tStart.Minute;
		s1 = tStart.Second;
		ms1 = tStart.Millisecond;

		int numFrame0 = 0;
		if(rdbLinear->Checked == true){ //�����^��
			for( k = 0; k < 2000; k++)
			{
				target[0].vPos.x += speed * dt;
				display();
				Application::DoEvents();
				if( flagStart == false ) break;
				numFrame++;
				numFrame0++;
			}
		}
		else{//��]�^��
			while(true) //�A�j���[�V�������[�v
			{
				target[0].vPos.x = radius * (float)cos(pp * t / period2);
				target[0].vPos.y = radius * (float)sin(pp * t / period2);
				target[0].vEuler.z = 360.0f * t / period1;//���]
				display();
				t += dt;//�o�ߎ���
				Application::DoEvents();
				if( flagStart == false ) break;
				numFrame++;
				numFrame0++;
			}
		}

		Cursor = Cursors::Default;
		DateTime tStop = DateTime::Now;
		h2 = tStop.Hour;
		m2 = tStop.Minute;
		s2 = tStop.Second;
		ms2 = tStop.Millisecond;
		//�o�ߎ���(sec)
		lapse = (float)(h2-h1) * 3600.0f + (float)(m2-m1) * 60.0f + (float)(s2-s1) + (float)(ms2-ms1) / 1000.0f;
		//1�R�}������̕`�掞��(sec)
		drawTime = lapse / (float)numFrame0;
		txtDrawTime->Text = drawTime.ToString();//�e�L�X�g�{�b�N�X�ɕ\��
		txtNumFrame->Text = numFrame.ToString();//���R�}��
	}


	private: System::Void btnStart_Click(System::Object *  sender, System::EventArgs *  e)
	{
		execute();
	}

	private: System::Void btnStop_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = false;
	}

    private: System::Void rdbCheck_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbGrid_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbNon_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void btnWidth_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
         if(e->Button == MouseButtons::Left)
                gridWidth += 0.1f;
         else
                gridWidth -= 0.1f;
         txtGridWidth->Text = gridWidth.ToString();
         display();
    }

    private: System::Void chkShadow_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        flagShadow = chkShadow->Checked;
        display();
    }

    private: System::Void btnDolly_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.dist -= 0.5f;
        else
            camera.dist += 0.5f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnZoom_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.fov -= 0.1f;
        else
            camera.fov += 0.1f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnPan_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta += 1.0f; //deg
   	    else
            camera.theta -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTumble_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta -= 5.0f;
        else
            camera.theta += 5.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTilt_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 1.0f; //deg
   	    else
            camera.phi -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.vCenter.z = camera.vPos.z - camera.dist * (float)sin(pp * camera.phi);
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnCrane_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 2.0f;
        else
            camera.phi -= 2.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnLightX_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.x += 1.0f;
        else
            light.x -= 1.0f;
        txtLightX->Text = String::Format("{0:0.0}", __box(light.x));

        display();
    }

    private: System::Void btnLightY_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.y += 1.0f;
        else
            light.y -= 1.0f;
        txtLightY->Text = String::Format("{0:0.0}", __box(light.y));

        display();
    }

    private: System::Void btnLightZ_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.z += 1.0f;
        else
            light.z -= 1.0f;
        txtLightZ->Text = String::Format("{0:0.0}", __box(light.z));

        display();
    }


	private: System::Void chkWireframe_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
        setup.initOpenGL(); //Mode�؂�ւ����ɂ͕K�v
        display();
	}



};
}


