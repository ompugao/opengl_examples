#pragma once

#include "setup.h"
CSetup setup;
#include "SpaceForm.h"

namespace SpringPendulum
{
	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary> 
	/// Form1 �̊T�v
	///
	/// �x�� : ���̃N���X�̖��O��ύX����ꍇ�A���̃N���X���ˑ����邷�ׂĂ� .resx �t�@�C���Ɋ֘A�t����ꂽ 
	///          �}�l�[�W ���\�[�X �R���p�C�� �c�[���ɑ΂��� 'Resource File Name' �v���p�e�B��
	///          �ύX����K�v������܂��B���̕ύX���s��Ȃ��ƁA
	///          �f�U�C�i�ƁA���̃t�H�[���Ɋ֘A�t����ꂽ���[�J���C�Y�ς݃��\�[�X�Ƃ����������݂ɗ��p�ł��Ȃ��Ȃ�܂��B
	/// </summary>
	public __gc class Form1 : public System::Windows::Forms::Form
	{	
	public:
		Form1(void)
		{
			InitializeComponent();
		}
  
	protected:
		void Dispose(Boolean disposing)
		{
			if (disposing && components)
			{
				components->Dispose();
			}
			__super::Dispose(disposing);
		}
	public: System::Windows::Forms::GroupBox *  groupBox1;
	private: System::Windows::Forms::Button *  btnStep;
	private: System::Windows::Forms::Label *  label22;

	private: System::Windows::Forms::Label *  label20;

	private: System::Windows::Forms::Label *  label18;
	private: System::Windows::Forms::TextBox *  txtMass;
	private: System::Windows::Forms::Label *  label16;
	private: System::Windows::Forms::TextBox *  txtNumThin;

	private: System::Windows::Forms::Label *  label12;

	private: System::Windows::Forms::Label *  label11;
	private: System::Windows::Forms::Label *  label10;
	private: System::Windows::Forms::TextBox *  txtFrequencyForced;

	private: System::Windows::Forms::Button *  btnStop;
	private: System::Windows::Forms::Button *  btnStart;
	private: System::Windows::Forms::TextBox *  txtDeltaTime;
	private: System::Windows::Forms::Label *  label9;
	private: System::Windows::Forms::TextBox *  txtDrawTime;
	private: System::Windows::Forms::Label *  label8;
	private: System::Windows::Forms::TextBox *  txtNumFrame;
	private: System::Windows::Forms::Label *  label7;

	private: System::Windows::Forms::Label *  label4;
	private: System::Windows::Forms::Label *  label3;

	private: System::Windows::Forms::Label *  label2;

	private: System::Windows::Forms::Label *  label1;
	private: System::Windows::Forms::Button *  btnReady;
	private: System::Windows::Forms::CheckBox *  chkWireframe;

	private: System::Windows::Forms::GroupBox *  groupBox2;
	private: System::Windows::Forms::Button *  btnCrane;
	private: System::Windows::Forms::Button *  btnTilt;
	private: System::Windows::Forms::Button *  btnTumble;
	private: System::Windows::Forms::Button *  btnPan;
	private: System::Windows::Forms::Button *  btnZoom;
	private: System::Windows::Forms::Button *  btnDolly;
	public: System::Windows::Forms::GroupBox *  groupBox4;
	private: System::Windows::Forms::CheckBox *  chkShadow;
	private: System::Windows::Forms::TextBox *  txtGridWidth;
	private: System::Windows::Forms::Button *  btnWidth;
	public: System::Windows::Forms::RadioButton *  rdbCheck;
	public: System::Windows::Forms::RadioButton *  rdbGrid;
	public: System::Windows::Forms::RadioButton *  rdbNon;
	private: System::Windows::Forms::GroupBox *  groupBox3;
	private: System::Windows::Forms::TextBox *  txtLightZ;
	private: System::Windows::Forms::Button *  btnLightZ;
	private: System::Windows::Forms::TextBox *  txtLightY;
	private: System::Windows::Forms::Button *  btnLightY;
	private: System::Windows::Forms::TextBox *  txtLightX;
	private: System::Windows::Forms::Button *  btnLightX;
	private: System::Windows::Forms::Label *  label5;
	private: System::Windows::Forms::CheckBox *  chkSimple;
	private: System::Windows::Forms::CheckBox *  chkForced;
	private: System::Windows::Forms::Button *  btnConst;
	private: System::Windows::Forms::Button *  btnDamping;
	private: System::Windows::Forms::Button *  btnAmplitude;
	private: System::Windows::Forms::Button *  tnFrequencyForced;
	private: System::Windows::Forms::Label *  label6;
	private: System::Windows::Forms::Label *  label13;
	private: System::Windows::Forms::Button *  btnMass;
	private: System::Windows::Forms::TextBox *  txtDamping;
	private: System::Windows::Forms::TextBox *  txtConst;
	private: System::Windows::Forms::TextBox *  txtAmpForced;
	private: System::Windows::Forms::TextBox *  txtTheta;
	private: System::Windows::Forms::TextBox *  txtDisplacement;
	private: System::Windows::Forms::TextBox *  txtLimitLength;
	private: System::Windows::Forms::TextBox *  txtLength;
	private: System::Windows::Forms::Label *  label14;


	private:
		/// <summary>
		/// �K�v�ȃf�U�C�i�ϐ��ł��B
		/// </summary>
		System::ComponentModel::Container * components;

		/// <summary>
		/// �f�U�C�i �T�|�[�g�ɕK�v�ȃ��\�b�h�ł��B���̃��\�b�h�̓��e��
		/// �R�[�h �G�f�B�^�ŕύX���Ȃ��ł��������B
		/// </summary>
		void InitializeComponent(void)
		{
			this->groupBox1 = new System::Windows::Forms::GroupBox();
			this->label13 = new System::Windows::Forms::Label();
			this->label6 = new System::Windows::Forms::Label();
			this->tnFrequencyForced = new System::Windows::Forms::Button();
			this->btnAmplitude = new System::Windows::Forms::Button();
			this->btnDamping = new System::Windows::Forms::Button();
			this->btnConst = new System::Windows::Forms::Button();
			this->chkForced = new System::Windows::Forms::CheckBox();
			this->chkSimple = new System::Windows::Forms::CheckBox();
			this->label5 = new System::Windows::Forms::Label();
			this->btnStep = new System::Windows::Forms::Button();
			this->label22 = new System::Windows::Forms::Label();
			this->txtDamping = new System::Windows::Forms::TextBox();
			this->label20 = new System::Windows::Forms::Label();
			this->txtConst = new System::Windows::Forms::TextBox();
			this->label18 = new System::Windows::Forms::Label();
			this->txtMass = new System::Windows::Forms::TextBox();
			this->label16 = new System::Windows::Forms::Label();
			this->txtNumThin = new System::Windows::Forms::TextBox();
			this->txtTheta = new System::Windows::Forms::TextBox();
			this->label12 = new System::Windows::Forms::Label();
			this->txtDisplacement = new System::Windows::Forms::TextBox();
			this->label11 = new System::Windows::Forms::Label();
			this->label10 = new System::Windows::Forms::Label();
			this->txtFrequencyForced = new System::Windows::Forms::TextBox();
			this->btnMass = new System::Windows::Forms::Button();
			this->btnStop = new System::Windows::Forms::Button();
			this->btnStart = new System::Windows::Forms::Button();
			this->txtDeltaTime = new System::Windows::Forms::TextBox();
			this->label9 = new System::Windows::Forms::Label();
			this->txtDrawTime = new System::Windows::Forms::TextBox();
			this->label8 = new System::Windows::Forms::Label();
			this->txtNumFrame = new System::Windows::Forms::TextBox();
			this->label7 = new System::Windows::Forms::Label();
			this->txtAmpForced = new System::Windows::Forms::TextBox();
			this->label4 = new System::Windows::Forms::Label();
			this->label3 = new System::Windows::Forms::Label();
			this->txtLimitLength = new System::Windows::Forms::TextBox();
			this->label2 = new System::Windows::Forms::Label();
			this->txtLength = new System::Windows::Forms::TextBox();
			this->label1 = new System::Windows::Forms::Label();
			this->btnReady = new System::Windows::Forms::Button();
			this->chkWireframe = new System::Windows::Forms::CheckBox();
			this->groupBox2 = new System::Windows::Forms::GroupBox();
			this->btnCrane = new System::Windows::Forms::Button();
			this->btnTilt = new System::Windows::Forms::Button();
			this->btnTumble = new System::Windows::Forms::Button();
			this->btnPan = new System::Windows::Forms::Button();
			this->btnZoom = new System::Windows::Forms::Button();
			this->btnDolly = new System::Windows::Forms::Button();
			this->groupBox4 = new System::Windows::Forms::GroupBox();
			this->chkShadow = new System::Windows::Forms::CheckBox();
			this->txtGridWidth = new System::Windows::Forms::TextBox();
			this->btnWidth = new System::Windows::Forms::Button();
			this->rdbCheck = new System::Windows::Forms::RadioButton();
			this->rdbGrid = new System::Windows::Forms::RadioButton();
			this->rdbNon = new System::Windows::Forms::RadioButton();
			this->groupBox3 = new System::Windows::Forms::GroupBox();
			this->txtLightZ = new System::Windows::Forms::TextBox();
			this->btnLightZ = new System::Windows::Forms::Button();
			this->txtLightY = new System::Windows::Forms::TextBox();
			this->btnLightY = new System::Windows::Forms::Button();
			this->txtLightX = new System::Windows::Forms::TextBox();
			this->btnLightX = new System::Windows::Forms::Button();
			this->label14 = new System::Windows::Forms::Label();
			this->groupBox1->SuspendLayout();
			this->groupBox2->SuspendLayout();
			this->groupBox4->SuspendLayout();
			this->groupBox3->SuspendLayout();
			this->SuspendLayout();
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label14);
			this->groupBox1->Controls->Add(this->label13);
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->tnFrequencyForced);
			this->groupBox1->Controls->Add(this->btnAmplitude);
			this->groupBox1->Controls->Add(this->btnDamping);
			this->groupBox1->Controls->Add(this->btnConst);
			this->groupBox1->Controls->Add(this->chkForced);
			this->groupBox1->Controls->Add(this->chkSimple);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->btnStep);
			this->groupBox1->Controls->Add(this->label22);
			this->groupBox1->Controls->Add(this->txtDamping);
			this->groupBox1->Controls->Add(this->label20);
			this->groupBox1->Controls->Add(this->txtConst);
			this->groupBox1->Controls->Add(this->label18);
			this->groupBox1->Controls->Add(this->txtMass);
			this->groupBox1->Controls->Add(this->label16);
			this->groupBox1->Controls->Add(this->txtNumThin);
			this->groupBox1->Controls->Add(this->txtTheta);
			this->groupBox1->Controls->Add(this->label12);
			this->groupBox1->Controls->Add(this->txtDisplacement);
			this->groupBox1->Controls->Add(this->label11);
			this->groupBox1->Controls->Add(this->label10);
			this->groupBox1->Controls->Add(this->txtFrequencyForced);
			this->groupBox1->Controls->Add(this->btnMass);
			this->groupBox1->Controls->Add(this->btnStop);
			this->groupBox1->Controls->Add(this->btnStart);
			this->groupBox1->Controls->Add(this->txtDeltaTime);
			this->groupBox1->Controls->Add(this->label9);
			this->groupBox1->Controls->Add(this->txtDrawTime);
			this->groupBox1->Controls->Add(this->label8);
			this->groupBox1->Controls->Add(this->txtNumFrame);
			this->groupBox1->Controls->Add(this->label7);
			this->groupBox1->Controls->Add(this->txtAmpForced);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->txtLimitLength);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->txtLength);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Controls->Add(this->btnReady);
			this->groupBox1->Location = System::Drawing::Point(0, 8);
			this->groupBox1->Name = S"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(440, 176);
			this->groupBox1->TabIndex = 37;
			this->groupBox1->TabStop = false;
			this->groupBox1->Text = S"Animation";
			// 
			// label13
			// 
			this->label13->Location = System::Drawing::Point(112, 136);
			this->label13->Name = S"label13";
			this->label13->Size = System::Drawing::Size(24, 16);
			this->label13->TabIndex = 53;
			this->label13->Text = S"Hz";
			// 
			// label6
			// 
			this->label6->Location = System::Drawing::Point(112, 112);
			this->label6->Name = S"label6";
			this->label6->Size = System::Drawing::Size(24, 16);
			this->label6->TabIndex = 52;
			this->label6->Text = S"m";
			// 
			// tnFrequencyForced
			// 
			this->tnFrequencyForced->Location = System::Drawing::Point(8, 136);
			this->tnFrequencyForced->Name = S"tnFrequencyForced";
			this->tnFrequencyForced->Size = System::Drawing::Size(64, 24);
			this->tnFrequencyForced->TabIndex = 51;
			this->tnFrequencyForced->Text = S"�U����";
			this->tnFrequencyForced->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::tnFrequencyForced_MouseDown);
			// 
			// btnAmplitude
			// 
			this->btnAmplitude->Location = System::Drawing::Point(16, 112);
			this->btnAmplitude->Name = S"btnAmplitude";
			this->btnAmplitude->Size = System::Drawing::Size(48, 24);
			this->btnAmplitude->TabIndex = 50;
			this->btnAmplitude->Text = S"�U��";
			this->btnAmplitude->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnAmplitude_MouseDown);
			// 
			// btnDamping
			// 
			this->btnDamping->Location = System::Drawing::Point(232, 64);
			this->btnDamping->Name = S"btnDamping";
			this->btnDamping->Size = System::Drawing::Size(80, 24);
			this->btnDamping->TabIndex = 49;
			this->btnDamping->Text = S"�����W��";
			this->btnDamping->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDamping_MouseDown);
			// 
			// btnConst
			// 
			this->btnConst->Location = System::Drawing::Point(232, 40);
			this->btnConst->Name = S"btnConst";
			this->btnConst->Size = System::Drawing::Size(80, 24);
			this->btnConst->TabIndex = 48;
			this->btnConst->Text = S"�o�l�萔";
			this->btnConst->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnConst_MouseDown);
			// 
			// chkForced
			// 
			this->chkForced->Location = System::Drawing::Point(8, 72);
			this->chkForced->Name = S"chkForced";
			this->chkForced->Size = System::Drawing::Size(88, 24);
			this->chkForced->TabIndex = 47;
			this->chkForced->Text = S"�����U��";
			// 
			// chkSimple
			// 
			this->chkSimple->Location = System::Drawing::Point(8, 48);
			this->chkSimple->Name = S"chkSimple";
			this->chkSimple->Size = System::Drawing::Size(72, 24);
			this->chkSimple->TabIndex = 46;
			this->chkSimple->Text = S"�ȈՉ�";
			// 
			// label5
			// 
			this->label5->Location = System::Drawing::Point(200, 48);
			this->label5->Name = S"label5";
			this->label5->Size = System::Drawing::Size(24, 16);
			this->label5->TabIndex = 45;
			this->label5->Text = S"m";
			// 
			// btnStep
			// 
			this->btnStep->Location = System::Drawing::Point(352, 144);
			this->btnStep->Name = S"btnStep";
			this->btnStep->Size = System::Drawing::Size(48, 24);
			this->btnStep->TabIndex = 44;
			this->btnStep->Text = S"Step";
			this->btnStep->Click += new System::EventHandler(this, &Form1::btnStep_Click);
			// 
			// label22
			// 
			this->label22->Location = System::Drawing::Point(352, 72);
			this->label22->Name = S"label22";
			this->label22->Size = System::Drawing::Size(40, 16);
			this->label22->TabIndex = 43;
			this->label22->Text = S"Kg/s";
			// 
			// txtDamping
			// 
			this->txtDamping->Location = System::Drawing::Point(312, 64);
			this->txtDamping->Name = S"txtDamping";
			this->txtDamping->Size = System::Drawing::Size(40, 22);
			this->txtDamping->TabIndex = 42;
			this->txtDamping->Text = S"";
			// 
			// label20
			// 
			this->label20->Location = System::Drawing::Point(352, 48);
			this->label20->Name = S"label20";
			this->label20->Size = System::Drawing::Size(56, 16);
			this->label20->TabIndex = 40;
			this->label20->Text = S"Kg/s^2";
			// 
			// txtConst
			// 
			this->txtConst->Location = System::Drawing::Point(312, 40);
			this->txtConst->Name = S"txtConst";
			this->txtConst->Size = System::Drawing::Size(40, 22);
			this->txtConst->TabIndex = 39;
			this->txtConst->Text = S"";
			// 
			// label18
			// 
			this->label18->Location = System::Drawing::Point(352, 24);
			this->label18->Name = S"label18";
			this->label18->Size = System::Drawing::Size(32, 16);
			this->label18->TabIndex = 37;
			this->label18->Text = S"Kg";
			// 
			// txtMass
			// 
			this->txtMass->Location = System::Drawing::Point(312, 16);
			this->txtMass->Name = S"txtMass";
			this->txtMass->Size = System::Drawing::Size(40, 22);
			this->txtMass->TabIndex = 36;
			this->txtMass->Text = S"";
			// 
			// label16
			// 
			this->label16->Location = System::Drawing::Point(296, 96);
			this->label16->Name = S"label16";
			this->label16->Size = System::Drawing::Size(80, 16);
			this->label16->TabIndex = 34;
			this->label16->Text = S"�Ԉ����\��";
			// 
			// txtNumThin
			// 
			this->txtNumThin->Location = System::Drawing::Point(376, 96);
			this->txtNumThin->Name = S"txtNumThin";
			this->txtNumThin->Size = System::Drawing::Size(48, 22);
			this->txtNumThin->TabIndex = 29;
			this->txtNumThin->Text = S"";
			// 
			// txtTheta
			// 
			this->txtTheta->Location = System::Drawing::Point(160, 88);
			this->txtTheta->Name = S"txtTheta";
			this->txtTheta->Size = System::Drawing::Size(40, 22);
			this->txtTheta->TabIndex = 27;
			this->txtTheta->Text = S"";
			// 
			// label12
			// 
			this->label12->Location = System::Drawing::Point(96, 88);
			this->label12->Name = S"label12";
			this->label12->Size = System::Drawing::Size(72, 16);
			this->label12->TabIndex = 26;
			this->label12->Text = S"�����p�x";
			// 
			// txtDisplacement
			// 
			this->txtDisplacement->Location = System::Drawing::Point(160, 64);
			this->txtDisplacement->Name = S"txtDisplacement";
			this->txtDisplacement->Size = System::Drawing::Size(40, 22);
			this->txtDisplacement->TabIndex = 25;
			this->txtDisplacement->Text = S"";
			// 
			// label11
			// 
			this->label11->Location = System::Drawing::Point(96, 64);
			this->label11->Name = S"label11";
			this->label11->Size = System::Drawing::Size(72, 16);
			this->label11->TabIndex = 24;
			this->label11->Text = S"�����ψ�";
			// 
			// label10
			// 
			this->label10->Location = System::Drawing::Point(200, 72);
			this->label10->Name = S"label10";
			this->label10->Size = System::Drawing::Size(24, 16);
			this->label10->TabIndex = 23;
			this->label10->Text = S"m";
			// 
			// txtFrequencyForced
			// 
			this->txtFrequencyForced->BackColor = System::Drawing::SystemColors::ControlLightLight;
			this->txtFrequencyForced->Location = System::Drawing::Point(72, 136);
			this->txtFrequencyForced->Name = S"txtFrequencyForced";
			this->txtFrequencyForced->Size = System::Drawing::Size(40, 22);
			this->txtFrequencyForced->TabIndex = 21;
			this->txtFrequencyForced->Text = S"";
			// 
			// btnMass
			// 
			this->btnMass->Location = System::Drawing::Point(256, 16);
			this->btnMass->Name = S"btnMass";
			this->btnMass->Size = System::Drawing::Size(48, 24);
			this->btnMass->TabIndex = 20;
			this->btnMass->Text = S"�d��";
			this->btnMass->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnMass_MouseDown);
			// 
			// btnStop
			// 
			this->btnStop->Location = System::Drawing::Point(384, 120);
			this->btnStop->Name = S"btnStop";
			this->btnStop->Size = System::Drawing::Size(48, 24);
			this->btnStop->TabIndex = 19;
			this->btnStop->Text = S"Stop";
			this->btnStop->Click += new System::EventHandler(this, &Form1::btnStop_Click);
			// 
			// btnStart
			// 
			this->btnStart->Location = System::Drawing::Point(328, 120);
			this->btnStart->Name = S"btnStart";
			this->btnStart->Size = System::Drawing::Size(48, 24);
			this->btnStart->TabIndex = 18;
			this->btnStart->Text = S"Start";
			this->btnStart->Click += new System::EventHandler(this, &Form1::btnStart_Click);
			// 
			// txtDeltaTime
			// 
			this->txtDeltaTime->Location = System::Drawing::Point(232, 144);
			this->txtDeltaTime->Name = S"txtDeltaTime";
			this->txtDeltaTime->Size = System::Drawing::Size(72, 22);
			this->txtDeltaTime->TabIndex = 15;
			this->txtDeltaTime->Text = S"";
			// 
			// label9
			// 
			this->label9->Location = System::Drawing::Point(200, 144);
			this->label9->Name = S"label9";
			this->label9->Size = System::Drawing::Size(40, 16);
			this->label9->TabIndex = 14;
			this->label9->Text = S"����";
			// 
			// txtDrawTime
			// 
			this->txtDrawTime->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtDrawTime->Location = System::Drawing::Point(232, 120);
			this->txtDrawTime->Name = S"txtDrawTime";
			this->txtDrawTime->Size = System::Drawing::Size(72, 22);
			this->txtDrawTime->TabIndex = 13;
			this->txtDrawTime->Text = S"";
			// 
			// label8
			// 
			this->label8->Location = System::Drawing::Point(200, 120);
			this->label8->Name = S"label8";
			this->label8->Size = System::Drawing::Size(40, 16);
			this->label8->TabIndex = 12;
			this->label8->Text = S"�`��";
			// 
			// txtNumFrame
			// 
			this->txtNumFrame->BackColor = System::Drawing::SystemColors::InactiveBorder;
			this->txtNumFrame->Location = System::Drawing::Point(136, 136);
			this->txtNumFrame->Name = S"txtNumFrame";
			this->txtNumFrame->Size = System::Drawing::Size(56, 22);
			this->txtNumFrame->TabIndex = 11;
			this->txtNumFrame->Text = S"";
			// 
			// label7
			// 
			this->label7->Location = System::Drawing::Point(144, 120);
			this->label7->Name = S"label7";
			this->label7->Size = System::Drawing::Size(48, 16);
			this->label7->TabIndex = 10;
			this->label7->Text = S"�R�}��";
			// 
			// txtAmpForced
			// 
			this->txtAmpForced->Location = System::Drawing::Point(72, 112);
			this->txtAmpForced->Name = S"txtAmpForced";
			this->txtAmpForced->Size = System::Drawing::Size(40, 22);
			this->txtAmpForced->TabIndex = 8;
			this->txtAmpForced->Text = S"";
			// 
			// label4
			// 
			this->label4->Location = System::Drawing::Point(200, 96);
			this->label4->Name = S"label4";
			this->label4->Size = System::Drawing::Size(48, 16);
			this->label4->TabIndex = 6;
			this->label4->Text = S"deg";
			// 
			// label3
			// 
			this->label3->Location = System::Drawing::Point(200, 24);
			this->label3->Name = S"label3";
			this->label3->Size = System::Drawing::Size(32, 16);
			this->label3->TabIndex = 5;
			this->label3->Text = S"m";
			// 
			// txtLimitLength
			// 
			this->txtLimitLength->Location = System::Drawing::Point(160, 40);
			this->txtLimitLength->Name = S"txtLimitLength";
			this->txtLimitLength->Size = System::Drawing::Size(40, 22);
			this->txtLimitLength->TabIndex = 4;
			this->txtLimitLength->Text = S"";
			// 
			// label2
			// 
			this->label2->Location = System::Drawing::Point(80, 40);
			this->label2->Name = S"label2";
			this->label2->Size = System::Drawing::Size(80, 16);
			this->label2->TabIndex = 3;
			this->label2->Text = S"�o�l���E��";
			// 
			// txtLength
			// 
			this->txtLength->Location = System::Drawing::Point(160, 16);
			this->txtLength->Name = S"txtLength";
			this->txtLength->Size = System::Drawing::Size(40, 22);
			this->txtLength->TabIndex = 2;
			this->txtLength->Text = S"";
			// 
			// label1
			// 
			this->label1->Location = System::Drawing::Point(80, 16);
			this->label1->Name = S"label1";
			this->label1->Size = System::Drawing::Size(80, 24);
			this->label1->TabIndex = 1;
			this->label1->Text = S"�o�l���R��";
			// 
			// btnReady
			// 
			this->btnReady->Location = System::Drawing::Point(8, 16);
			this->btnReady->Name = S"btnReady";
			this->btnReady->Size = System::Drawing::Size(72, 32);
			this->btnReady->TabIndex = 0;
			this->btnReady->Text = S"Ready";
			this->btnReady->Click += new System::EventHandler(this, &Form1::btnReady_Click);
			// 
			// chkWireframe
			// 
			this->chkWireframe->Location = System::Drawing::Point(24, 256);
			this->chkWireframe->Name = S"chkWireframe";
			this->chkWireframe->Size = System::Drawing::Size(96, 24);
			this->chkWireframe->TabIndex = 41;
			this->chkWireframe->Text = S"Wireframe";
			this->chkWireframe->CheckedChanged += new System::EventHandler(this, &Form1::chkWireframe_CheckedChanged);
			// 
			// groupBox2
			// 
			this->groupBox2->Controls->Add(this->btnCrane);
			this->groupBox2->Controls->Add(this->btnTilt);
			this->groupBox2->Controls->Add(this->btnTumble);
			this->groupBox2->Controls->Add(this->btnPan);
			this->groupBox2->Controls->Add(this->btnZoom);
			this->groupBox2->Controls->Add(this->btnDolly);
			this->groupBox2->Location = System::Drawing::Point(224, 184);
			this->groupBox2->Name = S"groupBox2";
			this->groupBox2->Size = System::Drawing::Size(128, 96);
			this->groupBox2->TabIndex = 39;
			this->groupBox2->TabStop = false;
			this->groupBox2->Text = S"Camera";
			// 
			// btnCrane
			// 
			this->btnCrane->Location = System::Drawing::Point(56, 62);
			this->btnCrane->Name = S"btnCrane";
			this->btnCrane->Size = System::Drawing::Size(64, 21);
			this->btnCrane->TabIndex = 5;
			this->btnCrane->Text = S"Crane";
			this->btnCrane->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnCrane_MouseDown);
			// 
			// btnTilt
			// 
			this->btnTilt->Location = System::Drawing::Point(8, 62);
			this->btnTilt->Name = S"btnTilt";
			this->btnTilt->Size = System::Drawing::Size(48, 21);
			this->btnTilt->TabIndex = 4;
			this->btnTilt->Text = S"Tilt";
			this->btnTilt->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTilt_MouseDown);
			// 
			// btnTumble
			// 
			this->btnTumble->Location = System::Drawing::Point(56, 41);
			this->btnTumble->Name = S"btnTumble";
			this->btnTumble->Size = System::Drawing::Size(64, 21);
			this->btnTumble->TabIndex = 3;
			this->btnTumble->Text = S"Tumble";
			this->btnTumble->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnTumble_MouseDown);
			// 
			// btnPan
			// 
			this->btnPan->Location = System::Drawing::Point(8, 41);
			this->btnPan->Name = S"btnPan";
			this->btnPan->Size = System::Drawing::Size(48, 21);
			this->btnPan->TabIndex = 2;
			this->btnPan->Text = S"Pan";
			this->btnPan->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnPan_MouseDown);
			// 
			// btnZoom
			// 
			this->btnZoom->Location = System::Drawing::Point(56, 18);
			this->btnZoom->Name = S"btnZoom";
			this->btnZoom->Size = System::Drawing::Size(64, 22);
			this->btnZoom->TabIndex = 1;
			this->btnZoom->Text = S"Zoom";
			this->btnZoom->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnZoom_MouseDown);
			// 
			// btnDolly
			// 
			this->btnDolly->Location = System::Drawing::Point(8, 18);
			this->btnDolly->Name = S"btnDolly";
			this->btnDolly->Size = System::Drawing::Size(48, 22);
			this->btnDolly->TabIndex = 0;
			this->btnDolly->Text = S"Dolly";
			this->btnDolly->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnDolly_MouseDown);
			// 
			// groupBox4
			// 
			this->groupBox4->Controls->Add(this->chkShadow);
			this->groupBox4->Controls->Add(this->txtGridWidth);
			this->groupBox4->Controls->Add(this->btnWidth);
			this->groupBox4->Controls->Add(this->rdbCheck);
			this->groupBox4->Controls->Add(this->rdbGrid);
			this->groupBox4->Controls->Add(this->rdbNon);
			this->groupBox4->Location = System::Drawing::Point(0, 184);
			this->groupBox4->Name = S"groupBox4";
			this->groupBox4->Size = System::Drawing::Size(216, 72);
			this->groupBox4->TabIndex = 38;
			this->groupBox4->TabStop = false;
			this->groupBox4->Text = S"Floor";
			// 
			// chkShadow
			// 
			this->chkShadow->Location = System::Drawing::Point(112, 40);
			this->chkShadow->Name = S"chkShadow";
			this->chkShadow->Size = System::Drawing::Size(88, 16);
			this->chkShadow->TabIndex = 5;
			this->chkShadow->Text = S"Shadow";
			this->chkShadow->CheckedChanged += new System::EventHandler(this, &Form1::chkShadow_CheckedChanged);
			// 
			// txtGridWidth
			// 
			this->txtGridWidth->Location = System::Drawing::Point(64, 40);
			this->txtGridWidth->Name = S"txtGridWidth";
			this->txtGridWidth->Size = System::Drawing::Size(40, 22);
			this->txtGridWidth->TabIndex = 4;
			this->txtGridWidth->Text = S"";
			// 
			// btnWidth
			// 
			this->btnWidth->Location = System::Drawing::Point(8, 40);
			this->btnWidth->Name = S"btnWidth";
			this->btnWidth->Size = System::Drawing::Size(56, 24);
			this->btnWidth->TabIndex = 3;
			this->btnWidth->Text = S"Width";
			this->btnWidth->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnWidth_MouseDown);
			// 
			// rdbCheck
			// 
			this->rdbCheck->Location = System::Drawing::Point(136, 16);
			this->rdbCheck->Name = S"rdbCheck";
			this->rdbCheck->Size = System::Drawing::Size(72, 24);
			this->rdbCheck->TabIndex = 2;
			this->rdbCheck->Text = S"Check";
			this->rdbCheck->CheckedChanged += new System::EventHandler(this, &Form1::rdbCheck_CheckedChanged);
			// 
			// rdbGrid
			// 
			this->rdbGrid->Checked = true;
			this->rdbGrid->Location = System::Drawing::Point(76, 16);
			this->rdbGrid->Name = S"rdbGrid";
			this->rdbGrid->Size = System::Drawing::Size(72, 24);
			this->rdbGrid->TabIndex = 1;
			this->rdbGrid->TabStop = true;
			this->rdbGrid->Text = S"Grid";
			this->rdbGrid->CheckedChanged += new System::EventHandler(this, &Form1::rdbGrid_CheckedChanged);
			// 
			// rdbNon
			// 
			this->rdbNon->Location = System::Drawing::Point(16, 16);
			this->rdbNon->Name = S"rdbNon";
			this->rdbNon->Size = System::Drawing::Size(56, 24);
			this->rdbNon->TabIndex = 0;
			this->rdbNon->Text = S"Non";
			this->rdbNon->CheckedChanged += new System::EventHandler(this, &Form1::rdbNon_CheckedChanged);
			// 
			// groupBox3
			// 
			this->groupBox3->Controls->Add(this->txtLightZ);
			this->groupBox3->Controls->Add(this->btnLightZ);
			this->groupBox3->Controls->Add(this->txtLightY);
			this->groupBox3->Controls->Add(this->btnLightY);
			this->groupBox3->Controls->Add(this->txtLightX);
			this->groupBox3->Controls->Add(this->btnLightX);
			this->groupBox3->Location = System::Drawing::Point(360, 184);
			this->groupBox3->Name = S"groupBox3";
			this->groupBox3->Size = System::Drawing::Size(72, 96);
			this->groupBox3->TabIndex = 40;
			this->groupBox3->TabStop = false;
			this->groupBox3->Text = S"Light";
			// 
			// txtLightZ
			// 
			this->txtLightZ->Location = System::Drawing::Point(32, 64);
			this->txtLightZ->Name = S"txtLightZ";
			this->txtLightZ->Size = System::Drawing::Size(34, 22);
			this->txtLightZ->TabIndex = 5;
			this->txtLightZ->Text = S"";
			// 
			// btnLightZ
			// 
			this->btnLightZ->Location = System::Drawing::Point(8, 64);
			this->btnLightZ->Name = S"btnLightZ";
			this->btnLightZ->Size = System::Drawing::Size(24, 22);
			this->btnLightZ->TabIndex = 4;
			this->btnLightZ->Text = S"Z";
			this->btnLightZ->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightZ_MouseDown);
			// 
			// txtLightY
			// 
			this->txtLightY->Location = System::Drawing::Point(32, 40);
			this->txtLightY->Name = S"txtLightY";
			this->txtLightY->Size = System::Drawing::Size(33, 22);
			this->txtLightY->TabIndex = 3;
			this->txtLightY->Text = S"";
			// 
			// btnLightY
			// 
			this->btnLightY->Location = System::Drawing::Point(8, 40);
			this->btnLightY->Name = S"btnLightY";
			this->btnLightY->Size = System::Drawing::Size(24, 24);
			this->btnLightY->TabIndex = 2;
			this->btnLightY->Text = S"Y";
			this->btnLightY->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightY_MouseDown);
			// 
			// txtLightX
			// 
			this->txtLightX->Location = System::Drawing::Point(32, 16);
			this->txtLightX->Name = S"txtLightX";
			this->txtLightX->Size = System::Drawing::Size(32, 22);
			this->txtLightX->TabIndex = 1;
			this->txtLightX->Text = S"";
			// 
			// btnLightX
			// 
			this->btnLightX->Location = System::Drawing::Point(8, 16);
			this->btnLightX->Name = S"btnLightX";
			this->btnLightX->Size = System::Drawing::Size(24, 24);
			this->btnLightX->TabIndex = 0;
			this->btnLightX->Text = S"X";
			this->btnLightX->MouseDown += new System::Windows::Forms::MouseEventHandler(this, &Form1::btnLightX_MouseDown);
			// 
			// label14
			// 
			this->label14->Location = System::Drawing::Point(304, 136);
			this->label14->Name = S"label14";
			this->label14->Size = System::Drawing::Size(24, 16);
			this->label14->TabIndex = 54;
			this->label14->Text = S"s";
			// 
			// Form1
			// 
			this->AutoScaleBaseSize = System::Drawing::Size(7, 15);
			this->ClientSize = System::Drawing::Size(448, 283);
			this->Controls->Add(this->groupBox1);
			this->Controls->Add(this->chkWireframe);
			this->Controls->Add(this->groupBox2);
			this->Controls->Add(this->groupBox4);
			this->Controls->Add(this->groupBox3);
			this->Name = S"Form1";
			this->Text = S"SpringPendulum(�΂ːU��q)";
			this->Load += new System::EventHandler(this, &Form1::Form1_Load);
			this->Closed += new System::EventHandler(this, &Form1::Form1_Closed);
			this->groupBox1->ResumeLayout(false);
			this->groupBox2->ResumeLayout(false);
			this->groupBox4->ResumeLayout(false);
			this->groupBox3->ResumeLayout(false);
			this->ResumeLayout(false);

		}	
//------------------------------------------------------------------------------
	SpaceForm* spaceForm;//�R�����`��t�H�[���̃C���X�^���X
	bool flagStart;//�A�j���[�V�������s�t���O
	bool flagStep;//�X�e�b�v���s�t���O

    double constK;//�΂˒萔
    double damping;//�����W��
    double length0;//�΂˂̎��R��
    double limitLength;//���E��
    double realLength;//���ۂ̒���
    double mass;//����
    double height0;//�Œ�_�̍���
    double disp;//���R������̂���i�ψ�)
    double theta0; //�����p�x
    double af, ff; //�����U��
    double time;
    double v, alpha, beta, theta;
    double height;

	static double g = 9.8;//�d�͉����x
	static double pp = M_PI / 180.0;
    float t;//���̎��Ԍo�߁i���ԍ���dt�̘a�j
	int numFrame;//���R�}��

private: System::Void Form1_Load(System::Object *  sender, System::EventArgs *  e)
	{
		//Form�̈ʒu
		Left = 100;
		Top = 100;
		//SpaceForm��\��
		spaceForm = new SpaceForm();
		spaceForm -> Show();
		//Floor�̏����l
		gridWidth = 1.0;
        txtGridWidth->Text = gridWidth.ToString();

		txtDeltaTime->Text = S"0.001";//�������ԑ���(s)

		//�΂˂̒���
		length0 = 1.0; //�΂˂̎��R��
		txtLength->Text = String::Format("{0:0.0}", __box(length0));
		//���E��
		limitLength = 3.0;
		txtLimitLength->Text = String::Format("{0:0.0}", __box(limitLength));
		//�U��q�̎���
		mass = 1.0;
		txtMass->Text = String::Format("{0:0.0}", __box(mass));
		disp = 0.5;//�肠���̈ʒu����̂���(�ψ�)
		txtDisplacement->Text = String::Format("{0:0.000}", __box(disp));
		//�����萔
		constK = 50.0;//kg/s^2(�o�l�萔)
		txtConst->Text = String::Format("{0:0.0}", __box(constK));
		damping = 0.0;//kg/s(�����W��)
		txtDamping->Text = String::Format("{0:0.0}", __box(damping));
		//�U��q�̏����p�x
		theta0 = 0.0;
		txtTheta->Text = String::Format("{0:0.0}", __box(theta0));
		//�����U���̐U��
		af = 0.05;
		txtAmpForced->Text = String::Format("{0:0.00}", __box(af));
		//�����U���̐U����
		ff = 1.0;
		txtFrequencyForced->Text = String::Format("{0:0.00}", __box(ff));
		//�Ԉ����\��
		txtNumThin->Text = "50";

		//Floor�̏����l
		gridWidth = 1.0;
		//�Œ�̍���
		height0 = 1.5;
		//�����ʒu
        txtLightX->Text = light.x.ToString();
        txtLightY->Text = light.y.ToString();
        txtLightZ->Text = light.z.ToString();
	}

private: System::Void Form1_Closed(System::Object *  sender, System::EventArgs *  e)
	{
 		wglMakeCurrent(hDC, NULL);
		wglDeleteContext(hRC);
	}

private: System::Void btnReady_Click(System::Object *  sender, System::EventArgs *  e)
	{
		//OpenGL����
		IntPtr ptr = spaceForm->picSpace->Handle;//�f�o�C�X�R���e�L�X�g�̃n���h��
		hWnd = (HWND)ptr.ToInt32();
		hDC = GetDC(hWnd);
		setup.initOpenGL();
		
		Image* im = Image::FromFile("../../bmp128/check1.bmp");
		Bitmap* bitmap = new Bitmap(im);

		numTarget = 1;  //�Œ��
		numParticle = 1;//������
		numSpring = 1;  //�΂�

		//������
		particle[0].kind = SPHERE;
		particle[0].texType = T_SPHERICAL;
		particle[0].texMode = T_MODULATE;
		particle[0].makeTexture(bitmap);
		particle[0].vSize = CVector(0.25, 0.25, 0.25);

		particle[0].diffuse[0] = 1.0f; //red
		particle[0].diffuse[1] = 0.9f;
		particle[0].diffuse[2] = 0.9f;

		//�΂�
		spring[0].kind = S_SPRING;

		//�Œ��
		target[0].kind = CUBE;
		target[0].texType = T_SOLID;
		target[0].texMode = T_MODULATE;
		//solid texture�̏ꍇ�͑O������texImageS���v�Z���Ă���
		if(target[0].texType == T_SOLID) target[0].calcSolidTexCube(target[0].vSize);
		target[0].vSize = CVector(0.5, 0.5, 0.1);
		target[0].vPos = CVector(0.0, 0.0, height0 + target[0].vSize.z / 2.0);
		target[0].diffuse[0] = 1.0f; //red
		target[0].diffuse[1] = 0.9f;
		target[0].diffuse[2] = 0.9f;

		//�����ݒ�
		initObject();
		numFrame = 0;
		txtNumFrame->Text = numFrame.ToString();
		flagStep = false;
		camera.position();
		display();
		t = 0;
	}

	private: System::Void initObject()
	{
		length0 = Convert::ToDouble(txtLength->Text);//�΂˂̎��R��
		limitLength = Convert::ToDouble(txtLimitLength->Text); //���E��
		disp = Convert::ToDouble(txtDisplacement->Text);
		theta0 = Convert::ToDouble(txtTheta->Text);//�����p�x
		af = Convert::ToDouble(txtAmpForced->Text);//�����U���̐U��
		ff = Convert::ToDouble(txtFrequencyForced->Text);//�����U���̊p�U����
//MessageBox(NULL,"theta0=",theta0.ToString(),MB_OK);
		realLength = length0 + disp;
		particle[0].vPos0.x = realLength * sin(theta0 * pp);
		particle[0].vPos0.y = 0.0;
		particle[0].vPos0.z = height0 - realLength * cos(theta0 * pp);
		particle[0].vPos = particle[0].vPos0;
		particle[0].vEuler.y = - theta0 ;
		particle[0].vVelocity = CVector(0.0, 0.0, 0.0);

		//�΂�
		spring[0].length = realLength;
		spring[0].vPos.x = 0.0;
		spring[0].vPos.y = 0.0;
		spring[0].vPos.z = height0;// - realLength * cos(theta0 * pp) / 2.0;
		spring[0].vEuler = CVector(0.0, 0.0, 0.0);
		spring[0].vEuler.y = 90.0 - theta0;

		//�Œ�̈ʒu
		target[0].vPos = CVector(0.0, 0.0, height0 + target[0].vSize.z / 2.0);
		//�����l
		beta = 0.0;//d��/dt(�U��p�̑��x�j
		v = 0.0;//�o�l�������̑��x
		theta = theta0 * pp;//�U��p�x
		realLength = length0 + disp; //�o�l�̑S��
		time = 0.0;
		height = height0;
	}

	private: System::Void display()
	{
	    int i;
		setup.set3DAmbient(spaceForm->picSpace);
		setup.setLight();
		flagShadow = chkShadow->Checked;

		glClear(GL_COLOR_BUFFER_BIT); //�װ�ޯ̧��ر
		glClear(GL_DEPTH_BUFFER_BIT); //���߽�ޯ̧��ر
	    //���������̂�����Ƃ��͎���2�s���K�v
	    glCullFace(GL_BACK);   //���ʂ��폜
	    glEnable(GL_CULL_FACE);//���ʍ폜��L���ɂ���

		setup.drawFloor(rdbNon, rdbCheck);//setup.h

	    if(chkWireframe->Checked == true){//ܲ԰�ڰ�����
		    glPolygonMode(GL_FRONT,GL_LINE);
		    glPolygonMode(GL_BACK,GL_POINT);
	    }
				
		//�������̂�����Ƃ��͈ȉ��̂悤�ɕs�������̂��ɂ��ׂĕ`��
		for(i = 0; i < numTarget; i++) {
			if(target[i].diffuse[3] == 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}

		for(i = 0; i < numParticle; i++) {
			if(particle[i].diffuse[3] == 1.0f) {
				particle[i].setTexture();
				particle[i].draw(false);
			}
		}

		for(i = 0; i < numSpring; i++) {
				spring[i].draw(false);
		}

		glDepthMask(GL_FALSE); //���߽�ޯ̧���������݋֎~
		glEnable(GL_BLEND);//��̧�����ިݸނ�L���ɂ���
		glBlendFunc(GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA);//�F�����W�������߂�

		//���������̂�`��
		for(i=0;i<numTarget;i++) {
			if(target[i].diffuse[3] != 1) {
				target[i].setTexture();
				target[i].draw(false);
			}
		}
		glDepthMask(GL_TRUE); //���߽�ޯ̧�̏������݂�����
		glDisable(GL_BLEND);

        setup.drawShadow();//setup.h

        glPopMatrix();
	    SwapBuffers(hDC);
    }

	private: System::Void execute()
	{
		float drawTime, lapse;
		int h1, m1, s1, ms1;
		int h2, m2, s2, ms2;
		float dt;//��������
    
		//����
		dt = Convert::ToSingle(txtDeltaTime->Text);//�b�P�ʂŎw��

		txtDrawTime->Text = S" ";
		flagStart = true;

		Cursor = Cursors::AppStarting;//�J�[�\����ύX
		DateTime tStart = DateTime::Now;//���݂̎���
		h1 = tStart.Hour;
		m1 = tStart.Minute;
		s1 = tStart.Second;
		ms1 = tStart.Millisecond;

		int numFrame0 = 0;

		double xx, zz, a;
		double omegaF;
		double numThin = Convert::ToDouble(txtConst->Text);
		float ddt = dt / (float)numThin;
		int k;
		while(true){
			omegaF = 2.0*M_PI*ff;
			for(k = 0; k < numThin; k++)
			{
				if(chkForced->Checked == true)//�����U��
					height = height0 + af * sin(omegaF * time);
				else height = height0;

				//Euler�@
				if(chkSimple->Checked == true) //�ȈՉ�@
				{
					theta = atan2( (double)particle[0].vPos.x, (height - (double)particle[0].vPos.z));
					//�����x��x����,������
					particle[0].vAccel.x = -(constK * disp * sin(theta) + damping * particle[0].vVelocity.x) / mass;// -g*sin(theta);
					particle[0].vAccel.z = (constK * disp * cos(theta) - damping * particle[0].vVelocity.z) / mass - g ;
					//���x
					particle[0].vVelocity += particle[0].vAccel * ddt;
					//�ʒu
					particle[0].vPos += particle[0].vVelocity * ddt;
					//�ʒu�C��]�p
					xx = particle[0].vPos.x ;
					zz = particle[0].vPos.z ;
					realLength = sqrt(xx * xx + (height-zz)*(height-zz));
					disp = realLength - length0; //�ψ�
				}
				else{ //������@
					a = realLength * beta * beta + g * cos(theta) - (constK * disp + damping * v)/ mass;
					if(chkForced->Checked == true)//�����U��
					{    a -= af*omegaF*omegaF * sin(omegaF*time) / mass;  }
					alpha = -(2.0 * v * beta + g * sin(theta)) / realLength - damping*beta/mass ;
					v += a * ddt;
					beta += alpha * ddt;
					disp += v * ddt ;
					theta += beta * ddt;
					realLength = length0 + disp;
					particle[0].vPos.x = realLength * sin(theta);
					particle[0].vPos.z = height - realLength * cos(theta);
					//�o�l�̍\���I����
					if(realLength < 2.0*spring[0].radius*spring[0].ratio*spring[0].num3)
					{
						realLength = 2.0*spring[0].radius*spring[0].ratio*spring[0].num3;
						particle[0].vPos.z = height - realLength * cos(theta);
						particle[0].vPos.x = realLength * sin(theta);
						disp = realLength - length0;
					}
				}
				time += ddt;
			}
			if(realLength > limitLength) {
				MessageBox::Show("���E���𒴂��� ","�o�l�̒���");
				break;
			}

			//�o�l�̍\���I����
			if(realLength < 2.0*spring[0].radius*spring[0].ratio*spring[0].num3)
			{
				realLength = 2.0*spring[0].radius*spring[0].ratio*spring[0].num3;
				particle[0].vPos.z = height - realLength * cos(theta);
				particle[0].vPos.x = realLength * sin(theta);
			}
			//�΂˂̈ʒu�E�p�x
			spring[0].length = realLength;
			spring[0].vPos.x = 0.0;
			spring[0].vPos.y = 0.0;
			spring[0].vPos.z = height;//spring�̈ʒu�͏�[
			spring[0].vEuler.y = 90.0 - theta / pp; //deg
			//���̉�]�p�i�o�l�Ɠ�����]�p��^����)
			particle[0].vEuler.y = - theta / pp; //deg
			//�Œ��
			target[0].vPos.z =  height + target[0].vSize.z / 2.0 ;
			display();
			Application::DoEvents();//���̃C�x���g��҂�
			if( flagStart == false ) break;
			numFrame++;
			numFrame0++;
			if(flagStep == true) break;
		}

		Cursor = Cursors::Default;
		DateTime tStop = DateTime::Now;
		h2 = tStop.Hour;
		m2 = tStop.Minute;
		s2 = tStop.Second;
		ms2 = tStop.Millisecond;
		//�o�ߎ���(sec)
		lapse = (float)(h2-h1) * 3600.0f + (float)(m2-m1) * 60.0f + (float)(s2-s1) + (float)(ms2-ms1) / 1000.0f;
		//1�R�}������̕`�掞��(sec)
		drawTime = lapse / (float)numFrame0;
		txtDrawTime->Text = drawTime.ToString();//�e�L�X�g�{�b�N�X�ɕ\��
		txtNumFrame->Text = numFrame.ToString();//���R�}��
	}

private: System::Void btnStart_Click(System::Object *  sender, System::EventArgs *  e)
	{
		execute();
	}

private: System::Void btnStop_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStart = false;
	}

private: System::Void btnStep_Click(System::Object *  sender, System::EventArgs *  e)
	{
		flagStep = true;
		flagStep = true;
		execute();
	}

    private: System::Void rdbCheck_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbGrid_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void rdbNon_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        display();
    }

    private: System::Void btnWidth_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
         if(e->Button == MouseButtons::Left)
                gridWidth += 0.1f;
         else
                gridWidth -= 0.1f;
         txtGridWidth->Text = gridWidth.ToString();
         display();
    }

    private: System::Void chkShadow_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
    {
        flagShadow = chkShadow->Checked;
        display();
    }

    private: System::Void btnDolly_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.dist -= 0.5f;
        else
            camera.dist += 0.5f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnZoom_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.fov -= 0.1f;
        else
            camera.fov += 0.1f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnPan_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta += 1.0f; //deg
   	    else
            camera.theta -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTumble_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.theta -= 5.0f;
        else
            camera.theta += 5.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnTilt_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 1.0f; //deg
   	    else
            camera.phi -= 1.0f;

        double pp = M_PI / 180.0;
        camera.vCenter.x = camera.vPos.x - camera.dist * (float)(cos(pp * camera.phi) * cos(pp * camera.theta));
        camera.vCenter.y = camera.vPos.y - camera.dist * (float)(cos(pp * camera.phi) * sin(pp * camera.theta));
        camera.vCenter.z = camera.vPos.z - camera.dist * (float)sin(pp * camera.phi);
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnCrane_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            camera.phi += 2.0f;
        else
            camera.phi -= 2.0f;

        camera.position();
        setup.set3DAmbient(spaceForm->picSpace);
        display();
    }

    private: System::Void btnLightX_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.x += 1.0f;
        else
            light.x -= 1.0f;
        txtLightX->Text = String::Format("{0:0.0}", __box(light.x));

        display();
    }

    private: System::Void btnLightY_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.y += 1.0f;
        else
            light.y -= 1.0f;
        txtLightY->Text = String::Format("{0:0.0}", __box(light.y));

        display();
    }

    private: System::Void btnLightZ_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
    {
        if(e->Button == MouseButtons::Left)
            light.z += 1.0f;
        else
            light.z -= 1.0f;
        txtLightZ->Text = String::Format("{0:0.0}", __box(light.z));

        display();
    }


	private: System::Void chkWireframe_CheckedChanged(System::Object *  sender, System::EventArgs *  e)
	{
        setup.initOpenGL(); //Mode�؂�ւ����ɂ͕K�v
        display();
	}

private: System::Void btnConst_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			constK += 1.0;
		else
			constK -= 1.0;
		txtConst->Text = String::Format("{0:0.0}", __box(constK));
	}

private: System::Void btnDamping_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			damping += 0.1;
		else
			damping -= 0.1;
		txtDamping->Text = String::Format("{0:0.0}", __box(damping));
	}

private: System::Void btnAmplitude_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			af += 0.05;
		else
			af -= 0.05;
		txtAmpForced->Text = String::Format("{0:0.00}", __box(af));
	}

private: System::Void tnFrequencyForced_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			ff += 0.01;
		else
			ff -= 0.01;
		txtFrequencyForced->Text = String::Format("{0:0.00}", __box(ff));
	}


private: System::Void btnMass_MouseDown(System::Object *  sender, System::Windows::Forms::MouseEventArgs *  e)
	{
		if(e->Button == MouseButtons::Left)
			mass += 0.1;
		else
			mass -= 0.1;
		txtMass->Text = String::Format("{0:0.0}", __box(mass));
	}

};
}


