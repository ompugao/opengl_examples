//noise.h

#include <stdlib.h>
#include <math.h>

//Catmull-Rom�X�v���C���ɂ����
double CmR(double p0, double p1, double p2, double p3, double t)
{
  double a = (p3 - p0) * 0.5 + (p1 - p2) * 1.5;
  double b =  p0 - 2.5 * p1 + 2.0 * p2 - 0.5 * p3;

  return ((a * t + b)* t + (p2 - p0) * 0.5) * t + p1;
}

class CNoise1
{
private:
  int L;//x�����i�q�_��
  int size;//��{��Ԃ̃e�N�Z����
  int space;//�i�q�_�ԃe�N�Z����
  float p[10];//�i�q�_�ɂ�����m�C�Y�̒l
public:
  float f[64];//��{��Ԃ̃m�C�Y�l
  CNoise1();
  CNoise1(int l, int nSize);
  double noise(int x);
};

CNoise1::CNoise1()
{
  L = 5;
  size = 64;
  space = size / (L-1);
  int i;
  for (i = 0; i < L; i++) p[i] = (double)rand() / (double)RAND_MAX - 0.5;
  p[L-1] = p[0];//�n�_�ƏI�_�𓯂��l�Ƃ��ĕs�A���_�̂Ȃ������֐��Ƃ���
  for(i = 0; i < size; i++) f[i] = noise(i);//�O�����Ċ�{��Ԃ̃m�C�Y�l�����߂�
}

CNoise1::CNoise1(int l, int nSize)
{
  L = l;//�i�q�_��(2�ׂ̂���+1�j
  size = nSize;
  space = size / (L-1);
  int i;
  for (i = 0; i < L; i++) p[i] = (double)rand() / (double)RAND_MAX - 0.5;
  p[L-1] = p[0];//�n�_�ƏI�_�𓯂��l�Ƃ��ĕs�A���_�̂Ȃ������֐��Ƃ���
  for(i = 0; i < size; i++) f[i] = noise(i);//�O�����Ċ�{��Ԃ̃m�C�Y�l�����߂�
}

double CNoise1::noise(int x)
{
  x = (int)fmod((double)x , (double)size);//��{��Ԃɓ���悤��
  int i = x / space;//�i�q�_�ԍ�
  double xx = (double)(x - (i * space));
  double t = xx / (double)space; 

  if (i == 0) {
    return CmR(p[L - 1], p[0], p[1], p[2], t);
  }
  else if (i < L - 2) {
    return CmR(p[i - 1], p[i], p[i + 1], p[i + 2], t);
  }
  else //(i = L - 2)
  {
    return CmR(p[L - 3], p[L - 2], p[L - 1], p[0], t);
  }
}

//----------------------------------------------------------------------
class CNoise2
{
private:
  int M;//y�����i�q�_��
  int size;
  int space;
  CNoise1 ns1[10] ;
public:
  float g[64][64];
  CNoise2();
  CNoise2(int l, int m, int nSize);
  double noise(int x, int y);
};

CNoise2::CNoise2()
{
  M = 5;
  size = 64;
  space = size / (M-1);
  int i, j;
  for (int i = 0; i < M; i++) ns1[i] = CNoise1(5, size);
  ns1[M-1] = ns1[0];
  for(j = 0; j < size; j++)
	for(i = 0; i < size; i++) g[i][j] = noise(i, j);//�O�����Ċ�{��Ԃ̃m�C�Y�l�����߂�
}

CNoise2::CNoise2(int l, int m, int nSize)
{
  M = m;
  size = nSize;
  space = nSize / (M-1);
  int i, j;

  for (int i = 0; i < M; i++) ns1[i] = CNoise1(l, nSize);
  ns1[M-1] = ns1[0];
  for(j = 0; j < size; j++)
	for(i = 0; i < size; i++) g[i][j] = noise(i, j);//�O�����Ċ�{��Ԃ̃m�C�Y�l�����߂�
}

double CNoise2::noise(int x, int y)
{
  y = (int)fmod((double)y , (double)size);//
  int j = y / space;//�i�q�_�ԍ�
  double yy = (double)(y - (j * space));
  double t = yy / (double)space; 

  if (j == 0) {
    return CmR(ns1[M - 1].f[x], ns1[0].f[x], ns1[1].f[x], ns1[2].f[x], t);
  }
  else if (j < M - 2) {
    return CmR(ns1[j - 1].f[x], ns1[j].f[x], ns1[j + 1].f[x], ns1[j + 2].f[x], t);
  }
  else// (j = M - 2)
  {
    return CmR(ns1[M - 3].f[x], ns1[M - 2].f[x], ns1[M - 1].f[x], ns1[0].f[x], t);
  }
}

//---------------------------------------------------------------------------------
class CNoise3
{
private:
  int N;//z�����i�q�_��
  int size;
  int space;
  CNoise2 ns2[10] ;
public:
  double max ;
  double min ;
  CNoise3();
  CNoise3(int l, int m, int n, int nSize);
  double noise(int x, int y, int z);
  double perlin(int x, int y, int z, int k);
  double turbulence(int x, int y, int z, int k);
  double sine(int x, int y, int z, int k, int x0, int y0, double a, double lambda);
  double grain(int x, int y, int z, int k, double s, double mag);
};

CNoise3::CNoise3()
{
  N = 5;
  size = 64;
  space = size / (N-1);
  for (int k = 0; k < N; k++) ns2[k] = CNoise2(5, 5, size);
  ns2[N-1] = ns2[0];
}

CNoise3::CNoise3(int l, int m, int n, int nSize)
{
  N = n;
  size = nSize;
  space = size / (N-1);

  for (int k = 0; k < N; k++) ns2[k] = CNoise2(l, m, nSize);
  ns2[N-1] = ns2[0];
}

double CNoise3::noise(int x, int y, int z)
{
  z = (int)fmod((double)z , (double)size);//
  int k = z / space;//�i�q�_�ԍ�
  double zz = (double)(z - (k * space));
  double t = zz / (double)space; 
  if (k == 0) {
    return CmR(ns2[N - 1].g[x][y], ns2[0].g[x][y], ns2[1].g[x][y], ns2[2].g[x][y], t);
  }
  else if (k < N - 2) {
    return CmR(ns2[k - 1].g[x][y], ns2[k].g[x][y], ns2[k + 1].g[x][y], ns2[k + 2].g[x][y], t);
  }
  else //(k = N - 2) 
  {
    return CmR(ns2[N - 3].g[x][y], ns2[N - 2].g[x][y], ns2[N - 1].g[x][y], ns2[0].g[x][y], t);
  }
}

double CNoise3::perlin(int x, int y, int z, int k)
{
  //k�F�R�s�[��
  int xx, yy, zz;
  int x2 = x;
  int y2 = y;
  int z2 = z;
  double v = noise(x, y, z);
  double w = 0.5;

  while (k-- > 0)
  {
	x2 *= 2; y2 *= 2; z2 *= 2;
	xx = (int)fmod((double)x2, (double)size);
	yy = (int)fmod((double)y2, (double)size);
	zz = (int)fmod((double)z2, (double)size);
    v += noise(xx, yy, zz) * w;
    w *= w;
  }
  if(v < min) min = v;
  if(v > max) max = v;
  return v;
}


double CNoise3::turbulence(int x, int y, int z, int k)
{
  int xx, yy, zz;
  int x2 = x;
  int y2 = y;
  int z2 = z;
  float v = fabs(noise(x, y, z));
  double w = 0.5;

  while (k-- > 0) {
	x2 *= 2; y2 *= 2; z2 *= 2;
	xx = (int)fmod((double)x2, (double)size);
	yy = (int)fmod((double)y2, (double)size);
	zz = (int)fmod((double)z2, (double)size);
    v += fabs(noise(xx, yy, zz)) * w;
    w *= w;
  }

  return v ;
}

double CNoise3::sine(int x, int y, int z, int k, int x0, int y0, double a, double lambda)
{
  //k:�R�s�[��
  //a:�G���̋��x
  double lam = (1.0 + 0.002* z ) * lambda;
  double d = sqrt((double)((x - x0)*(x-x0) + (y-y0)*(y-y0)));
  double v = (1.0 +  1.5*sin(2.0*M_PI*(d + a * turbulence(x, y, z, k)) / lam)) * 0.5;
  if (v < 0.0) v += 0.5;
  if(v > 1.0) v -= 0.5;
  return v;
}

double CNoise3::grain(int x, int y, int z, int k, double s, double mag)
{
  int xx = (int)((double)x * s);
  int yy = (int)((double)y * s);
  int zz = (int)((double)z * s);
  xx = (int)fmod((double)xx, (double)size);
  yy = (int)fmod((double)yy, (double)size);
  zz = (int)fmod((double)zz, (double)size);

  double a = perlin(xx, yy, zz, k) * mag;
  double v = a - floor(a);
  return v;
}

