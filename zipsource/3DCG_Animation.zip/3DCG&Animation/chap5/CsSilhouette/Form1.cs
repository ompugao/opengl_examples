﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//追加した名前空間
using System.IO;//ファイル操作に必要
using System.Drawing.Imaging;//ImageFormatに必要
namespace CsSilhouette
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

//-------------------------------------------------------------
        //変数
        //中点変位法
        int numDiv;//初期分割数
        float wid;//初期固定点間の幅
        float x0, y0;//縦軸0の左端位置
        double[] fix = new double[9];//固定点の初期設定値
        bool flagDown = false;//マウスフラグ
        //FFT
        double k1, k2, amp;
        //共通
        int nSize;//実際のサイズ
        float scale = 70;//縦軸1のピクセル数
        Color colorUp, colorLow;
        
        private void Form1_Load(object sender, EventArgs e)
        {
            //初期設定値
            numDiv = 4;
            nSize = 256;
            cmbSize.Items.Add("128");
            cmbSize.Items.Add("256");
            cmbSize.Items.Add("512");
            cmbSize.Text = Convert.ToString(nSize);
            picSpace.Width = nSize+8;
            picSpace.Height = nSize;
            this.Height = picSpace.Bottom + 40;
            
            cmbNumDiv.Items.Add("1");
            cmbNumDiv.Items.Add("2");
            cmbNumDiv.Items.Add("4");
            cmbNumDiv.Items.Add("8");
            cmbNumDiv.Text = "4";
            txtBeta.Text = "2.0";
            //分散初期値
            txtSigma0.Text = "0.5";
            //FFT
            txtK1.Text = "1";
            txtK2.Text = "127";
            txtAmp.Text = "0.3";
            //描画色
            colorUp = Color.FromArgb(150, 200, 250);
            colorLow = Color.FromArgb(200, 120, 50);
            clearPicBox();
            //基本線の左端位置(中点変位法）
            x0 = 2;
            y0 = 3 * (float)picSpace.Height / 4;
            for (int i = 0; i <= 8; i++) fix[i] = 1.0;
            drawInitLines();
        }

        private void clearPicBox()
        {
            picSpace.Image = new Bitmap(picSpace.Width, picSpace.Height);
            Graphics g = Graphics.FromImage(picSpace.Image);
            g.Clear(Color.White);
            g.Dispose();
            picSpace.Invalidate();
        }

        private void drawInitLines()
        {
            int i;

            picSpace.Image = new Bitmap(picSpace.Width, picSpace.Height);
            Graphics g = Graphics.FromImage(picSpace.Image);
            g.Clear(Color.White);
            //基線（縦軸目盛が０の横線）
            Pen pen0 = new Pen(Color.Black, 1);
            g.DrawLine(pen0, x0, y0, x0 + nSize, y0);
            //固定点
            wid = (float)nSize / (float)numDiv;//固定点間の幅
            for (i = 1; i <= numDiv; i++)
                g.DrawLine(pen0, x0 + wid*(i-1), y0 - scale*(float)fix[i-1], x0 + wid*i, y0 - scale*(float)fix[i]);
            for (i = 0; i <= numDiv; i++)
                g.DrawEllipse(new Pen(Color.Red, 1), x0 + wid * i - 2, y0 - scale * (float)fix[i] -2, 4, 4);
        }

        private void Save_BMP_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                picSpace.Image.Save(saveFileDialog1.FileName, ImageFormat.Bmp);
            }
        }

        private void Save_JPEG_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                picSpace.Image.Save(saveFileDialog1.FileName, ImageFormat.Jpeg);
            }
        }

        private void Copy_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(picSpace.Image, true);
        }

        private void cmbNumDiv_SelectedIndexChanged(object sender, EventArgs e)
        {
            numDiv = Convert.ToInt32(cmbNumDiv.Text);
            for (int i = 0; i <= numDiv; i++) fix[i] = 1.0;//初期値
            drawInitLines();
        }

        private void picSpace_MouseDown(object sender, MouseEventArgs e)
        {
            flagDown = true;
        }

        private void picSpace_MouseUp(object sender, MouseEventArgs e)
        {
            if (!flagDown) return;
            int i;
            int selectI = 999;
            for(i = 0 ; i <= numDiv; i++)
            {
                if(e.X > x0 + wid*i - 10 && e.X < x0 + wid*i + 10)
                    selectI = i;
            }
            if(selectI == 999) {flagDown = false; return;}

            if(e.Y < y0 - scale*fix[selectI]) fix[selectI] += 0.1;//上の位置
            else fix[selectI] -= 0.1;//下の位置
            drawInitLines();
        }

        private void btnStartMD_Click(object sender, EventArgs e)
        {
            //中点変位法によるfBm
            int i, j, k;
            double[] ff = new double[nSize + 1];//確定値
            double[] f = new double[nSize + 1];//確定値と新規に求める中点の値

            int numDiv = Convert.ToInt32(cmbNumDiv.Text);//初期分割数
            double sigma0 = Convert.ToDouble(txtSigma0.Text);//初期分散
            double beta = Convert.ToDouble(txtBeta.Text);
            double hurst = (beta - 1.0) / 2.0;
            Random rnd;
            if (txtRandom.Text == "")//空白なら乱数系列が変化
                rnd = new Random();
            else rnd = new Random(Convert.ToInt32(txtRandom.Text));
            //標準偏差
            double sigma = sigma0;// *Math.Sqrt(1.0 - Math.Pow(2.0, 2.0 * hurst - 2.0));

            //初期値
            for (i = 0; i <= numDiv; i++)
            {
                ff[i] = fix[i];
            }
            while (numDiv <= nSize / 2)
            {
                //sigma /= Math.Sqrt(Math.Pow(2.0, 2.0 * hurst));
                sigma /= Math.Pow(2.0, hurst);

                numDiv *= 2;//分割数
                for (j = 0; j <= numDiv; j++)
                {
                    i = j / 2;//i:前回の節点番号、j:新節点番号
                    if (i * 2 == j) //j=偶数
                    {
                        f[j] = ff[i];//確定済み
                        //MessageBox.Show("j ="+ j.ToString(), "i = "+ i.ToString());
                    }

                    else//j=奇数
                    {
                        f[j] = (ff[i] + ff[i + 1]) / 2.0;
                        f[j] += sigma * getNormalRandom(rnd);
                    }
                }
                for (k = 0; k <= numDiv; k++) ff[k] = f[k];
            }

            drawSilhouette(f);			

        }

        private double getNormalRandom(Random rnd)
        {//正規乱数
            
            double rr1 = rnd.NextDouble();
            double rr2 = rnd.NextDouble();
            double ran = Math.Sqrt(-2.0 * Math.Log(rr1)) * Math.Cos(2.0 * Math.PI * rr2);
            return ran;
         /*
            double[] rr = new double[12];
            double ran = 0.0;
            for (int i = 0; i < 12; i++) ran += rnd.NextDouble();
            ran -= 6;
            return ran;*/
        }

        private void drawSilhouette(double[] f)
        {
            int i;
            float x1, y1, x2, y2, a;
             
            picSpace.Image = new Bitmap(picSpace.Width, picSpace.Height);
            Graphics g = Graphics.FromImage(picSpace.Image);
            g.Clear(Color.White);

            Pen pen = new Pen(Color.Black, 1);
            x1 = x0;
            y1 = y0 - (float)(f[0] * scale);
            for (i = 1; i < nSize; i++)
            {
                x2 = x0 + i;
                y2 = y0 - (float)(f[i] * scale);
                g.DrawLine(pen, x1, y1, x2, y2);
                x1 = x2; y1 = y2;
            }

            Pen penUp = new Pen(colorUp);
            Pen penLow = new Pen(colorLow);
            for (i = 0; i < nSize; i++)
            {
                x2 = x0 + i;
                y2 = y0 - (float)(f[i] * scale);
                g.DrawLine(penUp, x2, 0, x2, y2);
                g.DrawLine(penLow, x2, y2, x2, picSpace.Height);
                
            }

            g.Dispose();
            picSpace.Invalidate();
        }

        private void btnInitialize_Click(object sender, EventArgs e)
        {
            numDiv = Convert.ToInt32(cmbNumDiv.Text);
            //for (int i = 0; i <= numDiv; i++) fix[i] = 1.0;
            drawInitLines();

        }

        private void cmbSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            nSize = Convert.ToInt32(cmbSize.Text);
            picSpace.Width = nSize + 8;
            if (picSpace.Right > groupBox2.Right)
                this.Width = picSpace.Right + 20;
            else
                this.Width = groupBox2.Right + 20;
            drawInitLines();
        }

        private void btnStartFFT_Click(object sender, EventArgs e)
        {
            //f[i] = ΣAsin(kωt+φ)を逆FFTによって求める
			//A^2(電力スペクトル)が1/k^βに比例すること
			//位相φは乱数で求める
			int i, k;
			double[] fr = new double[nSize];
			double[] fi = new double[nSize];
		
			double[] tblSin = new double[nSize];//sinﾃｰﾌﾞﾙ
			double[] tblCos = new double[nSize];//cosﾃｰﾌﾞﾙ
            double phi, a;
			nSize = Convert.ToInt32(cmbSize.Text);
			double[] f = new double[nSize+1];

			Random rnd;
			if(txtRandom.Text == "")
				rnd = new Random();
			else rnd = new Random(Convert.ToInt32(txtRandom.Text));

			makeTable(-1, nSize, tblSin, tblCos);

			double beta = Convert.ToDouble(txtBeta.Text);
			int k1 = Convert.ToInt32(txtK1.Text);
            if (k1 < 1) { MessageBox.Show("k1 >= 1 とすること"); return; }
			int k2 = Convert.ToInt32(txtK2.Text);
            if (k1 > k2) { MessageBox.Show("k1 <= k2 とすること"); return; }
			if(k2 >= nSize / 2) k2 = nSize / 2 - 1;
			double amp = Convert.ToDouble(txtAmp.Text);//基本波振幅

			for(i = 0; i < nSize; i++)
			{
				fr[i] = 0.0; fi[i] = 0.0;
			}
			
			for(k = k1; k <= k2; k++)
			{
				phi= 2.0 * Math.PI * rnd.NextDouble();
				a =  (amp /Math.Pow((double)k, beta/2.0)) / 2.0;
				fr[k] = a * Math.Cos(phi);
				fr[nSize-k] = fr[k];
				fi[k] = a * Math.Sin(phi);
				fi[nSize-k] = - fi[k];
			}	

			fft1d(-1, nSize, fr, fi, tblSin, tblCos);
            for (i = 0; i < nSize; i++) f[i] = fr[i] +0.5;//
			drawSilhouette(f);
        }
        //---------------------------------------------------------------------------------------
        //1次元フーリエ変換
        public void fft1d(int flag, int n, double[] fr, double[] fi, double[] tblSin, double[] tblCos)
        {
            int i, m, iw, j, l, lp, lp2, n2, k;
            double c, s, wr, wi, xa, ya;

            //Bit Reversal
            j = 0;
            for (i = 0; i < n - 1; i++)
            {
                if (i < j)
                {
                    xa = fr[i]; fr[i] = fr[j]; fr[j] = xa;
                    ya = fi[i]; fi[i] = fi[j]; fi[j] = ya;
                }
                n2 = n / 2;
                while (j >= n2) { j = j - n2; n2 = n2 / 2; }
                j += n2;
            }

            //fft
            m = 0;
            n2 = n;
            while (n2 != 1) { m++; n2 = n2 / 2; }

            for (l = 1; l <= m; l++)
            {
                lp = (short)Math.Pow(2.0, (double)l);
                lp2 = lp / 2;
                k = 0;
                for (j = 0; j < lp2; j++)
                {
                    c = tblCos[k]; s = tblSin[k];
                    k += n / lp;
                    for (i = j; i < n; i += lp)
                    {
                        iw = i + lp2;
                        //ﾊﾞﾀﾌﾗｲ演算
                        wr = fr[iw] * c - fi[iw] * s;
                        wi = fr[iw] * s + fi[iw] * c;
                        fr[iw] = fr[i] - wr; fi[iw] = fi[i] - wi;
                        fr[i] = fr[i] + wr; fi[i] = fi[i] + wi;
                    }
                }
            }
            if (flag == 1)
            {//FFT
                for (i = 0; i < n; i++)
                {
                    fr[i] /= (float)n; fi[i] /= (float)n;
                }
            }
        }
        //-----------------------------------------------------------------------------
        //sin，cosテーブル作成
        void makeTable(int flag, int n, double[] tblSin, double[] tblCos)
        {
            short i;
            double cc, arg;

            cc = -2.0 * Math.PI * flag / n;
            for (i = 0; i < n; i++)
            {
                arg = (double)i * cc;
                tblSin[i] = Math.Sin(arg);
                tblCos[i] = Math.Cos(arg);
            }
        }
    }
}