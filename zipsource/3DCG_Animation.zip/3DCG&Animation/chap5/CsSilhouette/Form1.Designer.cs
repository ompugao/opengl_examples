﻿namespace CsSilhouette
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Save_BMP = new System.Windows.Forms.ToolStripMenuItem();
            this.Save_JPEG = new System.Windows.Forms.ToolStripMenuItem();
            this.Copy = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.picSpace = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRandom = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtBeta = new System.Windows.Forms.TextBox();
            this.cmbSize = new System.Windows.Forms.ComboBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnInitialize = new System.Windows.Forms.Button();
            this.btnStartMD = new System.Windows.Forms.Button();
            this.txtSigma0 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbNumDiv = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnStartFFT = new System.Windows.Forms.Button();
            this.txtAmp = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtK2 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtK1 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSpace)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(389, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルToolStripMenuItem
            // 
            this.ファイルToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Save_BMP,
            this.Save_JPEG,
            this.Copy});
            this.ファイルToolStripMenuItem.Name = "ファイルToolStripMenuItem";
            this.ファイルToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ファイルToolStripMenuItem.Text = "ファイル";
            // 
            // Save_BMP
            // 
            this.Save_BMP.Name = "Save_BMP";
            this.Save_BMP.Size = new System.Drawing.Size(139, 22);
            this.Save_BMP.Text = "BMP保存";
            this.Save_BMP.Click += new System.EventHandler(this.Save_BMP_Click);
            // 
            // Save_JPEG
            // 
            this.Save_JPEG.Name = "Save_JPEG";
            this.Save_JPEG.Size = new System.Drawing.Size(139, 22);
            this.Save_JPEG.Text = "JPEG保存";
            this.Save_JPEG.Click += new System.EventHandler(this.Save_JPEG_Click);
            // 
            // Copy
            // 
            this.Copy.Name = "Copy";
            this.Copy.Size = new System.Drawing.Size(139, 22);
            this.Copy.Text = "コピー";
            this.Copy.Click += new System.EventHandler(this.Copy_Click);
            // 
            // picSpace
            // 
            this.picSpace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picSpace.Location = new System.Drawing.Point(6, 144);
            this.picSpace.Name = "picSpace";
            this.picSpace.Size = new System.Drawing.Size(237, 214);
            this.picSpace.TabIndex = 1;
            this.picSpace.TabStop = false;
            this.picSpace.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picSpace_MouseDown);
            this.picSpace.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picSpace_MouseUp);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "ｻｲｽﾞ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(115, 34);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 15);
            this.label2.TabIndex = 4;
            this.label2.Text = "乱数系列";
            // 
            // txtRandom
            // 
            this.txtRandom.Location = new System.Drawing.Point(180, 30);
            this.txtRandom.Name = "txtRandom";
            this.txtRandom.Size = new System.Drawing.Size(31, 22);
            this.txtRandom.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(221, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(22, 15);
            this.label4.TabIndex = 9;
            this.label4.Text = "β";
            // 
            // txtBeta
            // 
            this.txtBeta.Location = new System.Drawing.Point(244, 31);
            this.txtBeta.Name = "txtBeta";
            this.txtBeta.Size = new System.Drawing.Size(50, 22);
            this.txtBeta.TabIndex = 10;
            // 
            // cmbSize
            // 
            this.cmbSize.FormattingEnabled = true;
            this.cmbSize.Location = new System.Drawing.Point(54, 30);
            this.cmbSize.Name = "cmbSize";
            this.cmbSize.Size = new System.Drawing.Size(53, 23);
            this.cmbSize.TabIndex = 18;
            this.cmbSize.SelectedIndexChanged += new System.EventHandler(this.cmbSize_SelectedIndexChanged);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnInitialize);
            this.groupBox1.Controls.Add(this.btnStartMD);
            this.groupBox1.Controls.Add(this.txtSigma0);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cmbNumDiv);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(7, 59);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(209, 76);
            this.groupBox1.TabIndex = 19;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "中点変位法";
            // 
            // btnInitialize
            // 
            this.btnInitialize.Location = new System.Drawing.Point(117, 45);
            this.btnInitialize.Name = "btnInitialize";
            this.btnInitialize.Size = new System.Drawing.Size(83, 22);
            this.btnInitialize.TabIndex = 19;
            this.btnInitialize.Text = "初期設定";
            this.btnInitialize.UseVisualStyleBackColor = true;
            this.btnInitialize.Click += new System.EventHandler(this.btnInitialize_Click);
            // 
            // btnStartMD
            // 
            this.btnStartMD.Location = new System.Drawing.Point(117, 18);
            this.btnStartMD.Name = "btnStartMD";
            this.btnStartMD.Size = new System.Drawing.Size(83, 23);
            this.btnStartMD.TabIndex = 18;
            this.btnStartMD.Text = "StartMD";
            this.btnStartMD.UseVisualStyleBackColor = true;
            this.btnStartMD.Click += new System.EventHandler(this.btnStartMD_Click);
            // 
            // txtSigma0
            // 
            this.txtSigma0.Location = new System.Drawing.Point(60, 45);
            this.txtSigma0.Name = "txtSigma0";
            this.txtSigma0.Size = new System.Drawing.Size(51, 22);
            this.txtSigma0.TabIndex = 17;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(22, 15);
            this.label5.TabIndex = 16;
            this.label5.Text = "σ";
            // 
            // cmbNumDiv
            // 
            this.cmbNumDiv.FormattingEnabled = true;
            this.cmbNumDiv.Location = new System.Drawing.Point(60, 18);
            this.cmbNumDiv.Name = "cmbNumDiv";
            this.cmbNumDiv.Size = new System.Drawing.Size(51, 23);
            this.cmbNumDiv.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 12;
            this.label3.Text = "分割数";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnStartFFT);
            this.groupBox2.Controls.Add(this.txtAmp);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.txtK2);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtK1);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(226, 59);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(160, 75);
            this.groupBox2.TabIndex = 20;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "FFT";
            // 
            // btnStartFFT
            // 
            this.btnStartFFT.Location = new System.Drawing.Point(79, 17);
            this.btnStartFFT.Name = "btnStartFFT";
            this.btnStartFFT.Size = new System.Drawing.Size(71, 23);
            this.btnStartFFT.TabIndex = 6;
            this.btnStartFFT.Text = "StartFFT";
            this.btnStartFFT.UseVisualStyleBackColor = true;
            this.btnStartFFT.Click += new System.EventHandler(this.btnStartFFT_Click);
            // 
            // txtAmp
            // 
            this.txtAmp.Location = new System.Drawing.Point(113, 42);
            this.txtAmp.Name = "txtAmp";
            this.txtAmp.Size = new System.Drawing.Size(38, 22);
            this.txtAmp.TabIndex = 5;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(77, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 15);
            this.label8.TabIndex = 4;
            this.label8.Text = "振幅";
            // 
            // txtK2
            // 
            this.txtK2.Location = new System.Drawing.Point(33, 43);
            this.txtK2.Name = "txtK2";
            this.txtK2.Size = new System.Drawing.Size(33, 22);
            this.txtK2.TabIndex = 3;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 42);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(22, 15);
            this.label7.TabIndex = 2;
            this.label7.Text = "k2";
            // 
            // txtK1
            // 
            this.txtK1.Location = new System.Drawing.Point(32, 16);
            this.txtK1.Name = "txtK1";
            this.txtK1.Size = new System.Drawing.Size(35, 22);
            this.txtK1.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(6, 18);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(22, 15);
            this.label6.TabIndex = 0;
            this.label6.Text = "k1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(389, 370);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.cmbSize);
            this.Controls.Add(this.txtBeta);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtRandom);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.picSpace);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "シルエット(CsSilhouette)";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picSpace)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ファイルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Save_BMP;
        private System.Windows.Forms.ToolStripMenuItem Save_JPEG;
        private System.Windows.Forms.ToolStripMenuItem Copy;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.PictureBox picSpace;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRandom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtBeta;
        private System.Windows.Forms.ComboBox cmbSize;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnInitialize;
        private System.Windows.Forms.Button btnStartMD;
        private System.Windows.Forms.TextBox txtSigma0;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbNumDiv;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtK2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtK1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnStartFFT;
        private System.Windows.Forms.TextBox txtAmp;
    }
}

