using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//�ǉ��������O���
using System.IO;//�t�@�C������ɕK�v
using System.Drawing.Imaging;//ImageFormat�ɕK�v
namespace CsMandelbrot
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //�ϐ�
        int numRepeat;
        double scale;
        double posX, posY, posX0, posY0;
        int size;//Mandelbrot,Julia�W���̌v�Z�̈�
        int width0;//size / 2.0
        double initX, initY;//�����l
        bool flagDown = false;
        int x0, y0;//�s�N�`���{�b�N�X�̒��S;
        Color[] col = new Color[256];

        private void Form1_Load(object sender, EventArgs e)
        {
            numRepeat = 30;//�J��Ԃ���
            txtNumRepeat.Text = numRepeat.ToString();

            scale = 1.5;
            txtScale.Text = scale.ToString();
            //�ʒu
            posX = - 0.5;
            posY = 0.0;
            txtPosX.Text = posX.ToString();
            txtPosY.Text = posY.ToString();
            //�v�Z�̈�̉�f���i�S�́j
            size = 256;
            txtSize.Text = size.ToString();
            clearPicBox();

            //�����l
            //initX = 0.0;
            //initY = 1.0;// 0.0;
            txtInitX.Text = "0.0";
            txtInitY.Text = "0.0";

            //�z�F
            int cc;
            for (cc = 0; cc < 256; cc++)
            {
                if (cc < 5) col[cc] = Color.FromArgb(0, 0, 0);
                else if (cc < 50) col[cc] = Color.FromArgb(0, 5*cc,255- 5 * cc); 
                else if (cc < 100)  col[cc] = Color.FromArgb(5 * (cc - 50) , 0, 255 - 5 * (cc - 50)); 
                else if (cc < 150)  col[cc] = Color.FromArgb(255-5 * (cc - 100), 5 * (cc - 100), 0); 
                else if (cc < 200)  col[cc] = Color.FromArgb(5 * (cc - 150), 100, 255 - 5 * (cc - 150));
                else if (cc < 255)  col[cc] = Color.FromArgb(220 - 4 * (cc - 200), 4 * (cc - 200) +35, 0);
                else  col[cc] = Color.FromArgb(255, 255, 0); 
            }
        }

        private void clearPicBox()
        {
            picSpace.Image = new Bitmap(picSpace.Width, picSpace.Height);
            Graphics g = Graphics.FromImage(picSpace.Image);
            g.Clear(Color.White);
            g.Dispose();
            picSpace.Invalidate();
        }

        private void Save_BMP_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                picSpace.Image.Save(saveFileDialog1.FileName, ImageFormat.Bmp);
            }
        }

        private void Save_JPEG_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                picSpace.Image.Save(saveFileDialog1.FileName, ImageFormat.Jpeg);
            }
        }

        private void Copy_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(picSpace.Image, true);
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            scale = Convert.ToDouble(txtScale.Text);
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            posX = Convert.ToDouble(txtPosX.Text);
            posY = Convert.ToDouble(txtPosY.Text);
            initX = Convert.ToDouble(txtInitX.Text);
            initY = Convert.ToDouble(txtInitY.Text);

            size = Convert.ToInt32(txtSize.Text);
            picSpace.Width = size;
            picSpace.Height = size;
            if (this.Height < picSpace.Top + picSpace.Height + 40)
                this.Height = picSpace.Top + picSpace.Height + 40;

            clearPicBox();
            width0 = size / 2;
            x0 = picSpace.Width / 2;
            y0 = picSpace.Height / 2;

            Bitmap bmp = new Bitmap(picSpace.Image);

            int i, j, n, cc;

            double x, y, u, v, a, b, sum;
            Cursor = Cursors.WaitCursor;

            for (j = -width0; j < width0; j++)
            {
                b = scale * (double)j / (double)width0 + posY;
                for (i = -width0; i < width0; i++)
                {
                    a = scale * (double)i / (double)width0 + posX;
                    x = initX;//�����l
                    y = initY;
                    sum = 0.0;
                    for (n = 1; n <= numRepeat; n++)
                    {
                        u = x * x - y * y + a;//����
                        v = 2.0 * x * y + b;//����
                        x = u; y = v;
                        sum = x * x + y * y;
                        if (sum >= 10.0) break;//�I������
                    }
//if(j==0 && (i==-100 || i == 0 || i == 100)) MessageBox.Show(sum.ToString(), i.ToString());
                    cc = (int)(255.0 * (double)n / (double)numRepeat);
                    if (cc > 255) cc = 255;
                    bmp.SetPixel(x0 + i, y0 - j - 1, col[cc]);//Color.FromArgb(c, gg, bb));
                }
            }
            picSpace.Image = bmp;
            posX0 = posX;
            posY0 = posY;
            Cursor = Cursors.Default;
        }

        private void picSpace_MouseDown(object sender, MouseEventArgs e)
        {
            flagDown = true;
        }

        private void picSpace_MouseUp(object sender, MouseEventArgs e)
        {
            if (!flagDown) return;
            posX = posX0 + scale * (e.X - x0) / width0;
            txtPosX.Text = Convert.ToString(posX);
            posY = posY0 - scale * (e.Y - y0) / width0;
            txtPosY.Text = Convert.ToString(posY);
        }
      
    }
}