﻿namespace CsJulia
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtNumRepeat = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtSize = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPosX = new System.Windows.Forms.TextBox();
            this.txtPosY = new System.Windows.Forms.TextBox();
            this.picSpace = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.txtConstA = new System.Windows.Forms.TextBox();
            this.txtConstB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtScale = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.ファイルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.File_SaveBMP = new System.Windows.Forms.ToolStripMenuItem();
            this.File_SaveJPEG = new System.Windows.Forms.ToolStripMenuItem();
            this.File_Copy = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.picSpace)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(11, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "回数";
            // 
            // txtNumRepeat
            // 
            this.txtNumRepeat.Location = new System.Drawing.Point(49, 30);
            this.txtNumRepeat.Name = "txtNumRepeat";
            this.txtNumRepeat.Size = new System.Drawing.Size(44, 22);
            this.txtNumRepeat.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(106, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "ｻｲｽﾞ";
            // 
            // txtSize
            // 
            this.txtSize.Location = new System.Drawing.Point(143, 29);
            this.txtSize.Name = "txtSize";
            this.txtSize.Size = new System.Drawing.Size(44, 22);
            this.txtSize.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(37, 15);
            this.label3.TabIndex = 4;
            this.label3.Text = "定数";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 84);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 15);
            this.label4.TabIndex = 7;
            this.label4.Text = "位置";
            // 
            // txtPosX
            // 
            this.txtPosX.Location = new System.Drawing.Point(49, 80);
            this.txtPosX.Name = "txtPosX";
            this.txtPosX.Size = new System.Drawing.Size(96, 22);
            this.txtPosX.TabIndex = 8;
            // 
            // txtPosY
            // 
            this.txtPosY.Location = new System.Drawing.Point(153, 81);
            this.txtPosY.Name = "txtPosY";
            this.txtPosY.Size = new System.Drawing.Size(90, 22);
            this.txtPosY.TabIndex = 9;
            // 
            // picSpace
            // 
            this.picSpace.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.picSpace.Location = new System.Drawing.Point(20, 120);
            this.picSpace.Name = "picSpace";
            this.picSpace.Size = new System.Drawing.Size(248, 194);
            this.picSpace.TabIndex = 10;
            this.picSpace.TabStop = false;
            this.picSpace.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picSpace_MouseDown);
            this.picSpace.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picSpace_MouseUp);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(258, 60);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(60, 39);
            this.btnStart.TabIndex = 11;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // txtConstA
            // 
            this.txtConstA.Location = new System.Drawing.Point(49, 55);
            this.txtConstA.Name = "txtConstA";
            this.txtConstA.Size = new System.Drawing.Size(98, 22);
            this.txtConstA.TabIndex = 12;
            // 
            // txtConstB
            // 
            this.txtConstB.Location = new System.Drawing.Point(153, 54);
            this.txtConstB.Name = "txtConstB";
            this.txtConstB.Size = new System.Drawing.Size(90, 22);
            this.txtConstB.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(207, 35);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "ｽｹｰﾙ";
            // 
            // txtScale
            // 
            this.txtScale.Location = new System.Drawing.Point(253, 30);
            this.txtScale.Name = "txtScale";
            this.txtScale.Size = new System.Drawing.Size(58, 22);
            this.txtScale.TabIndex = 15;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(358, 24);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルToolStripMenuItem
            // 
            this.ファイルToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.File_SaveBMP,
            this.File_SaveJPEG,
            this.File_Copy});
            this.ファイルToolStripMenuItem.Name = "ファイルToolStripMenuItem";
            this.ファイルToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ファイルToolStripMenuItem.Text = "ファイル";
            // 
            // File_SaveBMP
            // 
            this.File_SaveBMP.Name = "File_SaveBMP";
            this.File_SaveBMP.Size = new System.Drawing.Size(152, 22);
            this.File_SaveBMP.Text = "BMP保存";
            this.File_SaveBMP.Click += new System.EventHandler(this.Save_BMP_Click);
            // 
            // File_SaveJPEG
            // 
            this.File_SaveJPEG.Name = "File_SaveJPEG";
            this.File_SaveJPEG.Size = new System.Drawing.Size(152, 22);
            this.File_SaveJPEG.Text = "JPEG保存";
            this.File_SaveJPEG.Click += new System.EventHandler(this.Save_JPEG_Click);
            // 
            // File_Copy
            // 
            this.File_Copy.Name = "File_Copy";
            this.File_Copy.Size = new System.Drawing.Size(152, 22);
            this.File_Copy.Text = "コピー";
            this.File_Copy.Click += new System.EventHandler(this.Copy_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(358, 330);
            this.Controls.Add(this.txtScale);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtConstB);
            this.Controls.Add(this.txtConstA);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.picSpace);
            this.Controls.Add(this.txtPosY);
            this.Controls.Add(this.txtPosX);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtSize);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNumRepeat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Julia";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.picSpace)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNumRepeat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtSize;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPosX;
        private System.Windows.Forms.TextBox txtPosY;
        private System.Windows.Forms.PictureBox picSpace;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.TextBox txtConstA;
        private System.Windows.Forms.TextBox txtConstB;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtScale;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ファイルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem File_SaveBMP;
        private System.Windows.Forms.ToolStripMenuItem File_SaveJPEG;
        private System.Windows.Forms.ToolStripMenuItem File_Copy;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
    }
}

