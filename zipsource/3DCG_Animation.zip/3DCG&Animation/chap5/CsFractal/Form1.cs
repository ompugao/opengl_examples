using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
//�ǉ��������O���
using System.IO;//�t�@�C������ɕK�v
using System.Drawing.Imaging;//ImageFormat�ɕK�v

namespace CsFractal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //�ϐ�
        int numRepeat;
        double rate;//������
        double alpha;//����p
        double factor;//��l�����̕ϓ���

        private void Form1_Load(object sender, EventArgs e)
        {
            numRepeat = 7;//�J��Ԃ���
            txtNumRepeat.Text = numRepeat.ToString();

            rate = 0.7;
            txtRate.Text = rate.ToString();
            alpha = 30.0;
            txtAlpha.Text = alpha.ToString();

            //��l�����ɂ��ϓ���
            factor = 0.0;
            txtFactor.Text = factor.ToString();

            rdbWhite.Checked = true;
            rdbBlack.Checked = false;
            //pb.Width = 64;
            //pb.Height = 64;
            clearPicBox();
         }

        private void clearPicBox()
        {
            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            if(rdbWhite.Checked) g.Clear(Color.White);
            else g.Clear(Color.Black);
            g.Dispose();
            pb.Invalidate();
        }


        private void Save_BMP_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                    pb.Image.Save(saveFileDialog1.FileName, ImageFormat.Bmp);
            }		
        }

        private void Save_JPEG_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                pb.Image.Save(saveFileDialog1.FileName, ImageFormat.Jpeg);
            }		
        }

        private void Copy_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(pb.Image, true);
        }

        private void Koch1_Click(object sender, EventArgs e)
        {
            double length0 = (double)(pb.Width - 20);//�S��
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            if (numRepeat > 10)
            {
                MessageBox.Show("numRepeat��10�ȉ��Ƃ���");
                return;
            }
            int numV = (int)Math.Pow(4.0, (double)numRepeat + 1);//�����_��
            double[] xp = new double[numV];//���_���W
            double[] yp = new double[numV];
 
            //�C�j�V�G�[�^�̗��[���W
            xp[0] = 10.0; yp[0] = 50.0;//��������(0, 0)�Ƃ����Ƃ��̍��W
            xp[1] = 10.0 + length0; yp[1] = yp[0];
            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            g.Clear(Color.White);


            koch(length0, xp, yp, g);

            g.Dispose();
            pb.Invalidate();

        }

        private void koch(double length0, double[] xp, double[] yp, Graphics g)
        {
            double len = length0 / 3.0;//�O�p�`��1�ӂ̒���
            int numSeg = 1;//�ӂ̌�
            int i, j, k;
            double alpha;

            for (i = 1; i <= numRepeat; i++)
            {
                for (j = numSeg; j >= 1; j--)//���_���W���X�V(�����ɒ���)
                {
                    xp[4 * j] = xp[j]; yp[4 * j] = yp[j];
                }
                //segment��3�������A�����ɐV�O�p�`���쐬
                for (j = 0; j < numSeg; j++)
                {
                    k = 4 * j;//�esegment�̍��[�̐V���_�ԍ�
                    xp[k + 1] = (2.0 * xp[k] + xp[k + 4]) / 3.0;
                    yp[k + 1] = (2.0 * yp[k] + yp[k + 4]) / 3.0;
                    xp[k + 3] = (xp[k] + 2.0 * xp[k + 4]) / 3.0;
                    yp[k + 3] = (yp[k] + 2.0 * yp[k + 4]) / 3.0;
                    //segment�̕Ίp
                    alpha = Math.Atan2(yp[k + 4] - yp[k], xp[k + 4] - xp[k]);
                    //�V3�p�`���_���W
                    xp[k + 2] = xp[k + 1] + len * Math.Cos(alpha + Math.PI / 3.0);
                    yp[k + 2] = yp[k + 1] + len * Math.Sin(alpha + Math.PI / 3.0);
                }
                numSeg *= 4;//�S�{��������
                //numVertex = numSeg + 1;
                len /= 3.0;
            }

            Pen pen0 = new Pen(Color.Black, 1);
            for (j = 0; j < numSeg; j++)
                g.DrawLine(pen0, (float)xp[j], (float)(pb.Height - yp[j]), (float)xp[j + 1], (float)(pb.Height - yp[j + 1]));

        }
        private void Koch2_Click(object sender, EventArgs e)
        {
            double length0 = (double)pb.Width * 0.7;// 150.0;//�S��
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            if (numRepeat > 10)
            {
                MessageBox.Show("numRepeat��10�ȉ��Ƃ���");
                return;
            }
            int numV = (int)Math.Pow(4.0, (double)numRepeat) + 1;//�����_��
            double[] xp = new double[numV];//���_���W
            double[] yp = new double[numV];
            double x0 = pb.Width / 2.0;
            double y0 = pb.Height / 2.0;
            double yy = length0 * Math.Cos(Math.PI / 3.0) / 2.0;

            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            g.Clear(Color.White);

            //�C�j�V�G�[�^�̗��[���W(��Ӂj
            xp[0] = x0 + length0 / 2.0; yp[0] = y0 - yy;// length0 / 2.0;
            xp[1] = x0 - length0 / 2.0; yp[1] = yp[0];
            koch(length0, xp, yp, g);

            //�C�j�V�G�[�^�̗��[���W(���Ӂj
            xp[0] = x0 - length0 / 2.0; yp[0] = y0 - yy;// length0 / 2.0;
            xp[1] = x0 ; yp[1] = yp[0] + length0 * Math.Sin(Math.PI / 3.0);
            koch(length0, xp, yp, g);

            //�C�j�V�G�[�^�̗��[���W(�E�Ӂj
            xp[1] = x0 + length0 / 2.0; yp[1] = y0 - yy;// length0 / 2.0;
            xp[0] = x0; yp[0] = yp[1] + length0 * Math.Sin(Math.PI / 3.0);
            koch(length0, xp, yp, g);

            g.Dispose();
            pb.Invalidate();

        }

        private void Tree1_Click(object sender, EventArgs e)
        {
            double length0 = (double)pb.Height * 0.28;//initiator
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            if (numRepeat > 10)
            {
                MessageBox.Show("numRepeat��10�ȉ��Ƃ���");
                return;
            }

            Random rnd;
            if (txtRandom.Text == "")//�󔒂Ȃ痐���n�񂪕ω�
                rnd = new Random();
            else rnd = new Random(Convert.ToInt32(txtRandom.Text));
            //�����ɂ��ϓ���
            factor = Convert.ToDouble(txtFactor.Text);

            int numB = (int)Math.Pow(2.0, (double)numRepeat);//�����_��
            double[] xp = new double[numB];//���_���W(���j
            double[] yp = new double[numB];
            double[] xq = new double[numB];//���_���W(��)
            double[] yq = new double[numB];
            double[] xx = new double[numB];//���_���W(��)
            double[] yy = new double[numB];

            double[] beta = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            double[] beta0 = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j

            rate = Convert.ToDouble(txtRate.Text) ;//�������i�}�̒����̔䗦�j
            alpha = Convert.ToDouble(txtAlpha.Text);//����p�i�Б��j
            double alpha0 = alpha * Math.PI / 180.0;//rad
            double x0 = pb.Width / 2.0;
            double y0 = 10.0;//��������(0,0)
         
            int i, j, k;
            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            if (rdbWhite.Checked) g.Clear(Color.White);
            else g.Clear(Color.Black);

            //initiator
            xp[0] = x0; yp[0] = y0;
            xq[0] = x0; yq[0] = y0 + length0;
            beta[0] = Math.PI / 2.0;//�Ίp
            double len = length0;//�}�̒���
            int numBranch = 1;//�}�̖{��(1�̐���j
            drawBranch(g, numBranch, xp, yp, xq, yq);
            //drawBranch2(1, g, numBranch, xp, yp, xq, yq);

            for(i = 1; i <= numRepeat; i++)
            {
                len *= rate;
                k = 0;
                for (j = 0; j < numBranch; j++)
                {
                    xx[j] = xq[j];
                    yy[j] = yq[j];
                    beta0[j] = beta[j];
                }
                for(j = 0; j < numBranch; j++)
                {
                    //�E���̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] - alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                    //�����̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] + alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                }
                numBranch *= 2;
                //�ꐢ�㕪�`��
                drawBranch(g, numBranch, xp, yp, xq, yq);
                //drawBranch2(i, g, numBranch, xp, yp, xq, yq);
            }
            g.Dispose();
            pb.Invalidate();

        }

        private void drawBranch(Graphics g, int numBranch, double[] xp, double[] yp, double[] xq, double[] yq)
        {
            int j;
            Pen pen0 = new Pen(Color.Black, 1);
            for (j = 0; j < numBranch; j++)
                g.DrawLine(pen0, (float)xp[j], (float)(pb.Height - yp[j]), (float)xq[j], (float)(pb.Height - yq[j]));

        }

        private void Tree1C_Click(object sender, EventArgs e)
        {
            double length0 = (double)pb.Height * 0.28;//initiator
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            if (numRepeat > 10)
            {
                MessageBox.Show("numRepeat��10�ȉ��Ƃ���");
                return;
            }

            Random rnd;
            if (txtRandom.Text == "")//�󔒂Ȃ痐���n�񂪕ω�
                rnd = new Random();
            else rnd = new Random(Convert.ToInt32(txtRandom.Text));
            //�����ɂ��ϓ���
            factor = Convert.ToDouble(txtFactor.Text);

            int numB = (int)Math.Pow(2.0, (double)numRepeat);//�����_��
            double[] xp = new double[numB];//���_���W(���j
            double[] yp = new double[numB];
            double[] xq = new double[numB];//���_���W(��)
            double[] yq = new double[numB];
            double[] xx = new double[numB];//���_���W(��)
            double[] yy = new double[numB];

            double[] beta = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            double[] beta0 = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j

            rate = Convert.ToDouble(txtRate.Text);//�������i�}�̒����̔䗦�j
            alpha = Convert.ToDouble(txtAlpha.Text);//����p�i�Б��j
            double alpha0 = alpha * Math.PI / 180.0;//rad
            double x0 = pb.Width / 2.0;
            double y0 = 10.0;//��������(0,0)

            int i, j, k;
            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            if (rdbWhite.Checked) g.Clear(Color.White);
            else g.Clear(Color.Black);

            //initiator
            xp[0] = x0; yp[0] = y0;
            xq[0] = x0; yq[0] = y0 + length0;
            beta[0] = Math.PI / 2.0;//�Ίp
            double len = length0;//�}�̒���
            int numBranch = 1;//�}�̖{��(1�̐���j
            drawBranch2(1, g, numBranch, xp, yp, xq, yq);

            for (i = 1; i <= numRepeat; i++)
            {
                len *= rate;
                k = 0;
                for (j = 0; j < numBranch; j++)
                {
                    xx[j] = xq[j];
                    yy[j] = yq[j];
                    beta0[j] = beta[j];
                }
                for (j = 0; j < numBranch; j++)
                {
                    //�E���̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] - alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                    //�����̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] + alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                }
                numBranch *= 2;
                //�ꐢ�㕪�`��
                drawBranch2(i, g, numBranch, xp, yp, xq, yq);
            }
            g.Dispose();
            pb.Invalidate();
        }

        private void Tree2_Click(object sender, EventArgs e)
        {
            double length0 = (double)pb.Height * 0.28;//initiator
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            if (numRepeat > 10)
            {
                MessageBox.Show("numRepeat��10�ȉ��Ƃ���");
                return;
            }
            int numB = (int)Math.Pow(3.0, (double)numRepeat);//�����_��
            double[] xp = new double[numB];//���_���W(���j
            double[] yp = new double[numB];
            double[] xq = new double[numB];//���_���W(��)
            double[] yq = new double[numB];
            double[] xx = new double[numB];//���_���W(��)
            double[] yy = new double[numB];

            double[] beta = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            double[] beta0 = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            rate = Convert.ToDouble(txtRate.Text);//�������i�}�̒����̔䗦�j
            double rate2 = 0.5;//�e�}�̎�}�ɑ΂��钷���䗦
            alpha = Convert.ToDouble(txtAlpha.Text);//����p�i�Б��j
            double alpha0 = alpha * Math.PI / 180.0;//rad
            double x0 = pb.Width / 2.0;
            double y0 = 10.0;//��������(0,0)

            Random rnd;
            if (txtRandom.Text == "")//�󔒂Ȃ痐���n�񂪕ω�
                rnd = new Random();
            else rnd = new Random(Convert.ToInt32(txtRandom.Text));
            factor = Convert.ToDouble(txtFactor.Text);

            int i, j, k;
            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            if (rdbWhite.Checked) g.Clear(Color.White);
            else g.Clear(Color.Black);

            //initiator
            xp[0] = x0; yp[0] = y0;
            xq[0] = x0; yq[0] = y0 + length0;
            beta[0] = Math.PI / 2.0;//�Ίp
            double len1 = length0;//�}�̒���
            double len2 = length0 * rate2;
            int numBranch = 1;//�}�̖{��(1�̐���j
            drawBranch(g, numBranch, xp, yp, xq, yq);
            //drawBranch2(1, g, numBranch, xp, yp, xq, yq);

            for (i = 1; i <= numRepeat; i++)
            {
                len1 *= rate;
                len2 = len1 * rate2;
                k = 0;
                for (j = 0; j < numBranch; j++)
                {
                    xx[j] = xq[j];
                    yy[j] = yq[j];
                    beta0[j] = beta[j];
                }
                for (j = 0; j < numBranch; j++)
                {
                    //�E���̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] - alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len2 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len2 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                    //���S�̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len1 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len1 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                    //�����̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] + alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len2 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len2 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                }
                numBranch *= 3;
                //�ꐢ�㕪�`��
                drawBranch(g, numBranch, xp, yp, xq, yq);
                //drawBranch2(i, g, numBranch, xp, yp, xq, yq);
            }
            g.Dispose();
            pb.Invalidate();
        }

        private void Tree2C_Click(object sender, EventArgs e)
        {
            //Color
            double length0 = (double)pb.Height * 0.28;//initiator
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            if (numRepeat > 10)
            {
                MessageBox.Show("numRepeat��10�ȉ��Ƃ���");
                return;
            }
            int numB = (int)Math.Pow(3.0, (double)numRepeat);//�����_��
            double[] xp = new double[numB];//���_���W(���j
            double[] yp = new double[numB];
            double[] xq = new double[numB];//���_���W(��)
            double[] yq = new double[numB];
            double[] xx = new double[numB];//���_���W(��)
            double[] yy = new double[numB];

            double[] beta = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            double[] beta0 = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            rate = Convert.ToDouble(txtRate.Text);//�������i�}�̒����̔䗦�j
            double rate2 = 0.5;//�e�}�̒����䗦
            alpha = Convert.ToDouble(txtAlpha.Text);//����p�i�Б��j
            double alpha0 = alpha * Math.PI / 180.0;//rad
            double x0 = pb.Width / 2.0;
            double y0 = 10.0;//��������(0,0)

            Random rnd;
            if (txtRandom.Text == "")//�󔒂Ȃ痐���n�񂪕ω�
                rnd = new Random();
            else rnd = new Random(Convert.ToInt32(txtRandom.Text));

            factor = Convert.ToDouble(txtFactor.Text);
            int i, j, k;
            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            if (rdbWhite.Checked) g.Clear(Color.White);
            else g.Clear(Color.Black);

            //initiator
            xp[0] = x0; yp[0] = y0;
            xq[0] = x0; yq[0] = y0 + length0;
            beta[0] = Math.PI / 2.0;//�Ίp
            double len1 = length0;//�}�̒���
            double len2 = length0 * rate2;
            int numBranch = 1;//�}�̖{��(1�̐���j
            drawBranch2(1, g, numBranch, xp, yp, xq, yq);

            for (i = 1; i <= numRepeat; i++)
            {
                len1 *= rate;
                len2 = len1 * rate2;
                k = 0;
                for (j = 0; j < numBranch; j++)
                {
                    xx[j] = xq[j];
                    yy[j] = yq[j];
                    beta0[j] = beta[j];
                }
                for (j = 0; j < numBranch; j++)
                {
                    //�E���̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] - alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len2 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len2 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                    //���S�̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len1 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len1 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                    //�����̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] + alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len2 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len2 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                }
                numBranch *= 3;
                //�ꐢ�㕪�`��
                drawBranch2(i, g, numBranch, xp, yp, xq, yq);
            }
            g.Dispose();
            pb.Invalidate();

        }

        private void drawBranch2(int n, Graphics g, int numBranch, double[] xp, double[] yp, double[] xq, double[] yq)
        {
            //n=numRepeat
            int j;
            Pen pen0;

            float dia = 4.0f - (float)n;//���A�}�̒��a
            if(dia <= 1) dia = 1;
            if (n < 4) pen0 = new Pen(Color.Brown, dia);
            else if (n < 5) pen0 = new Pen(Color.DarkGreen, dia);
            else pen0 = new Pen(Color.Green, dia);
     //       else pen0 = new Pen(Color.LightPink);

            for (j = 0; j < numBranch; j++)
                g.DrawLine(pen0, (float)xp[j], (float)(pb.Height - yp[j]), (float)xq[j], (float)(pb.Height - yq[j]));

        }

        private void Tree3C_Click(object sender, EventArgs e)
        {
            double length0 = (double)pb.Height * 0.28;//initiator
            numRepeat = Convert.ToInt32(txtNumRepeat.Text);
            if (numRepeat > 10)
            {
                MessageBox.Show("numRepeat��10�ȉ��Ƃ���");
                return;
            }
            int numB = (int)Math.Pow(3.0, (double)numRepeat);//�����_��
            double[] xp = new double[numB];//���_���W(���j
            double[] yp = new double[numB];
            double[] xq = new double[numB];//���_���W(��)
            double[] yq = new double[numB];
            double[] xx = new double[numB];//���_���W(��)
            double[] yy = new double[numB];

            double[] beta = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            double[] beta0 = new double[numB];//�}�̕Ίp�i�����ʂ���̊p�x�j
            rate = Convert.ToDouble(txtRate.Text);//�������i�}�̒����̔䗦�j
            double rate2 = 0.5;//�e�}�̒����䗦
            alpha = Convert.ToDouble(txtAlpha.Text);//����p�i�Б��j
            double alpha0 = alpha * Math.PI / 180.0;//rad
            double x0 = pb.Width / 2.0;
            double y0 = 10.0;//��������(0,0)

            Random rnd;
            if (txtRandom.Text == "")//�󔒂Ȃ痐���n�񂪕ω�
                rnd = new Random();
            else rnd = new Random(Convert.ToInt32(txtRandom.Text));

            factor = Convert.ToDouble(txtFactor.Text);

            int i, j, k;
            pb.Image = new Bitmap(pb.Width, pb.Height);
            Graphics g = Graphics.FromImage(pb.Image);
            if (rdbWhite.Checked) g.Clear(Color.White);
            else g.Clear(Color.Black);

            //initiator
            xp[0] = x0; yp[0] = y0;
            xq[0] = x0; yq[0] = y0 + length0;
            beta[0] = Math.PI / 2.0;//�Ίp
            double len1 = length0;//�}�̒���
            double len2 = length0 * rate2;
            int numBranch = 1;//�}�̖{��(1�̐���j
            drawBranch3(1, g, numBranch, xp, yp, xq, yq);

            for (i = 1; i <= numRepeat; i++)
            {
                len1 *= rate;
                len2 = len1 * rate2;
                k = 0;
                for (j = 0; j < numBranch; j++)
                {
                    xx[j] = xq[j];
                    yy[j] = yq[j];
                    beta0[j] = beta[j];
                }
                for (j = 0; j < numBranch; j++)
                {
                    //�E���̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] - alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor); ;
                    xq[k] = xp[k] + len2 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor); ;
                    yq[k] = yp[k] + len2 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor); ;
                    k++;
                    //���S�̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len1 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len1 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                    //�����̐V�}
                    xp[k] = xx[j]; yp[k] = yy[j];
                    beta[k] = beta0[j] + alpha0 * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    xq[k] = xp[k] + len2 * Math.Cos(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    yq[k] = yp[k] + len2 * Math.Sin(beta[k]) * (1.0 + (rnd.NextDouble() - 0.5) * factor);
                    k++;
                }
                numBranch *= 3;
                //�ꐢ�㕪�`��
                drawBranch3(i, g, numBranch, xp, yp, xq, yq);
            }
            g.Dispose();
            pb.Invalidate();
        }


        private void drawBranch3(int n, Graphics g, int numBranch, double[] xp, double[] yp, double[] xq, double[] yq)
        {
            int j;
            Pen pen0;

            float dia = 4.0f - (float)n;
            if (dia <= 1) dia = 1;
            if (n < 4) pen0 = new Pen(Color.Brown, dia);
            else if (n < 5) pen0 = new Pen(Color.DarkGreen, dia);
            else pen0 = new Pen(Color.Green, dia);

            for (j = 0; j < numBranch; j++)
            {
                if (n < 6) g.DrawLine(pen0, (float)xp[j], (float)(pb.Height - yp[j]), (float)xq[j], (float)(pb.Height - yq[j]));
                else g.FillRectangle(new SolidBrush(Color.LightPink), (float)xp[j], (float)(pb.Height - yp[j]), 3, 3);
            }
        }

    }
}