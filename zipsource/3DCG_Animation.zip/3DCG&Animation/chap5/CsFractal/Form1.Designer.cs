﻿namespace CsFractal
{
    partial class Form1
    {
        /// <summary>
        /// 必要なデザイナ変数です。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 使用中のリソースをすべてクリーンアップします。
        /// </summary>
        /// <param name="disposing">マネージ リソースが破棄される場合 true、破棄されない場合は false です。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows フォーム デザイナで生成されたコード

        /// <summary>
        /// デザイナ サポートに必要なメソッドです。このメソッドの内容を
        /// コード エディタで変更しないでください。
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ファイルToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Save_BMP = new System.Windows.Forms.ToolStripMenuItem();
            this.Save_JPEG = new System.Windows.Forms.ToolStripMenuItem();
            this.Copy = new System.Windows.Forms.ToolStripMenuItem();
            this.マンデルブロToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.コッホToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Koch1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Koch2 = new System.Windows.Forms.ToolStripMenuItem();
            this.樹木ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Tree1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tree1C = new System.Windows.Forms.ToolStripMenuItem();
            this.Tree2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Tree2C = new System.Windows.Forms.ToolStripMenuItem();
            this.Tree3C = new System.Windows.Forms.ToolStripMenuItem();
            this.Mandelbrot1 = new System.Windows.Forms.ToolStripMenuItem();
            this.Mandelbrot2 = new System.Windows.Forms.ToolStripMenuItem();
            this.Julia1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.pb = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNumRepeat = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rdbBlack = new System.Windows.Forms.RadioButton();
            this.rdbWhite = new System.Windows.Forms.RadioButton();
            this.label6 = new System.Windows.Forms.Label();
            this.txtRandom = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtFactor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtRate = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtAlpha = new System.Windows.Forms.TextBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ファイルToolStripMenuItem,
            this.マンデルブロToolStripMenuItem,
            this.コッホToolStripMenuItem,
            this.樹木ToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(293, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ファイルToolStripMenuItem
            // 
            this.ファイルToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Save_BMP,
            this.Save_JPEG,
            this.Copy});
            this.ファイルToolStripMenuItem.Name = "ファイルToolStripMenuItem";
            this.ファイルToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.ファイルToolStripMenuItem.Text = "ファイル";
            // 
            // Save_BMP
            // 
            this.Save_BMP.Name = "Save_BMP";
            this.Save_BMP.Size = new System.Drawing.Size(152, 22);
            this.Save_BMP.Text = "BMP保存";
            this.Save_BMP.Click += new System.EventHandler(this.Save_BMP_Click);
            // 
            // Save_JPEG
            // 
            this.Save_JPEG.Name = "Save_JPEG";
            this.Save_JPEG.Size = new System.Drawing.Size(152, 22);
            this.Save_JPEG.Text = "JPEG保存";
            this.Save_JPEG.Click += new System.EventHandler(this.Save_JPEG_Click);
            // 
            // Copy
            // 
            this.Copy.Name = "Copy";
            this.Copy.Size = new System.Drawing.Size(152, 22);
            this.Copy.Text = "コピー";
            this.Copy.Click += new System.EventHandler(this.Copy_Click);
            // 
            // マンデルブロToolStripMenuItem
            // 
            this.マンデルブロToolStripMenuItem.Name = "マンデルブロToolStripMenuItem";
            this.マンデルブロToolStripMenuItem.Size = new System.Drawing.Size(12, 20);
            // 
            // コッホToolStripMenuItem
            // 
            this.コッホToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Koch1,
            this.Koch2});
            this.コッホToolStripMenuItem.Name = "コッホToolStripMenuItem";
            this.コッホToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.コッホToolStripMenuItem.Text = "コッホ";
            // 
            // Koch1
            // 
            this.Koch1.Name = "Koch1";
            this.Koch1.Size = new System.Drawing.Size(152, 22);
            this.Koch1.Text = "コッホ1";
            this.Koch1.Click += new System.EventHandler(this.Koch1_Click);
            // 
            // Koch2
            // 
            this.Koch2.Name = "Koch2";
            this.Koch2.Size = new System.Drawing.Size(152, 22);
            this.Koch2.Text = "コッホ2";
            this.Koch2.Click += new System.EventHandler(this.Koch2_Click);
            // 
            // 樹木ToolStripMenuItem
            // 
            this.樹木ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Tree1,
            this.Tree1C,
            this.Tree2,
            this.Tree2C,
            this.Tree3C});
            this.樹木ToolStripMenuItem.Name = "樹木ToolStripMenuItem";
            this.樹木ToolStripMenuItem.Size = new System.Drawing.Size(49, 20);
            this.樹木ToolStripMenuItem.Text = "樹木";
            // 
            // Tree1
            // 
            this.Tree1.Name = "Tree1";
            this.Tree1.Size = new System.Drawing.Size(155, 22);
            this.Tree1.Text = "樹木1";
            this.Tree1.Click += new System.EventHandler(this.Tree1_Click);
            // 
            // Tree1C
            // 
            this.Tree1C.Name = "Tree1C";
            this.Tree1C.Size = new System.Drawing.Size(155, 22);
            this.Tree1C.Text = "樹木1(カラー)";
            this.Tree1C.Click += new System.EventHandler(this.Tree1C_Click);
            // 
            // Tree2
            // 
            this.Tree2.Name = "Tree2";
            this.Tree2.Size = new System.Drawing.Size(155, 22);
            this.Tree2.Text = "樹木2";
            this.Tree2.Click += new System.EventHandler(this.Tree2_Click);
            // 
            // Tree2C
            // 
            this.Tree2C.Name = "Tree2C";
            this.Tree2C.Size = new System.Drawing.Size(155, 22);
            this.Tree2C.Text = "樹木2(カラー)";
            this.Tree2C.Click += new System.EventHandler(this.Tree2C_Click);
            // 
            // Tree3C
            // 
            this.Tree3C.Name = "Tree3C";
            this.Tree3C.Size = new System.Drawing.Size(155, 22);
            this.Tree3C.Text = "樹木3(カラー)";
            this.Tree3C.Click += new System.EventHandler(this.Tree3C_Click);
            // 
            // Mandelbrot1
            // 
            this.Mandelbrot1.Name = "Mandelbrot1";
            this.Mandelbrot1.Size = new System.Drawing.Size(32, 19);
            // 
            // Mandelbrot2
            // 
            this.Mandelbrot2.Name = "Mandelbrot2";
            this.Mandelbrot2.Size = new System.Drawing.Size(32, 19);
            // 
            // Julia1
            // 
            this.Julia1.Name = "Julia1";
            this.Julia1.Size = new System.Drawing.Size(32, 19);
            // 
            // pb
            // 
            this.pb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pb.Location = new System.Drawing.Point(43, 114);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(191, 185);
            this.pb.TabIndex = 1;
            this.pb.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 34);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 15);
            this.label1.TabIndex = 2;
            this.label1.Text = "回数";
            // 
            // txtNumRepeat
            // 
            this.txtNumRepeat.Location = new System.Drawing.Point(48, 31);
            this.txtNumRepeat.Name = "txtNumRepeat";
            this.txtNumRepeat.Size = new System.Drawing.Size(52, 22);
            this.txtNumRepeat.TabIndex = 3;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rdbBlack);
            this.groupBox1.Controls.Add(this.rdbWhite);
            this.groupBox1.Location = new System.Drawing.Point(224, 31);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(62, 61);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "背景";
            // 
            // rdbBlack
            // 
            this.rdbBlack.AutoSize = true;
            this.rdbBlack.Location = new System.Drawing.Point(6, 40);
            this.rdbBlack.Name = "rdbBlack";
            this.rdbBlack.Size = new System.Drawing.Size(40, 19);
            this.rdbBlack.TabIndex = 1;
            this.rdbBlack.TabStop = true;
            this.rdbBlack.Text = "黒";
            this.rdbBlack.UseVisualStyleBackColor = true;
            // 
            // rdbWhite
            // 
            this.rdbWhite.AutoSize = true;
            this.rdbWhite.Location = new System.Drawing.Point(6, 15);
            this.rdbWhite.Name = "rdbWhite";
            this.rdbWhite.Size = new System.Drawing.Size(40, 19);
            this.rdbWhite.TabIndex = 0;
            this.rdbWhite.TabStop = true;
            this.rdbWhite.Text = "白";
            this.rdbWhite.UseVisualStyleBackColor = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 91);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 15);
            this.label6.TabIndex = 15;
            this.label6.Text = "乱数系列";
            // 
            // txtRandom
            // 
            this.txtRandom.Location = new System.Drawing.Point(69, 86);
            this.txtRandom.Name = "txtRandom";
            this.txtRandom.Size = new System.Drawing.Size(31, 22);
            this.txtRandom.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(109, 91);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(52, 15);
            this.label7.TabIndex = 17;
            this.label7.Text = "変動率";
            // 
            // txtFactor
            // 
            this.txtFactor.Location = new System.Drawing.Point(158, 86);
            this.txtFactor.Name = "txtFactor";
            this.txtFactor.Size = new System.Drawing.Size(53, 22);
            this.txtFactor.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 15);
            this.label2.TabIndex = 19;
            this.label2.Text = "成長率";
            // 
            // txtRate
            // 
            this.txtRate.Location = new System.Drawing.Point(55, 58);
            this.txtRate.Name = "txtRate";
            this.txtRate.Size = new System.Drawing.Size(53, 22);
            this.txtRate.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(111, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(52, 15);
            this.label3.TabIndex = 21;
            this.label3.Text = "分岐角";
            // 
            // txtAlpha
            // 
            this.txtAlpha.Location = new System.Drawing.Point(158, 58);
            this.txtAlpha.Name = "txtAlpha";
            this.txtAlpha.Size = new System.Drawing.Size(41, 22);
            this.txtAlpha.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(293, 308);
            this.Controls.Add(this.txtAlpha);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtRate);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtFactor);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtRandom);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.txtNumRepeat);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pb);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "CsFractal(フラクタル）";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ファイルToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Save_BMP;
        private System.Windows.Forms.ToolStripMenuItem Save_JPEG;
        private System.Windows.Forms.ToolStripMenuItem Copy;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNumRepeat;
        private System.Windows.Forms.ToolStripMenuItem マンデルブロToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Mandelbrot1;
        private System.Windows.Forms.ToolStripMenuItem Mandelbrot2;
        private System.Windows.Forms.ToolStripMenuItem Julia1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rdbBlack;
        private System.Windows.Forms.RadioButton rdbWhite;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtRandom;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtFactor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtRate;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtAlpha;
        private System.Windows.Forms.ToolStripMenuItem コッホToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Koch1;
        private System.Windows.Forms.ToolStripMenuItem Koch2;
        private System.Windows.Forms.ToolStripMenuItem 樹木ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Tree1;
        private System.Windows.Forms.ToolStripMenuItem Tree1C;
        private System.Windows.Forms.ToolStripMenuItem Tree2;
        private System.Windows.Forms.ToolStripMenuItem Tree2C;
        private System.Windows.Forms.ToolStripMenuItem Tree3C;
    }
}

