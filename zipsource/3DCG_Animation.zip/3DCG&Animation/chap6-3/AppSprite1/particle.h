//particle.h
#include <stdlib.h>
#include <math.h>
#define NUM_PARTICLE 2500

int num0 = 10;//��x�ɕ��o���闱�q��
float g = 9.8;//�d�͉����x
float drag = 0.001;//��C��R
float e = 0.5;//���˕Ԃ�W��
float radius = 0.1;

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

class CParticle 
{
public:
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  CParticle();
  ~CParticle() {};
  void create();
  void update(float dt);
  void show(bool flagShadow);
};

CParticle::CParticle()
{
  vPosition = CVector(0.0, radius, 0.0);
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::create()
{
  vPosition = CVector(0.0, radius, 0.0);
  vVelocity = CVector(0.0, 8.0, 0.0);
  vVelocity.x = getRandom(-1.0, 1.0);
  vVelocity.z = getRandom(-1.0, 1.0);
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;//�d�͉����x�ƊO�͂͏�ɑ���
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
  if(vPosition.y < radius)
  {
		vPosition.y = + radius;
		vVelocity.y = - e * vVelocity.y;
  }
}

void CParticle::show(bool flagShadow)
{
  float diffuse[] = { 0.9f, 0.5f, 0.2f, 1.0f};
  float ambient[] = { 0.4f, 0.2f, 0.1f, 1.0f};
  //�e�̃}�e���A��
  float shadowDiffuse[] = {0.2f,0.2f,0.2f,0.5f};//�e�̊g�U��

  if(flagShadow) 
  {
	  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,shadowDiffuse);
  }
  else
  {	
	  glMaterialfv(GL_FRONT,GL_DIFFUSE,diffuse);
	  glMaterialfv(GL_FRONT,GL_AMBIENT,ambient);
  }

  float pointSize = 15.0;
  if(!flagShadow) glPointSize(pointSize);
  else glPointSize(pointSize/2.0);
  
  glBegin(GL_POINTS);
  glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}






