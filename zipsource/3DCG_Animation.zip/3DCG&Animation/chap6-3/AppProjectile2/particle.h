//particle.h
#define NUM_PARTICLE 250

float g = 9.8;//�d�͉����x
float drag = 0.1;//��C��R
float e = 0.5;//���˕Ԃ�W��
float radius = 0.1;

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

class CParticle {
 public:
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  CParticle();
  ~CParticle() {};
  void update(float dt);
  void show(bool flagShadow);
};

CParticle::CParticle()
{
  vPosition = CVector(0.0, radius, 0.0);
  vVelocity = CVector(0.0, 6.0, 0.0);
  vVelocity.x = getRandom(-1.0, 1.0);
  vVelocity.z = getRandom(-1.0, 1.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
  if(vPosition.y < radius)
  {
		vPosition.y = radius;
		vVelocity.y = - e * vVelocity.y;
  }
}

void CParticle::show(bool flagShadow)
{
  static float diffuse[] = { 0.9f, 0.1f, 0.0f, 1.0f};
  static float ambient[] = { 0.5f, 0.05f, 0.0f, 1.0f};
  static float specular[]= { 1.0f, 1.0f, 1.0f, 1.0f};
  //�e�̃}�e���A��
  static float shadowDiffuse[] = {0.2f,0.2f,0.2f,0.5f};//�e�̊g�U��

  if(flagShadow) 
  {
	  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,shadowDiffuse);
  }
  else
  {	
	  glMaterialfv(GL_FRONT,GL_DIFFUSE,diffuse);
	  glMaterialfv(GL_FRONT,GL_AMBIENT,ambient);
	  glMaterialfv(GL_FRONT,GL_SPECULAR,specular);
	  glMaterialf(GL_FRONT,GL_SHININESS,100);
  }

  glPushMatrix();
  glTranslatef(vPosition.x, vPosition.y, vPosition.z);
  drawSphere(radius, 8, 8);
  glPopMatrix();
}
