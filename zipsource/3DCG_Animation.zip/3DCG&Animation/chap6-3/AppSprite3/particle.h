//particle.h
#include <stdlib.h>
#include <math.h>
#define NUM_PARTICLE 100

int mode = 0;
float g = 0.0;//9.8;//�d�͉����x
float drag = 0.3;//��C��R

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

CVector getRandomVector( )
{
  //�傫��1�̕��ˏ�Ɉ�l�ɍL����x�N�g��
  CVector vVector;

  vVector.y = getRandom( -1.0f, 1.0f );
  float rad = (float)sqrt(1.0 - vVector.y * vVector.y);
  float theta = getRandom( -M_PI, M_PI );
  vVector.z = (float)cos(theta) * rad;
  vVector.x = (float)sin(theta) * rad;
  return vVector;
}

class CParticle 
{
public:
  float red, green, blue;
  float pointSize;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  CParticle();
  ~CParticle() {};
  void create();
  void update(float dt);
  void show(float elapseTime);
};

CParticle::CParticle()
{
  red = getRandom(0.0, 1.0);
  green = getRandom(0.0, 1.0);
  blue = getRandom(0.0, 1.0);
  pointSize = getRandom(1.0, 20.0);
  vPosition = CVector(0.0, 0.0, 0.0);
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, 0.0, 0.0);
}

void CParticle::create()
{
  red = getRandom(0.0, 1.0);
  green = getRandom(0.0, 1.0);
  blue = getRandom(0.0, 1.0); 
  pointSize = getRandom(1.0, 200.0);
  vPosition = CVector(0.0, 0.0, 0.0 );
  vVelocity = getRandomVector() * getRandom(1.0, 10.0);
}

void CParticle::update(float dt)
{
  CVector accel = CVector(0.0, 0.0, 0.0);
  if(mode >= 1)
  {
		float dist2 =  vPosition.x * vPosition.y + vPosition.y * vPosition.y + vPosition.z * vPosition.z;
		if(dist2 > 30.0) 
		{
			accel = 5.0*pointSize * vPosition.normalize2() / dist2;
			accel.reverse();
		}
  }
  accel -= drag * vVelocity;//���x�ɔ�Ⴗ���R��
  if(mode < 2) vVelocity += accel * dt;
  else//�ʒu�x�N�g����y���ɒ������鑬�x��^����
		vVelocity += accel * dt + (CVector(0.0, 1.0, 0.0) ^ vPosition.normalize2()) * 0.0002;//^�͊O��

  vPosition += vVelocity * dt;
}

void CParticle::show(float elapseTime)
{
  glColor4f(red, green, blue, 1.0);
  glPointSize(pointSize);
  glBegin(GL_POINTS);
  glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}
