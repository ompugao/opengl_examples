//particle.h
#define NUM_PARTICLE 800
#define NUM_LINE 10

float g = 9.8;//�d�͉����x
float drag = 2.5;//��C��R
float radius = 0.1;
float hFire = 15.0;
int spaceFrame = 50;//�����f�[�^�����߂�t���[���Ԋu
int mode = 0;

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

float getNormalRandom(float mean, float sigma)
{//���K����
  float ran = 0.0;
  for(int i=0; i < 12; i++)
	{
		ran += (float)rand() / (float)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + ran;
}

CVector getRandomVector( )
{//�傫��1�ŕ��ˏ�Ɉ�l�ɍL����x�N�g��
  CVector vVector;

  vVector.y = getRandom( -1.0f, 1.0f );
  float radius = (float)sqrt(1.0 - vVector.y * vVector.y);
  float theta = getRandom( -M_PI, M_PI );
  vVector.z = (float)cos(theta) * radius;
  vVector.x = (float)sin(theta) * radius;
  return vVector;
}

class CParticle 
{
public:
  float red, green, blue;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  CVector vPositionL[NUM_LINE];
  float pointSize;
  float lineWidth;

  CParticle();
  ~CParticle() {};
  void update(float dt);
  void create();
  void show(float elapsTime);
  void drawLines(int lineCount, float elapseTime);
};

CParticle::CParticle()
{
  vPosition = CVector(0.0, radius, 0.0);
  vVelocity = CVector(0.0, 8.0, 0.0);
  vVelocity.x = 0.0;//getRandom(-1.0, 1.0);
}

void CParticle::create()
{
  red = getRandom(0.0, 1.0);
  green = getRandom(0.0, 1.0);
  blue = getRandom(0.0, 1.0);
 
  pointSize = getNormalRandom(10.0, 2.0);//1.0, 40.0);
  lineWidth = 1.0;
  if(mode <= 2) vPosition = CVector(0.0, hFire, 0.0);
  else if(mode == 3)
  {
		if(getRandom(0.0, 1.0) < 0.5) vPosition = CVector(-8.0, hFire, 0.0);
		else vPosition = CVector(8.0, hFire, 0.0);
  }
  vVelocity = getRandomVector() * getNormalRandom(20.0, 0.5);//19.0, 20.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
}

void CParticle::show(float elapseTime)
{
  float a = 1.0;
  if(elapseTime > 2.0) a = 1.0 / (1.0 + (elapseTime-2.0)*0.5);//���X�ɈÂ�����
  glPointSize(pointSize);
  glColor4f(red*a, green*a, blue*a, 1.0);
  glBegin(GL_POINTS);
  glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}

void CParticle::drawLines(int lineCount, float elapseTime)
{
  float a;
  if(elapseTime < 2.0) a = 1.0;
  else a = 1.0 / (1.0 + (elapseTime-2.0)*0.5);//���X�ɈÂ�����

  glLineWidth(lineWidth);
  glColor4f(red*a, green*a, blue*a, 1.0);

  double fm;
  for(int i = 0; i < lineCount-1; i++) 
  {	
		if(mode >= 2)
		{
			fm = fmod((double)i, 3.0);
			if( fm == 0.0){ red = 1.0; green = 0.0; blue = 0.0; }
			else if( fm == 1.0){ red = 0.0; green = 1.0; blue = 0.0; }
			else { red = 0.0; green = 0.0; blue = 1.0; }
			glColor4f(red*a, green*a, blue*a, 1.0);
		}
		glBegin(GL_LINES);
			glVertex3f(vPositionL[i].x, vPositionL[i].y, vPositionL[i].z); 
			glVertex3f(vPositionL[i+1].x, vPositionL[i+1].y, vPositionL[i+1].z); 
		glEnd();
  }
}

