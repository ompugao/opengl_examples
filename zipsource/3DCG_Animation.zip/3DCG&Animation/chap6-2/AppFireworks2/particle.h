//particle.h
#define NUM_PARTICLE 5000
#define NUM_LINE 10

float g = 1.0;//9.8;//�d�͉����x
float drag = 1.0;//��C��R
float radius = 0.1;
float hFire = 1.0;
float e = 0.0;
int spaceFrame = 100;//�����f�[�^�����߂�t���[���Ԋu
int mode = 0;

int num0 = 10;
int count = 0;

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

float getNormalRandom(float mean, float sigma)
{//���K����
  double ran = 0.0;
  for(int i=0; i < 12; i++)
	{
		ran += (double)rand() / (double)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + (float)ran;
}

CVector getRandomVector(int type)
{//�傫��1�ŕ��ˏ�Ɉ�l�ɍL����x�N�g��
  CVector vVector;
  if(type == 0) vVector.y = getRandom( -1.0f, 1.0f );//���S��
  else vVector.y = getRandom( 0.0f, 1.0f );//�㔼������

  float radius = (float)sqrt(1.0 - vVector.y * vVector.y);
  float theta = getRandom( -M_PI, M_PI );
  vVector.z = (float)cosf(theta) * radius;
  vVector.x = (float)sinf(theta) * radius;
  return vVector;
}

class CParticle 
{
public:
  float red, green, blue;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  CVector vPositionL[NUM_LINE];
  float pointSize;
  float lineWidth;

  CParticle();
  ~CParticle() {};
  void update(float dt);
  void create();
  void show(float elapsTime);
  void drawLines(int lineCount, float elapseTime);
};

CParticle::CParticle()
{
  red = getRandom(0.0, 1.0);
  green = getRandom(0.0, 1.0);
  blue = getRandom(0.0, 1.0);
 
  pointSize = getNormalRandom(10.0, 2.0);
  lineWidth = 1.0;
  vPosition = CVector(0.0, hFire, 0.0);
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::create()
{
  red = getRandom(0.0, 1.0);
  green = getRandom(0.0, 1.0);
  blue = getRandom(0.0, 1.0);
  pointSize = 10.0;
  lineWidth = 1.0;
  if(mode < 2)
  {
		vPosition = CVector(0.0, hFire, 0.0);
		vVelocity = getRandomVector(1) * getNormalRandom(8.0, 2.0);
		vVelocity.y *= 3.0;
  }
  else if(mode == 2)
  {
		vPosition = CVector(0.0, 15.0, 0.0);
		vPosition.x = getRandom(-10.0, 10.0);
		vVelocity = CVector(0.0, getRandom(-15.0, 0.0), 0.0);
  }
  else
  {
		vPosition = CVector(0.0, 0.5, -5.0);
		vPosition.x = getRandom(-10.0, 10.0);
		vVelocity = CVector(0.0, getRandom(30.0, 0.0), 0.0);
  }
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
 	  
  if(vPosition.y < radius) 
  {
		vPosition.y = + radius;
		vVelocity.y = - e * vVelocity.y;
  }
}

void CParticle::show(float elapseTime)
{
  glPointSize(pointSize);
  glColor4f(red, green, blue, 1.0);
  glBegin(GL_POINTS);
  glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}


void CParticle::drawLines(int lineCount, float elapseTime)
{
  glLineWidth(lineWidth);
  glColor4f(red, green, blue, 1.0);

  for(int i = 0; i < lineCount-1; i++) 
  {	
		glBegin(GL_LINES);
			glVertex3f(vPositionL[i].x, vPositionL[i].y, vPositionL[i].z); 
			glVertex3f(vPositionL[i+1].x, vPositionL[i+1].y, vPositionL[i+1].z); 
		glEnd();
  }  
}





