
#define nMesh 50//�ő啪�����i���ӓ����j
#define NUM_WAVE  20//�S�g����
int numWave;//�r���̔g����
float period = 0.2;
float lambda = 0.5;
float amp0 = 0.05;
float sizeX = 8.0;
float sizeY = 8.0;
float meshX = sizeX / (float)nMesh;
float meshY = sizeY / (float)nMesh;
float sX[NUM_WAVE], sY[NUM_WAVE];//�~�`�g�̒��S
float timeOccur[NUM_WAVE];
float data[(nMesh+1)*(nMesh+1)];//Wave�̍����f�[�^
int interval = 100;//�g�𔭐������闱�q�̊Ԋu

void drawWave()
{
  static float diffuse[] = { 0.4f, 0.6f, 0.9f, 1.0f} ;
  static float ambient[] = { 0.1f, 0.2f, 0.3f, 1.0f};
  static float specular[]= { 1.0f, 1.0f, 1.0f, 1.0f};

  glMaterialfv(GL_FRONT,GL_DIFFUSE,diffuse);
  glMaterialfv(GL_FRONT,GL_AMBIENT,ambient);
  glMaterialfv(GL_FRONT,GL_SPECULAR,specular);
  glMaterialf(GL_FRONT,GL_SHININESS,10);

  glPushMatrix();
  glTranslatef(0.0, 0.0, 0.0);
  glRotatef(-90.0, 1.0, 0.0, 0.0);//x����]
  drawElevation1(nMesh, nMesh, sizeX, sizeY, 0, data);
  glPopMatrix();
}

float getSingleWave(float r, float elapseTime, int k)
{
  float phase;
  float a;

  if(r < 0.2) r = 0.2;
  phase = 2.0 * M_PI * ( (elapseTime - timeOccur[k]) /period - r / lambda);

  if(phase >= 0.0 && phase < 2.0 * M_PI) 
		a = (float)( amp0 * sin(phase) )  / (sqrt(r)) ;
  else
    a = 0.0f;

  return( a );
}

void makeWave(float elapseTime)
{
  int i, j, k;
  float x, y, r;

  //Clear Wave
  for(j = 0; j <= nMesh; j++)
      for(i = 0; i <= nMesh; i++) data[j * (nMesh + 1) + i] = 0.0;

  for(k = 0; k < NUM_WAVE; k++)
  {
    for(j = 0; j <= nMesh; j++)
    {
      y = (float)( - nMesh / 2 + j) * meshY - sY[k];
      for(i = 0; i <= nMesh; i++)
      {
        x = (float)( - nMesh / 2 + i) * meshX - sX[k];
        r = sqrt( x * x + y * y);
        data[j * (nMesh + 1) + i] += getSingleWave(r, elapseTime, k);
      }
    }
  }
}

