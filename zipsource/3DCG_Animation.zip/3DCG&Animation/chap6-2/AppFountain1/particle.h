//particle.h
#include <stdlib.h>
#include <math.h>
#define NUM_PARTICLE 1500

int count = 0;//���o���ꂽ���q��

float g = 9.8;//�d�͉����x
float drag = 0.001;//��C��R
float e = 0.5;//���˕Ԃ�W��
float radius = 0.1;
float num0 = 10;

//���K����
float getNormalRandom(float mean, float sigma)
{
  double ran = 0.0;
  for(int i=0; i < 12; i++)
	{
		ran += (double)rand() / (double)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + (float)ran;
}

class CParticle 
{
public:
  bool flagProject;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  float pointSize;   //���q�̑傫��
  CParticle();
  CParticle(CVector vPosition0, CVector vVelocity0, CVector vAccel0);
  ~CParticle() {};
  void create();
  void update(float dt);
  void show(bool flagShadow);
};

CParticle::CParticle()
{
  pointSize = getNormalRandom(1.0, 0.2);
  vPosition = CVector(0.0, radius, 0.0);
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

CParticle::CParticle(CVector vPosition0, CVector vVelocity0, CVector vAccel0)
{
  vPosition = vPosition0;
  vVelocity = vVelocity0;
  vAccel = vAccel0;
}

void CParticle::create()
{
  vPosition = CVector(0.0, radius, 0.0);
  vVelocity = CVector(0.0, 8.0, 0.0);
  vVelocity.x = getNormalRandom(0.0, 0.2);
  vVelocity.y += getNormalRandom(0.0, 0.5);
  vVelocity.z = getNormalRandom(0.0, 0.2);
  flagProject = false;
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;//�d�͉����x�ƊO�͂͏�ɑ���
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
  if(vPosition.y < radius)
  {
		vPosition.y = + radius;
		vVelocity.y = - e * vVelocity.y;
  }
}

void CParticle::show(bool flagShadow)
{
  static float diffuse[] = { 0.8f, 0.9f, 1.0f, 1.0f};
  //�e�̃}�e���A��
  static float shadowDiffuse[] = {0.3f,0.3f,0.3f,0.3f};//�e�̊g�U��

  if(flagShadow) 
  {
	  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,shadowDiffuse);
  }
  else
  {	
	  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,diffuse);
  }

  if(!flagShadow)
	glPointSize(pointSize);
  else
	glPointSize(pointSize/2.0);
  glBegin(GL_POINTS);
	glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}






