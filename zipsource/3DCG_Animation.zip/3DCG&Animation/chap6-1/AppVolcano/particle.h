//particle.h
#define MAX_NUM_PARTICLE 50000

int numParticle = 40000;
float g = 9.8;//�d�͉����x
float drag = 1.0;//0.5;//��C��R
float hFire = 5.0;
float e = 0.0;
float pointSize = 5.0;
float alpha = 0.5;//�A���t�@�l

int mode = 0;
int num0 = 30;//��x�ɕ��o���闱�q��
int count = 0;//�g�p�������q��

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

float getNormalRandom(float mean, float sigma)
{//���K����
  double ran = 0.0;
  for(int i=0; i < 12; i++){
		ran += (double)rand() / (double)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + (float)ran;
}

CVector getRandomVector(int type)
{//xz�傫��1�ŕ��ˏ�Ɉ�l�ɍL����x�N�g��
  CVector vVector;
  if(type == 0) vVector.y = getRandom( -1.0f, 1.0f );//���S��
  else vVector.y = getRandom( 0.0f, 1.0f );//�㔼��

  float radius = (float)sqrt(1.0 - vVector.y * vVector.y);
  float theta = getRandom( -M_PI, M_PI );
  vVector.z = (float)cos(theta) * radius;
  vVector.x = (float)sin(theta) * radius;
  return vVector;
}

class CParticle {
public:
  float red, green, blue;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  float startTime;

  CParticle();
  ~CParticle() {};
  void update(float dt);
  void create(int no);
  void show(float elapsTime);
};

CParticle::CParticle()
{
  red = getRandom(0.0, 1.0);
  green = getRandom(0.0, 1.0);
  blue = getRandom(0.0, 1.0);
 
  vPosition = CVector(0.0, hFire, 0.0);
  vVelocity = CVector(0.0, 10.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::create(int no)
{
  if(mode == 0)
  {
		g = getRandom(3.0, 8.0);
		vPosition = CVector(0.0, hFire, 0.0);
		vVelocity = getRandomVector(0) * getNormalRandom(1.0,0.1);
		vVelocity.x *= 0.5;
		vVelocity.z *= 0.0;
		vVelocity.y *= 10.0;
  }

  else if(mode == 1)
  { 
		//������
		g = getRandom(3.0, 5.0);
	//	g = 0.0;
		vPosition = CVector(getRandom(-1.0, 1.0), hFire-1.0, getRandom(-0.1, 0.1));
		vVelocity = getRandomVector(1) * getNormalRandom(1.0, 0.1);
		vVelocity.x *= 0.3;
		vVelocity.z *= 0.0;
		vVelocity.y *= 10.0;
  }
  else if(mode == 2)
  {
		vVelocity = getRandomVector(1) * getNormalRandom(0.5, 0.1);
		vVelocity.x *= 0.3;
		vVelocity.z *= 0.3;
		if(no == 0) 
		{
			g = getNormalRandom(-1.0, 0.3);
			vPosition = CVector(0.0, hFire, 0.0);
			vVelocity.y += 2.0;
		}
		else if(no == 1) 
		{
			g = getNormalRandom(-1.5, 0.1);
			vPosition = CVector(-3.0, 2.0, 2.0);
			vVelocity.y += 1.0;
		}
		else if(no == 2) 
		{
			g = getNormalRandom(-2.0, 0.2);
			vPosition = CVector(2.0, 3.0, 2.0);
			vVelocity.y += 0.5;
		}
		else 
		{
			g = getNormalRandom(-1.0, 0.5);
			vPosition = CVector(4.0, 3.0, 0.0);
			vVelocity.y += 2.0;
		}
  }

  vAccel = CVector(0.0, - g, 0.0); 
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
}

void CParticle::show(float elapseTime)
{
  if(mode <= 1)
  {
		float t1 = 0.1, t2 = 1.0;
		if(elapseTime < t1) {red = 1.0; green = 0.9; blue = 0.1;}
		else if(elapseTime < t2) {red = 1.0; green = 0.2; blue = 0.1;}
		else { red = 0.7; green = 0.2; blue = 0.2;}
  }
  else if(mode == 2)
  {
		float t1 = 0.1, t2 = 0.5;
		if(elapseTime < t1) {red = 1.0; green = 0.8; blue = 0.7; }
		else if(elapseTime < t2) {red = 0.8; green = 0.8; blue = 0.8; }
		else {vVelocity = CVector(getRandom(-0.1, 0.1), getRandom(-0.1, 0.1),
			getRandom(-0.1, 0.1)); red = 0.7; green = 0.7; blue = 0.7;}
  }

  glPointSize(pointSize);
  glColor4f(red, green, blue, alpha);
  glBegin(GL_POINTS);
  glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}



