//particle.h
#include <stdlib.h>
#include <math.h>
#define MAX_NUM_PARTICLE 50000
int num0 = 30;
int numParticle = 17000;

int count = 0;//���o���ꂽ���q��

float g = 9.8;//�d�͉����x
float drag = 5.0;//��C��R
float e = 0.2;//���˕Ԃ�W��
float radius = 0.1;
float hSnow = 5.0;//�~��̍���
int mode = 0;//�������
float accelX = 0.0;

//��Q���̃T�C�Y
float boxX = 1.0, boxY = 2.0, boxZ = 2.0;
//�c���Ă������q
#define NUM_KEEP 100
int numKeep = 0;
CVector keepPos[NUM_KEEP]; 

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

//���K����
float getNormalRandom(float mean, float sigma)
{
  double ran = 0.0;
  for(int i=0; i < 12; i++){
		ran += (double)rand() / (double)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + (float)ran;
}


class CParticle 
{
public:
  bool flagProject;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  float pointSize;
  CParticle();
  CParticle(CVector vPosition0, CVector vVelocity0, CVector vAccel0);
  ~CParticle() {};
  void create();
  void update(float dt);
  void show();
  void drawKeep();
};

CParticle::CParticle()
{
  pointSize = getNormalRandom(2.0, 0.2);
  vPosition = CVector(getRandom(-10.0, 10.0), hSnow+ getRandom(-1.0, 1.0), getRandom(-8.0, 8.0));
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::create()
{
  vPosition = CVector(getRandom(-10.0, 10.0), hSnow+getRandom(-1.0, 1.0), getRandom(-8.0, 8.0));
  vVelocity = CVector(getNormalRandom(0.0, 0.5), getNormalRandom(0.0, 0.3), getNormalRandom(0.0, 0.5));
  vAccel = CVector(accelX+getNormalRandom(0.0, 0.8), -g + getNormalRandom(0.0, 0.8), getNormalRandom(0.0, 0.8)); 
  if(mode == 1) 
  {
		vPosition.x = getRandom(-20.0, 0.0);
  }
}

void CParticle::update(float dt)
{
  CVector accel = vAccel ;//�d�͉����x�ƊO�͂͏�ɑ���
  if(mode == 1) accel.x += 40.0;//x�������̋�����
  accel -= drag * vVelocity;//��C��R
  vVelocity += accel * dt;//���x�̍X�V
  
  //���̏�
  if(vPosition.x >= -boxX/2.0 && vPosition.x <= boxX/2.0
		&& vPosition.z >= -boxZ/2.0 && vPosition.z <= boxZ/2.0
		&& vPosition.y < boxY + 0.1) vVelocity = CVector(0.0, 0.0, 0.0);

  //�n��ɗ�������͌Œ�
  if(vPosition.y < radius+0.05) 
  {
		vVelocity *= 0.0;
		//keep
		if(numKeep < NUM_KEEP)
		{	 
			keepPos[numKeep] = vPosition;
			numKeep ++;
		}
  }
  //����(-x��������̋������j
  if(mode == 1)
  {
		if(vPosition.y < 0.2) vVelocity.y += getNormalRandom(3.0, 1.0);//�����オ���
		//���̉E���𖳕�
		if(vPosition.z > -boxZ/2.0 + 0.1 && vPosition.z < boxZ/2.0-0.1 && vPosition.y < boxY) 
		{
			//���̉E��
			if(vPosition.x >= boxX/2.0 && vPosition.x <= boxX/2.0+2.0) 
			{
				vVelocity = CVector(0.0, 0.0, 0.0);
				vPosition.y = 0.1;
				//keep
				if(numKeep < NUM_KEEP)
				{
					keepPos[numKeep] = vPosition;
					numKeep ++;
				}
			}
		}
  }
  //�ʒu�̍X�V
  vPosition += vVelocity * dt;
  //�t���A�ɓ��B
  if(vPosition.y < radius)
  {
		vPosition.y = + radius; //�t���A��ɃV�t�g
		vVelocity.y = - e * vVelocity.y;
  }
  //���̍��E
  if(vPosition.z >= -boxZ/2.0 && vPosition.z <= boxZ/2.0 && vPosition.y < boxY) 
  {
		//����
		if(vPosition.x >= -boxX/2.0 && vPosition.x <= 0.0) 
		{
			vPosition.x = -boxX/2.0 - 0.1; 
			//keep
			if(numKeep < NUM_KEEP){
				keepPos[numKeep] = vPosition;
				numKeep ++;
			}
		}
		//���̉E��
		if(vPosition.x >= 0.0 && vPosition.x <= boxX/2.0) 
		{
			vPosition.x = boxX/2.0 + 0.1; 
			//keep
			if(numKeep < NUM_KEEP){
				keepPos[numKeep] = vPosition;
				numKeep ++;
			}
		}
  }
  if(numKeep >= NUM_KEEP) numKeep = 0;
}

void CParticle::show()
{
  static float diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f};

  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,diffuse);

  glPointSize(pointSize);
  glBegin(GL_POINTS);
	glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}

//keep���ꂽ���q�̕`��
void drawKeep(int n)
{
  static float diffuse[] = { 1.0f, 1.0f, 1.0f, 1.0f};

  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,diffuse);

  glPointSize(5.0);
  glBegin(GL_POINTS);
	glVertex3f(keepPos[n].x, keepPos[n].y, keepPos[n].z);
  glEnd();
}








