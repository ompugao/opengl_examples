//particle.h
#define MAX_NUM_PARTICLE 50000

int numParticle = 10000;
int mode = 0;
int num0 = 50;//��x�ɕ��o���闱�q��
int count = 0;//�g�p�������q��
float g = -1.0;//9.8;//�d�͉����x
float drag = 0.5;//��C��R
float hFire = 5.0;
float e = 0.0;
float pointSize = 5.0;
float alpha = 0.6;//�A���t�@�l

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

float getNormalRandom(float mean, float sigma)
{//���K����
  double ran = 0.0;
  for(int i=0; i < 12; i++)
	{
		ran += (double)rand() / (double)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + (float)ran;
}

CVector getRandomVector(int type)
{//xz�傫��1�ŕ��ˏ�Ɉ�l�ɍL����x�N�g��
  CVector vVector;
  if(type == 0) vVector.y = getRandom( -1.0f, 1.0f );//���S��
  else vVector.y = getRandom( 0.0f, 1.0f );//�㔼��

  float radius = (float)sqrt(1.0 - vVector.y * vVector.y);
  float theta = getRandom( -M_PI, M_PI );
  vVector.z = (float)cos(theta) * radius;
  vVector.x = (float)sin(theta) * radius;
  return vVector;
}

class CParticle {
public:
  float red, green, blue;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  float startTime;

  CParticle();
  ~CParticle() {};
  void update(float dt);
  void create(float elapseTime);
  void show(float elapsTime);
};

CParticle::CParticle()
{
  red = getRandom(0.0, 1.0);
  green = getRandom(0.0, 1.0);
  blue = getRandom(0.0, 1.0);
 
  vPosition = CVector(0.0, hFire, 0.0);
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::create(float t)
{
  if(mode == 0)
  {
		vPosition = CVector(0.0, hFire, 0.0);
		vVelocity = getRandomVector(1) * getNormalRandom(1.0,0.3);//(0.1, 2.0);
		vVelocity.y *= 5.0;
  }
  else if(mode == 1)
  {
		//�Ό����~�O����`���Ĉړ�
		vPosition = CVector(0.0, hFire, 0.0);
		double theta = 2.0*M_PI * t / 20.0;
		vPosition.z = (float)cos(theta) * 5.0;
		vPosition.x = (float)sin(theta) * 5.0;

		vVelocity = getRandomVector(1) * getNormalRandom(1.0, 0.3);//0.1, 2.0);
		vVelocity.y *= 5.0;
  }

  else if(mode == 2)
  {
		//�Ό��������O��
		float theta = getRandom( -M_PI, M_PI );
		vPosition.x = (float)cos(theta) * 4.0;
		vPosition.y = hFire;
		vPosition.z = (float)sin(theta) * 4.0;

		vVelocity = getRandomVector(1) * getNormalRandom(1.0, 0.3);
		vVelocity.y *= 1.0;
  }

  else
  {
		//������
		vPosition = CVector(getRandom(-5.0, 5.0), hFire, getRandom(-0.1, 0.1));
		vVelocity = getRandomVector(1) * getNormalRandom(0.5, 0.1);
		vVelocity.y *= 6.0;
  }
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
}

void CParticle::show(float elapseTime)
{
  float t1 = 0.1, t2 = 1.0, t3 = 2.0;
  if(elapseTime < t1) {red = 1.0; green = 0.9; blue = 0.8;}
  else if(elapseTime < t2) {red = 1.0; green = 0.9; blue = 0.3;}
  else if(elapseTime < t3)  {red = 1.0; green = 0.3; blue = 0.2;}
  else {red = 0.7; green = 0.2; blue = 0.2;}

  glPointSize(pointSize);
  glColor4f(red, green, blue, alpha);
  glBegin(GL_POINTS);
  glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}



