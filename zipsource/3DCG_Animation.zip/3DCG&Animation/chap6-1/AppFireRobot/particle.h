//particle.h
#define MAX_NUM_PARTICLE 50000

int numParticle = 1200;//���ۂ̗��q��
int num0 = 30;//��x�ɕ��o���闱�q��
float g = -1.0;//9.8;//�d�͉����x
float drag = 0.5;//��C��R
float hFire = 2.0;
float e = 0.0;
float pointSize = 5.0;
int count = 0;//�g�p�������q��

float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}

float getNormalRandom(float mean, float sigma)
{//���K����
  float ran = 0.0;
  for(int i=0; i < 12; i++)
	{
		ran += (float)rand() / (float)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + (float)ran;
}

CVector getRandomVector(int type)
{//xz�傫��1�ŕ��ˏ�Ɉ�l�ɍL����x�N�g��
  CVector vVector;
  if(type == 0) vVector.y = getRandom( -1.0f, 1.0f );//���S��
  else vVector.y = getRandom( 0.0f, 1.0f );//�㔼��

  float radius = (float)sqrt(1.0 - vVector.y * vVector.y);
  float theta = getRandom( -M_PI, M_PI );
  vVector.z = (float)cos(theta) * radius;
  vVector.x = (float)sin(theta) * radius;
  return vVector;
}

class CParticle 
{
public:
  float red, green, blue, alpha;
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  CVector vPositionL;
  CVector vLastPositionL;
  float startTime;
  float lineWidth;
  int frameCount;

  CParticle();
  ~CParticle() {};
  void update(float dt);
  void create(float elapseTime);
  void show(float elapsTime);
};

CParticle::CParticle()
{
  vPosition = CVector(0.0, hFire, 0.0);
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::create(float t)
{ 
  vVelocity = getRandomVector(1) * getNormalRandom(0.3,0.1);//(0.1, 2.0);
  vVelocity.y *= 10.0;
}

void CParticle::update(float dt)
{
  CVector accel = vAccel;
  accel -= drag * vVelocity;
  vVelocity += accel * dt;
  vPosition += vVelocity * dt;
}

void CParticle::show(float elapseTime)
{
  float t1 = 0.2, t2 = 0.25, t3 = 0.6;
  if(elapseTime < t1) {red = 0.3; green = 0.3; blue = 1.0; alpha = 0.2;}
  else if(elapseTime < t2) {red = 0.9; green = 0.7; blue = 0.4; alpha = 0.9;}
  else if(elapseTime < t3)  {red = 1.0; green = 0.9; blue = 0.8; alpha = 1.0;}
  else {red = 0.8; green = 0.5; blue = 0.3; alpha = 1.0;}
 
  glPointSize(pointSize);
  glColor4f(red, green, blue, alpha);
  glBegin(GL_POINTS);
  glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}



