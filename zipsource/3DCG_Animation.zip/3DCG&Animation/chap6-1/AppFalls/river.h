//river�f�[�^
#define nMesh 32//�ő啪�����i���ӓ����j
#define NUM_WAVE 3//�~�`�g�̔g����
float period = 2.0;
float lambda = 3.0;
float amp0 = 0.05;
float sizeX = 4.0;
float sizeY = 6.0;
float meshX = sizeX / (float)nMesh;
float meshY = sizeY / (float)nMesh;
float data[(nMesh+1)*(nMesh+1)];//Wave�̍����f�[�^

void drawRiver()
{
  static float diffuse[] = { 0.4f, 0.6f, 0.9f, 0.1f};
  static float ambient[] = { 0.1f, 0.2f, 0.3f, 0.1f};
  static float specular[]= { 0.5f, 0.5f, 0.5f, 0.0f};

  glMaterialfv(GL_FRONT,GL_DIFFUSE,diffuse);
  glMaterialfv(GL_FRONT,GL_AMBIENT,ambient);
  glMaterialfv(GL_FRONT,GL_SPECULAR,specular);
  glMaterialf(GL_FRONT,GL_SHININESS,10);

  glPushMatrix();
  glTranslatef(0.0, 0.0, sizeY/2.0);
  glRotatef(-90.0, 1.0, 0.0, 0.0);//x����]
  drawElevation1(nMesh, nMesh, sizeX, sizeY, 0, data);
  glPopMatrix();
}

float getWave(float r, float elapseTime, int k)
{
  float phase;
  float a;

  if(r < 0.01) r = 0.01;
  phase = 2.0 * M_PI * ( elapseTime /period - r / lambda);

  if(phase >= 0.0) 
		a = (float)( amp0 * (sin(phase) + 0.6*sin(2.0*phase) + 0.5 * sin(5.0*phase)) ) / (sqrt(r)) ;
  else 
		a = 0.0f;

  return( a );
}

void makeRiver(float elapseTime)
{
  int i, j, k;
  float x, y, r;
  float sX[NUM_WAVE], sY[NUM_WAVE];//�~�`�g�̒��S

  //�g��
  sX[0] =  0.0; sY[0] = 1.9;
  sX[1] = -1.0; sY[1] = 2.0;
  sX[2] =  1.0; sY[2] = 2.0;

  //Clear Wave
  for(j = 0; j <= nMesh; j++)
      for(i = 0; i <= nMesh; i++)
          data[j * (nMesh + 1) + i] = 0.0;

  for(k = 0; k < NUM_WAVE; k++)
  {
    for(j = 0; j <= nMesh; j++)
    {
      y = (float)( - nMesh / 2 + j) * meshY - sY[k];
      for(i = 0; i <= nMesh; i++)
      {
          x = (float)( - nMesh / 2 + i) * meshX - sX[k];
          r = sqrt( x * x + y * y);
          data[j * (nMesh + 1) + i] += getWave(r, elapseTime, k);
      }
    }
  }
}

