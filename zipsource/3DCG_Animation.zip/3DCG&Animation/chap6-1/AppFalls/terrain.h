//Terrain�f�[�^

#define nMeshT 64//�ő�128
float dataT[(nMeshT+1)*(nMeshT+1)];//Terrain�����f�[�^
double beta = 2.8;//fBm�̎w����
double sigma = 0.2;//�W���΍�

void makeTerrain()
{
  //Terrain�f�[�^�̍쐬
  int i, j;
  CMidpoint2 mp = CMidpoint2();
  mp.numDiv = 8;
  mp.numMax = nMeshT;
  mp.sigma = sigma;
  mp.beta = beta;

  //�������x�f�[�^
  for(j = 0; j <= mp.numDiv; j++)
	for(i = 0; i <= mp.numDiv; i++)
	{
	  if(j < 4) 
	  {
		mp.h[i][j] = 0.2;
		if(i >= 3 && i <= 5) mp.h[i][j] = -0.2;
	  }
	  else 
	  {
		mp.h[i][j] = 2.5;
		if(i == 4) mp.h[i][j] = 2.45;
	  }
	}
  mp.create(0, dataT);//��1�����͗�����seed�i�l��ς���ƈقȂ����p�^�[�����쐬�j
  //�����z���ɕ��s�ɂ��镝�ŒႭ����
  for(j = 3*nMeshT/8; j < 3*nMeshT/8+2; j++)
	for(i = 0; i <= nMeshT; i++) dataT[i + j*(nMeshT+1)] = 0.1 + getRandom(-0.1, 0.1);
  for(j = 3*nMeshT/8+2; j < 3*nMeshT/8+4; j++)
	for(i = 0; i <= nMeshT; i++) dataT[i + j*(nMeshT+1)] = 0.15 + getRandom(-0.1, 0.1);
  for(j = 3*nMeshT/8+4; j < 3*nMeshT/8+6; j++)
	for(i = 0; i <= nMeshT; i++) dataT[i + j*(nMeshT+1)] = 0.4 + getRandom(-0.1, 0.1);
  j = 3*nMeshT/8+6;
	for(i = 0; i <= nMeshT; i++) dataT[i + j*(nMeshT+1)] = 1.8 + getRandom(-0.1, 0.1);
  j = 3*nMeshT/8+7;
	for(i = 0; i <= nMeshT; i++) dataT[i + j*(nMeshT+1)] = 2.0 + getRandom(-0.1, 0.1);

	for(i = 2*nMeshT/8; i < 6*nMeshT/8 ; i++)
	for(j = 0; j < nMeshT; j++) dataT[i + j*(nMeshT+1)] -= 0.2 + getRandom(-0.1, 0.1);
  
}

void drawTerrain()
{
  static float diffuse[] = { 0.6f, 0.5f, 0.3f, 1.0f} ;
  static float ambient[] = { 0.2f, 0.18f, 0.15f, 1.0f};
  static float specular[]= { 0.1f, 0.1f, 0.1f, 1.0f};
  glMaterialfv(GL_FRONT,GL_DIFFUSE,diffuse);
  glMaterialfv(GL_FRONT,GL_AMBIENT,ambient);
  glMaterialfv(GL_FRONT,GL_SPECULAR,specular);
  glMaterialf(GL_FRONT,GL_SHININESS,100);

  glPushMatrix();
  glRotatef(-90.0, 1.0, 0.0, 0.0);//x����]
  drawElevation1(nMeshT, nMeshT, 8.0, 12.0, 0, dataT);//, dif);
  glPopMatrix();
}
