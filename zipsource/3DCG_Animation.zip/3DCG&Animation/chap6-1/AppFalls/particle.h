//particle.h
#include <stdlib.h>
#include <math.h>

#define MAX_NUM_PARTICLE 20000
int numParticle = 7000;
int num0 = 40;
int count = 0;//���o���ꂽ���q��

float g = 9.8;//�d�͉����x
float drag = 0.001;//��C��R
float e = 0.5;//���˕Ԃ�W��
float radius = 0.1;
int frameCount;

//��l����
float getRandom(float fMin, float fMax)
{
  return fMin + (fMax - fMin) * (float)rand() / (float)RAND_MAX;
}
//���K����
float getNormalRandom(float mean, float sigma)
{
  double ran = 0.0;
  for(int i=0; i < 12; i++)
	{
		ran += (double)rand() / (double)RAND_MAX;
  }
  ran -= 6.0;
  ran *= sigma;
  return mean + (float)ran;
}


class CParticle {
public:
  CVector vPosition; // �ʒu
  CVector vVelocity; // ���x
  CVector vAccel;    //�����x
  float pointSize;
  CParticle();
  ~CParticle() {};
  void create();
  void update(float dt);
  void show();
};

CParticle::CParticle()
{
  pointSize = getNormalRandom(2.0, 0.5);
  vPosition = CVector(0.0, 2.3, -5.0);
  vVelocity = CVector(0.0, 0.0, 0.0);
  vAccel = CVector(0.0, - g, 0.0);
}

void CParticle::create()
{
  vPosition = CVector(getRandom(-1.2, 1.2), getRandom(2.2, 2.5), getRandom(-5.0, -5.5));
  vVelocity = CVector(0.0, 0.0, getNormalRandom(1.2, 0.4));
}

void CParticle::update(float dt)
{
  CVector accel;
  if(vPosition.z < 0.0) accel = CVector(0.0, 0.0, 0.0);
  else 
  {
		accel = vAccel;
		accel -= drag * vVelocity;
		vVelocity += accel * dt;
  }
  vPosition += vVelocity * dt;
  if(vPosition.y < radius)
  {
		vPosition.y = + radius;
		vVelocity.y = - e * vVelocity.y;
  }
  if(vPosition.z > 3.0 + getRandom(-1.0, 1.0)) create();
}

void CParticle::show()
{
  static float diffuse[] = { 1.0f, 1.0f, 1.0f, 0.6f};
  glMaterialfv(GL_FRONT,GL_AMBIENT_AND_DIFFUSE,diffuse);

  glPointSize(pointSize);
  glBegin(GL_POINTS);
	glVertex3f(vPosition.x, vPosition.y, vPosition.z);
  glEnd();
}
